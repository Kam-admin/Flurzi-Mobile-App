/// Example Ad Network Plugin for Flurzi Mobile App
/// This demonstrates how to integrate an external ad network with the Flurzi SDK
library;

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../lib/services/sdk_ad_manager.dart';

/// Example implementation of an external ad network plugin
class ExampleAdNetworkPlugin {
  static const String _pluginName = 'Example Ad Network';
  static const String _pluginVersion = '1.0.0';
  
  final SDKAdManager _sdkAdManager = SDKAdManager();
  String? _clientId;
  bool _isInitialized = false;
  
  // Simulated ad network state
  final List<String> _availableAdUnits = [
    'rewarded_video_main',
    'rewarded_video_bonus',
    'interstitial_mining',
  ];
  
  // Plugin configuration
  final Map<String, dynamic> _config = {
    'ad_timeout_seconds': 30,
    'retry_attempts': 3,
    'reward_multiplier': 1.0,
    'test_mode': true,
  };

  /// Initialize the plugin with SDK credentials
  Future<bool> initialize({
    required String clientId,
    required String clientSecret,
    Map<String, dynamic>? config,
  }) async {
    try {
      print('[$_pluginName] Initializing plugin v$_pluginVersion...');
      
      // Merge custom config
      if (config != null) {
        _config.addAll(config);
      }
      
      // Initialize SDK
      final initResult = await _sdkAdManager.initialize(
        clientId: clientId,
        clientSecret: clientSecret,
      );
      
      if (!initResult.success) {
        print('[$_pluginName] SDK initialization failed: ${initResult.message}');
        return false;
      }
      
      _clientId = clientId;
      _isInitialized = true;
      
      // Setup event listeners
      _setupEventListeners();
      
      print('[$_pluginName] Plugin initialized successfully');
      print('[$_pluginName] Client ID: $_clientId');
      print('[$_pluginName] User ID: ${initResult.userId}');
      
      return true;
    } catch (e) {
      print('[$_pluginName] Initialization error: $e');
      return false;
    }
  }
  
  /// Setup event listeners for real-time updates
  void _setupEventListeners() {
    // Listen to ad status changes
    _sdkAdManager.adStatusStream.listen((update) {
      print('[$_pluginName] Ad Status Update: ${update.type}');
      print('[$_pluginName] Tier: ${update.tierId}');
      print('[$_pluginName] Progress: ${update.adsWatched}/${update.adsRequired}');
      
      _handleAdStatusUpdate(update);
    });
    
    // Listen to reward updates
    _sdkAdManager.adRewardStream.listen((reward) {
      print('[$_pluginName] Reward Update: ${reward.amount} coins');
      print('[$_pluginName] Tier: ${reward.tierName}');
      print('[$_pluginName] External: ${reward.isExternal}');
      
      _handleRewardUpdate(reward);
    });
  }
  
  /// Check if ads are available for the current user
  Future<bool> isAdAvailable() async {
    if (!_isInitialized || _clientId == null) {
      print('[$_pluginName] Plugin not initialized');
      return false;
    }
    
    try {
      final availability = await _sdkAdManager.checkAdAvailability(_clientId!);
      
      if (availability.error != null) {
        print('[$_pluginName] Availability check error: ${availability.error}');
        return false;
      }
      
      print('[$_pluginName] Can watch ads: ${availability.canWatchAds}');
      print('[$_pluginName] Available tiers: ${availability.availableTierCount}');
      print('[$_pluginName] Daily progress: ${availability.dailyAdsWatched}/${availability.maxDailyAds}');
      
      return availability.canWatchAds;
    } catch (e) {
      print('[$_pluginName] Error checking ad availability: $e');
      return false;
    }
  }
  
  /// Get detailed ad status and available tiers
  Future<AdAvailabilityResult?> getAdStatus() async {
    if (!_isInitialized || _clientId == null) return null;
    
    try {
      return await _sdkAdManager.checkAdAvailability(_clientId!);
    } catch (e) {
      print('[$_pluginName] Error getting ad status: $e');
      return null;
    }
  }
  
  /// Show a rewarded ad (simulated)
  Future<AdShowResult> showRewardedAd({String? tierId}) async {
    if (!_isInitialized || _clientId == null) {
      return AdShowResult(
        success: false,
        message: 'Plugin not initialized',
      );
    }
    
    try {
      // Check if ads are available
      if (!await isAdAvailable()) {
        return AdShowResult(
          success: false,
          message: 'No ads available',
        );
      }
      
      print('[$_pluginName] Preparing to show rewarded ad...');
      
      // Simulate ad loading
      await _simulateAdLoading();
      
      // Simulate ad display
      final adResult = await _simulateAdDisplay();
      
      if (!adResult.success) {
        return AdShowResult(
          success: false,
          message: adResult.message,
        );
      }
      
      // Process reward through SDK
      final watchResult = await _sdkAdManager.watchAd(_clientId!, tierId: tierId);
      
      if (watchResult.success) {
        print('[$_pluginName] Ad completed successfully!');
        print('[$_pluginName] Earned: ${watchResult.earnings} coins');
        print('[$_pluginName] Tier: ${watchResult.tierName}');
        
        return AdShowResult(
          success: true,
          message: 'Ad completed successfully',
          earnings: watchResult.earnings,
          tierId: watchResult.tierId,
          tierName: watchResult.tierName,
        );
      } else {
        return AdShowResult(
          success: false,
          message: 'Failed to process reward: ${watchResult.message}',
        );
      }
    } catch (e) {
      print('[$_pluginName] Error showing ad: $e');
      return AdShowResult(
        success: false,
        message: 'Technical error: $e',
      );
    }
  }
  
  /// Show an external ad (from your own ad network)
  Future<AdShowResult> showExternalAd({
    required String tierId,
    required String adUnitId,
  }) async {
    if (!_isInitialized || _clientId == null) {
      return AdShowResult(
        success: false,
        message: 'Plugin not initialized',
      );
    }
    
    try {
      print('[$_pluginName] Showing external ad from unit: $adUnitId');
      
      // Simulate external ad network call
      final externalAdResult = await _simulateExternalAdNetwork(adUnitId);
      
      if (!externalAdResult.success) {
        return AdShowResult(
          success: false,
          message: externalAdResult.message,
        );
      }
      
      // Process external ad reward through SDK
      final rewardResult = await _sdkAdManager.processExternalAdReward(
        clientId: _clientId!,
        tierId: tierId,
        rewardAmount: externalAdResult.rewardAmount,
        adNetworkId: _pluginName,
        adUnitId: adUnitId,
        metadata: {
          'ad_format': 'rewarded_video',
          'completion_time': DateTime.now().toIso8601String(),
          'ad_duration': externalAdResult.duration,
          'completion_rate': externalAdResult.completionRate,
        },
      );
      
      if (rewardResult.success) {
        print('[$_pluginName] External ad reward processed: ${rewardResult.rewardAmount} coins');
        
        return AdShowResult(
          success: true,
          message: 'External ad completed successfully',
          earnings: rewardResult.rewardAmount,
          tierId: tierId,
          isExternal: true,
        );
      } else {
        return AdShowResult(
          success: false,
          message: 'Failed to process external reward: ${rewardResult.message}',
        );
      }
    } catch (e) {
      print('[$_pluginName] Error showing external ad: $e');
      return AdShowResult(
        success: false,
        message: 'External ad error: $e',
      );
    }
  }
  
  /// Get plugin configuration
  Future<Map<String, dynamic>> getConfiguration() async {
    if (!_isInitialized || _clientId == null) {
      return {'error': 'Plugin not initialized'};
    }
    
    try {
      final sdkConfig = await _sdkAdManager.getAdConfiguration(_clientId!);
      
      return {
        'plugin': {
          'name': _pluginName,
          'version': _pluginVersion,
          'config': _config,
          'available_ad_units': _availableAdUnits,
        },
        'sdk': {
          'max_daily_ads': sdkConfig.maxDailyAds,
          'cooldown_minutes': sdkConfig.adCooldownMinutes,
          'supported_ad_types': sdkConfig.supportedAdTypes,
          'ad_networks': sdkConfig.adNetworks,
          'reward_multiplier': sdkConfig.rewardMultiplier,
        },
      };
    } catch (e) {
      return {'error': 'Failed to get configuration: $e'};
    }
  }
  
  /// Handle ad status updates
  void _handleAdStatusUpdate(AdStatusUpdate update) {
    switch (update.type) {
      case AdStatusType.adWatched:
        print('[$_pluginName] User watched an ad for tier ${update.tierId}');
        break;
      case AdStatusType.externalAdRewarded:
        print('[$_pluginName] External ad reward processed for tier ${update.tierId}');
        break;
      case AdStatusType.tierCompleted:
        print('[$_pluginName] Tier ${update.tierId} completed!');
        // Could trigger special rewards or notifications
        break;
      case AdStatusType.dailyLimitReached:
        print('[$_pluginName] Daily ad limit reached');
        // Could disable ad UI or show appropriate message
        break;
    }
  }
  
  /// Handle reward updates
  void _handleRewardUpdate(AdRewardUpdate reward) {
    print('[$_pluginName] Reward processed: ${reward.amount} coins');
    
    if (reward.isExternal) {
      print('[$_pluginName] External reward from ${reward.adNetworkId}');
    }
    
    // Could trigger UI updates, analytics, etc.
  }
  
  /// Simulate ad loading process
  Future<void> _simulateAdLoading() async {
    print('[$_pluginName] Loading ad...');
    
    // Simulate network delay
    await Future.delayed(Duration(
      milliseconds: 500 + Random().nextInt(1500),
    ));
    
    print('[$_pluginName] Ad loaded successfully');
  }
  
  /// Simulate ad display and user interaction
  Future<_AdDisplayResult> _simulateAdDisplay() async {
    print('[$_pluginName] Displaying ad...');
    
    // Simulate ad display time
    await Future.delayed(Duration(
      seconds: 15 + Random().nextInt(15), // 15-30 seconds
    ));
    
    // Simulate completion (90% success rate in test mode)
    final success = _config['test_mode'] == true 
        ? Random().nextDouble() > 0.1
        : Random().nextDouble() > 0.2;
    
    if (success) {
      print('[$_pluginName] Ad completed by user');
      return _AdDisplayResult(
        success: true,
        message: 'Ad completed successfully',
      );
    } else {
      print('[$_pluginName] Ad was skipped or failed');
      return _AdDisplayResult(
        success: false,
        message: 'Ad was not completed',
      );
    }
  }
  
  /// Simulate external ad network integration
  Future<_ExternalAdResult> _simulateExternalAdNetwork(String adUnitId) async {
    print('[$_pluginName] Calling external ad network for unit: $adUnitId');
    
    // Simulate network call
    await Future.delayed(Duration(milliseconds: 200 + Random().nextInt(800)));
    
    // Simulate ad display
    await Future.delayed(Duration(seconds: 20 + Random().nextInt(10)));
    
    // Simulate success (85% success rate)
    final success = Random().nextDouble() > 0.15;
    
    if (success) {
      final rewardAmount = 5.0 + Random().nextDouble() * 15.0; // 5-20 coins
      final duration = 25 + Random().nextInt(10); // 25-35 seconds
      final completionRate = 0.8 + Random().nextDouble() * 0.2; // 80-100%
      
      return _ExternalAdResult(
        success: true,
        message: 'External ad completed',
        rewardAmount: rewardAmount,
        duration: duration,
        completionRate: completionRate,
      );
    } else {
      return _ExternalAdResult(
        success: false,
        message: 'External ad failed or was skipped',
        rewardAmount: 0.0,
        duration: 0,
        completionRate: 0.0,
      );
    }
  }
  
  /// Dispose plugin resources
  void dispose() {
    print('[$_pluginName] Disposing plugin resources...');
    _sdkAdManager.dispose();
    _isInitialized = false;
    _clientId = null;
  }
}

/// Result of showing an ad
class AdShowResult {
  final bool success;
  final String message;
  final double earnings;
  final String tierId;
  final String tierName;
  final bool isExternal;
  
  AdShowResult({
    required this.success,
    required this.message,
    this.earnings = 0.0,
    this.tierId = '',
    this.tierName = '',
    this.isExternal = false,
  });
}

/// Internal class for ad display simulation
class _AdDisplayResult {
  final bool success;
  final String message;
  
  _AdDisplayResult({
    required this.success,
    required this.message,
  });
}

/// Internal class for external ad network simulation
class _ExternalAdResult {
  final bool success;
  final String message;
  final double rewardAmount;
  final int duration;
  final double completionRate;
  
  _ExternalAdResult({
    required this.success,
    required this.message,
    required this.rewardAmount,
    required this.duration,
    required this.completionRate,
  });
}

/// Example usage of the plugin
class ExampleUsage {
  static Future<void> demonstratePlugin() async {
    final plugin = ExampleAdNetworkPlugin();
    
    // Initialize plugin
    final initialized = await plugin.initialize(
      clientId: 'your_client_id',
      clientSecret: 'your_client_secret',
      config: {
        'test_mode': true,
        'reward_multiplier': 1.2,
      },
    );
    
    if (!initialized) {
      print('Failed to initialize plugin');
      return;
    }
    
    // Check ad availability
    final isAvailable = await plugin.isAdAvailable();
    if (!isAvailable) {
      print('No ads available');
      return;
    }
    
    // Get detailed status
    final status = await plugin.getAdStatus();
    if (status != null) {
      print('Available tiers: ${status.availableTiers.length}');
      for (final tier in status.availableTiers) {
        print('- ${tier.name}: ${tier.rewardPerAd} coins per ad');
      }
    }
    
    // Show a regular ad
    final adResult = await plugin.showRewardedAd();
    if (adResult.success) {
      print('Earned ${adResult.earnings} coins!');
    } else {
      print('Ad failed: ${adResult.message}');
    }
    
    // Show an external ad
    if (status != null && status.availableTiers.isNotEmpty) {
      final externalResult = await plugin.showExternalAd(
        tierId: status.availableTiers.first.id,
        adUnitId: 'rewarded_video_main',
      );
      
      if (externalResult.success) {
        print('External ad earned ${externalResult.earnings} coins!');
      }
    }
    
    // Get configuration
    final config = await plugin.getConfiguration();
    print('Plugin configuration: $config');
    
    // Cleanup
    plugin.dispose();
  }
}