# Flurzi Mobile App - SDK Integration Guide

## Overview

The Flurzi Mobile App SDK provides a comprehensive interface for external ad networks and plugins to integrate with the app's reward system. This guide covers everything you need to know to successfully integrate your ad solution.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Authentication](#authentication)
3. [Ad Integration](#ad-integration)
4. [API Reference](#api-reference)
5. [Real-time Updates](#real-time-updates)
6. [Best Practices](#best-practices)
7. [Error Handling](#error-handling)
8. [Examples](#examples)

## Getting Started

### Prerequisites

- Flutter development environment
- Valid SDK client credentials
- Understanding of the Flurzi Mobile App's tier system

### Installation

1. Add the SDK Ad Manager to your project:

```dart
import 'package:flurzi_mobile_app/services/sdk_ad_manager.dart';
```

2. Initialize the SDK:

```dart
final adManager = SDKAdManager();

final initResult = await adManager.initialize(
  clientId: 'your_client_id',
  clientSecret: 'your_client_secret',
  userId: 'optional_user_id',
);

if (initResult.success) {
  print('SDK initialized successfully');
} else {
  print('Failed to initialize: ${initResult.message}');
}
```

## Authentication

### SDK Client Registration

Before using the SDK, you need to register as an SDK client:

```dart
final sdkService = SDKService();

final registrationResult = await sdkService.registerSDKClient(
  clientName: 'Your Ad Network',
  description: 'Integration with Your Ad Network',
  permissions: ['ads:watch', 'ads:status', 'ads:config'],
);

if (registrationResult.success) {
  final clientId = registrationResult.clientId;
  final clientSecret = registrationResult.clientSecret;
  // Store these credentials securely
}
```

### Token Validation

All API calls require a valid client token:

```dart
final validation = await sdkService.validateToken(clientId);
if (validation.isValid) {
  // Proceed with API calls
} else {
  // Handle invalid token
  print('Token validation failed: ${validation.message}');
}
```

## Ad Integration

### Checking Ad Availability

Before showing ads, check if the user can watch more ads:

```dart
final availability = await adManager.checkAdAvailability(clientId);

if (availability.canWatchAds) {
  print('User can watch ${availability.availableTierCount} tier ads');
  print('Daily ads watched: ${availability.dailyAdsWatched}/${availability.maxDailyAds}');
  
  // Show available tiers
  for (final tier in availability.availableTiers) {
    print('Tier: ${tier.name}, Progress: ${(tier.progress * 100).toStringAsFixed(1)}%');
    print('Reward per ad: ${tier.rewardPerAd} coins');
  }
} else {
  print('No ads available. Next ad in: ${availability.nextAdAvailableIn}');
}
```

### Watching Ads

#### Option 1: Let the system choose the best tier

```dart
final result = await adManager.watchAd(clientId);

if (result.success) {
  print('Ad watched successfully!');
  print('Earned: ${result.earnings} coins');
  print('Tier: ${result.tierName}');
  print('Progress: ${result.adsWatched}/${result.adsRequired}');
} else {
  print('Failed to watch ad: ${result.message}');
}
```

#### Option 2: Target a specific tier

```dart
final result = await adManager.watchAd(clientId, tierId: 'specific_tier_id');
```

### Processing External Ad Rewards

When your ad network shows an ad, process the reward:

```dart
final rewardResult = await adManager.processExternalAdReward(
  clientId: clientId,
  tierId: 'target_tier_id',
  rewardAmount: 10.5,
  adNetworkId: 'your_network_id',
  adUnitId: 'your_ad_unit_id',
  metadata: {
    'ad_type': 'rewarded_video',
    'duration': 30,
    'completion_rate': 1.0,
  },
);

if (rewardResult.success) {
  print('External ad reward processed: ${rewardResult.rewardAmount} coins');
} else {
  print('Failed to process reward: ${rewardResult.message}');
}
```

## API Reference

### SDKAdManager Methods

#### `initialize(clientId, clientSecret, userId?)`

Initializes the SDK with your credentials.

**Parameters:**
- `clientId` (String): Your SDK client ID
- `clientSecret` (String): Your SDK client secret
- `userId` (String, optional): Specific user ID to target

**Returns:** `SDKInitResult`

#### `checkAdAvailability(clientId)`

Checks if the user can watch more ads and returns available tiers.

**Returns:** `AdAvailabilityResult`

#### `watchAd(clientId, tierId?)`

Processes an ad watch for the user.

**Parameters:**
- `clientId` (String): Your SDK client ID
- `tierId` (String, optional): Specific tier to target

**Returns:** `AdWatchResult`

#### `getAdStatus(clientId)`

Retrieves the current ad status for the user.

**Returns:** `AdStatusResult`

#### `processExternalAdReward(params)`

Processes a reward from an external ad network.

**Parameters:**
- `clientId` (String): Your SDK client ID
- `tierId` (String): Target tier ID
- `rewardAmount` (double): Reward amount in coins
- `adNetworkId` (String, optional): Your ad network identifier
- `adUnitId` (String, optional): Specific ad unit identifier
- `metadata` (Map, optional): Additional metadata

**Returns:** `AdRewardResult`

#### `getAdConfiguration(clientId)`

Retrieves ad configuration and limits.

**Returns:** `AdConfigResult`

### Data Models

#### `AdTierInfo`

```dart
class AdTierInfo {
  final String id;           // Tier identifier
  final String name;         // Tier display name
  final int adsWatched;      // Ads watched for this tier
  final int adsRequired;     // Total ads required for tier
  final double rewardPerAd;  // Coins earned per ad
  final double progress;     // Progress percentage (0.0 - 1.0)
}
```

#### `AdAvailabilityResult`

```dart
class AdAvailabilityResult {
  final bool canWatchAds;              // Can user watch more ads
  final int availableTierCount;        // Number of available tiers
  final int dailyAdsWatched;          // Ads watched today
  final int maxDailyAds;              // Daily ad limit
  final Duration nextAdAvailableIn;    // Time until next ad
  final List<AdTierInfo> availableTiers; // Available tiers
  final String? error;                 // Error message if any
}
```

## Real-time Updates

### Listening to Ad Status Changes

```dart
// Listen to ad status updates
adManager.adStatusStream.listen((update) {
  switch (update.type) {
    case AdStatusType.adWatched:
      print('Ad watched for tier ${update.tierId}');
      break;
    case AdStatusType.externalAdRewarded:
      print('External ad reward processed');
      break;
    case AdStatusType.tierCompleted:
      print('Tier ${update.tierId} completed!');
      break;
    case AdStatusType.dailyLimitReached:
      print('Daily ad limit reached');
      break;
  }
});
```

### Listening to Reward Updates

```dart
// Listen to reward updates
adManager.adRewardStream.listen((reward) {
  print('Reward received: ${reward.amount} coins');
  print('Tier: ${reward.tierName}');
  print('External: ${reward.isExternal}');
  
  if (reward.isExternal) {
    print('Ad Network: ${reward.adNetworkId}');
    print('Ad Unit: ${reward.adUnitId}');
  }
});
```

## Best Practices

### 1. Check Availability Before Showing Ads

Always check if ads are available before presenting them to users:

```dart
final availability = await adManager.checkAdAvailability(clientId);
if (!availability.canWatchAds) {
  // Don't show ad UI
  return;
}
```

### 2. Handle Rate Limiting

Respect the app's rate limiting:

```dart
final config = await adManager.getAdConfiguration(clientId);
print('Max daily ads: ${config.maxDailyAds}');
print('Cooldown: ${config.adCooldownMinutes} minutes');
```

### 3. Validate Rewards

Ensure reward amounts are reasonable:

```dart
final tier = availability.availableTiers.first;
final maxReward = tier.rewardPerAd * 1.1; // 10% tolerance

if (rewardAmount > maxReward) {
  // Reject excessive reward
  return;
}
```

### 4. Use Appropriate Tier Selection

```dart
// Find the highest-value tier
final bestTier = availability.availableTiers
    .reduce((a, b) => a.rewardPerAd > b.rewardPerAd ? a : b);

final result = await adManager.watchAd(clientId, tierId: bestTier.id);
```

### 5. Implement Proper Error Handling

```dart
try {
  final result = await adManager.watchAd(clientId);
  if (!result.success) {
    // Handle business logic errors
    showUserMessage(result.message);
  }
} catch (e) {
  // Handle technical errors
  logError('Ad watch failed', e);
  showUserMessage('Something went wrong. Please try again.');
}
```

## Error Handling

### Common Error Scenarios

1. **Invalid Credentials**
   ```dart
   // Error: "Invalid or expired token"
   // Solution: Re-authenticate or refresh token
   ```

2. **No Available Ads**
   ```dart
   // Error: "No active tiers available for ad watching"
   // Solution: Check availability first
   ```

3. **Daily Limit Reached**
   ```dart
   // Error: "Daily ad limit reached"
   // Solution: Wait until next day or show appropriate message
   ```

4. **Invalid Reward Amount**
   ```dart
   // Error: "Reward amount exceeds expected value"
   // Solution: Validate reward against tier expectations
   ```

### Error Response Format

All methods return structured error information:

```dart
if (!result.success) {
  print('Error: ${result.message}');
  // Handle specific error cases
}
```

## Examples

### Complete Integration Example

```dart
import 'package:flurzi_mobile_app/services/sdk_ad_manager.dart';

class MyAdNetworkIntegration {
  final SDKAdManager _adManager = SDKAdManager();
  late String _clientId;
  
  Future<void> initialize() async {
    // Initialize SDK
    final initResult = await _adManager.initialize(
      clientId: 'your_client_id',
      clientSecret: 'your_client_secret',
    );
    
    if (initResult.success) {
      _clientId = initResult.clientId!;
      _setupListeners();
    } else {
      throw Exception('Failed to initialize SDK: ${initResult.message}');
    }
  }
  
  void _setupListeners() {
    // Listen to ad events
    _adManager.adStatusStream.listen(_handleAdStatusUpdate);
    _adManager.adRewardStream.listen(_handleRewardUpdate);
  }
  
  Future<bool> canShowAd() async {
    final availability = await _adManager.checkAdAvailability(_clientId);
    return availability.canWatchAds;
  }
  
  Future<void> showRewardedAd() async {
    try {
      // Check availability
      if (!await canShowAd()) {
        print('No ads available');
        return;
      }
      
      // Show your ad
      final adShown = await _showYourAd();
      
      if (adShown) {
        // Process reward through SDK
        final result = await _adManager.watchAd(_clientId);
        
        if (result.success) {
          _showRewardToUser(result.earnings);
        } else {
          _showErrorToUser(result.message);
        }
      }
    } catch (e) {
      _showErrorToUser('Failed to show ad: $e');
    }
  }
  
  Future<bool> _showYourAd() async {
    // Your ad network implementation
    // Return true if ad was successfully shown and completed
    return true;
  }
  
  void _handleAdStatusUpdate(AdStatusUpdate update) {
    print('Ad status update: ${update.type} for tier ${update.tierId}');
  }
  
  void _handleRewardUpdate(AdRewardUpdate reward) {
    print('Reward: ${reward.amount} coins for ${reward.tierName}');
  }
  
  void _showRewardToUser(double amount) {
    // Show reward UI to user
    print('You earned $amount coins!');
  }
  
  void _showErrorToUser(String message) {
    // Show error UI to user
    print('Error: $message');
  }
}
```

### External Ad Network Integration

```dart
class ExternalAdNetworkIntegration {
  final SDKAdManager _adManager = SDKAdManager();
  late String _clientId;
  
  Future<void> onAdCompleted({
    required String adUnitId,
    required String tierId,
    required double rewardAmount,
  }) async {
    try {
      final result = await _adManager.processExternalAdReward(
        clientId: _clientId,
        tierId: tierId,
        rewardAmount: rewardAmount,
        adNetworkId: 'my_ad_network',
        adUnitId: adUnitId,
        metadata: {
          'completion_time': DateTime.now().toIso8601String(),
          'ad_format': 'rewarded_video',
        },
      );
      
      if (result.success) {
        print('External ad reward processed successfully');
      } else {
        print('Failed to process external ad reward: ${result.message}');
      }
    } catch (e) {
      print('Error processing external ad reward: $e');
    }
  }
}
```

## Support

For technical support and questions:

- Email: sdk-support@flurzi.com
- Documentation: https://docs.flurzi.com/sdk
- GitHub Issues: https://github.com/flurzi/mobile-app-sdk/issues

## Changelog

### Version 1.0.0
- Initial SDK release
- Basic ad watching functionality
- Real-time status updates
- External ad network integration
- Comprehensive error handling