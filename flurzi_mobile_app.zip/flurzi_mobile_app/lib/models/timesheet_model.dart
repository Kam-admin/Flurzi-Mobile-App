class TimesheetModel {
  final String id;
  final String userId;
  final String teamId;
  final Map<String, List<String>> availability; // day -> list of time slots
  final DateTime submittedAt;
  final DateTime? lastUpdatedAt;
  final bool isActive;

  TimesheetModel({
    required this.id,
    required this.userId,
    required this.teamId,
    required this.availability,
    required this.submittedAt,
    this.lastUpdatedAt,
    this.isActive = true,
  });

  factory TimesheetModel.fromJson(Map<String, dynamic> json) {
    return TimesheetModel(
      id: json['id'] ?? '',
      userId: json['userId'] ?? '',
      teamId: json['teamId'] ?? '',
      availability: Map<String, List<String>>.from(
        json['availability']?.map(
          (key, value) => MapEntry(key, List<String>.from(value)),
        ) ?? {},
      ),
      submittedAt: DateTime.parse(json['submittedAt']),
      lastUpdatedAt: json['lastUpdatedAt'] != null 
          ? DateTime.parse(json['lastUpdatedAt']) 
          : null,
      isActive: json['isActive'] ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'teamId': teamId,
      'availability': availability,
      'submittedAt': submittedAt.toIso8601String(),
      'lastUpdatedAt': lastUpdatedAt?.toIso8601String(),
      'isActive': isActive,
    };
  }

  TimesheetModel copyWith({
    String? id,
    String? userId,
    String? teamId,
    Map<String, List<String>>? availability,
    DateTime? submittedAt,
    DateTime? lastUpdatedAt,
    bool? isActive,
  }) {
    return TimesheetModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      teamId: teamId ?? this.teamId,
      availability: availability ?? this.availability,
      submittedAt: submittedAt ?? this.submittedAt,
      lastUpdatedAt: lastUpdatedAt ?? this.lastUpdatedAt,
      isActive: isActive ?? this.isActive,
    );
  }

  // Helper methods
  bool hasAvailabilityForDay(String day) {
    return availability.containsKey(day) && availability[day]!.isNotEmpty;
  }

  List<String> getAvailabilityForDay(String day) {
    return availability[day] ?? [];
  }

  int get totalAvailableSlots {
    return availability.values.fold(0, (sum, slots) => sum + slots.length);
  }

  List<String> get availableDays {
    return availability.keys.where((day) => availability[day]!.isNotEmpty).toList();
  }
}

class TimeSlot {
  final String id;
  final String startTime;
  final String endTime;
  final bool isSelected;

  TimeSlot({
    required this.id,
    required this.startTime,
    required this.endTime,
    this.isSelected = false,
  });

  factory TimeSlot.fromJson(Map<String, dynamic> json) {
    return TimeSlot(
      id: json['id'] ?? '',
      startTime: json['startTime'] ?? '',
      endTime: json['endTime'] ?? '',
      isSelected: json['isSelected'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'startTime': startTime,
      'endTime': endTime,
      'isSelected': isSelected,
    };
  }

  TimeSlot copyWith({
    String? id,
    String? startTime,
    String? endTime,
    bool? isSelected,
  }) {
    return TimeSlot(
      id: id ?? this.id,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      isSelected: isSelected ?? this.isSelected,
    );
  }

  String get displayTime => '$startTime - $endTime';
}