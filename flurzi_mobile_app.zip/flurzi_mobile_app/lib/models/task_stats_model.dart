class TaskStatsModel {
  final String id;
  final String userId;
  final String teamId;
  final int tasksCompleted;
  final int adsWatched;
  final double totalEarnings;
  final double bonusEarnings;
  final double averageRating;
  final int fiveStarRatings;
  final DateTime lastActiveAt;
  final Map<String, dynamic> weeklyStats;
  final Map<String, dynamic> monthlyStats;

  TaskStatsModel({
    required this.id,
    required this.userId,
    required this.teamId,
    this.tasksCompleted = 0,
    this.adsWatched = 0,
    this.totalEarnings = 0.0,
    this.bonusEarnings = 0.0,
    this.averageRating = 0.0,
    this.fiveStarRatings = 0,
    required this.lastActiveAt,
    this.weeklyStats = const {},
    this.monthlyStats = const {},
  });

  factory TaskStatsModel.fromJson(Map<String, dynamic> json) {
    return TaskStatsModel(
      id: json['id'] ?? '',
      userId: json['userId'] ?? '',
      teamId: json['teamId'] ?? '',
      tasksCompleted: json['tasksCompleted'] ?? 0,
      adsWatched: json['adsWatched'] ?? 0,
      totalEarnings: (json['totalEarnings'] ?? 0.0).toDouble(),
      bonusEarnings: (json['bonusEarnings'] ?? 0.0).toDouble(),
      averageRating: (json['averageRating'] ?? 0.0).toDouble(),
      fiveStarRatings: json['fiveStarRatings'] ?? 0,
      lastActiveAt: DateTime.parse(json['lastActiveAt']),
      weeklyStats: Map<String, dynamic>.from(json['weeklyStats'] ?? {}),
      monthlyStats: Map<String, dynamic>.from(json['monthlyStats'] ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'teamId': teamId,
      'tasksCompleted': tasksCompleted,
      'adsWatched': adsWatched,
      'totalEarnings': totalEarnings,
      'bonusEarnings': bonusEarnings,
      'averageRating': averageRating,
      'fiveStarRatings': fiveStarRatings,
      'lastActiveAt': lastActiveAt.toIso8601String(),
      'weeklyStats': weeklyStats,
      'monthlyStats': monthlyStats,
    };
  }

  TaskStatsModel copyWith({
    String? id,
    String? userId,
    String? teamId,
    int? tasksCompleted,
    int? adsWatched,
    double? totalEarnings,
    double? bonusEarnings,
    double? averageRating,
    int? fiveStarRatings,
    DateTime? lastActiveAt,
    Map<String, dynamic>? weeklyStats,
    Map<String, dynamic>? monthlyStats,
  }) {
    return TaskStatsModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      teamId: teamId ?? this.teamId,
      tasksCompleted: tasksCompleted ?? this.tasksCompleted,
      adsWatched: adsWatched ?? this.adsWatched,
      totalEarnings: totalEarnings ?? this.totalEarnings,
      bonusEarnings: bonusEarnings ?? this.bonusEarnings,
      averageRating: averageRating ?? this.averageRating,
      fiveStarRatings: fiveStarRatings ?? this.fiveStarRatings,
      lastActiveAt: lastActiveAt ?? this.lastActiveAt,
      weeklyStats: weeklyStats ?? this.weeklyStats,
      monthlyStats: monthlyStats ?? this.monthlyStats,
    );
  }

  // Helper getters
  double get contributionScore {
    // Calculate contribution score based on tasks completed, ads watched, and ratings
    final taskScore = tasksCompleted * 10.0;
    final adScore = adsWatched * 1.0;
    final ratingBonus = averageRating >= 4.5 ? fiveStarRatings * 5.0 : 0.0;
    return taskScore + adScore + ratingBonus;
  }

  bool get isTopPerformer => averageRating >= 4.5 && tasksCompleted >= 10;

  double get weeklyEarnings {
    return (weeklyStats['earnings'] ?? 0.0).toDouble();
  }

  double get monthlyEarnings {
    return (monthlyStats['earnings'] ?? 0.0).toDouble();
  }

  int get weeklyTasksCompleted {
    return weeklyStats['tasksCompleted'] ?? 0;
  }

  int get monthlyTasksCompleted {
    return monthlyStats['tasksCompleted'] ?? 0;
  }
}

class TeamStatsModel {
  final String teamId;
  final String teamName;
  final int totalMembers;
  final double totalEarnings;
  final double weeklyEarnings;
  final List<TaskStatsModel> memberStats;
  final DateTime lastUpdatedAt;

  TeamStatsModel({
    required this.teamId,
    required this.teamName,
    this.totalMembers = 0,
    this.totalEarnings = 0.0,
    this.weeklyEarnings = 0.0,
    this.memberStats = const [],
    required this.lastUpdatedAt,
  });

  factory TeamStatsModel.fromJson(Map<String, dynamic> json) {
    return TeamStatsModel(
      teamId: json['teamId'] ?? '',
      teamName: json['teamName'] ?? '',
      totalMembers: json['totalMembers'] ?? 0,
      totalEarnings: (json['totalEarnings'] ?? 0.0).toDouble(),
      weeklyEarnings: (json['weeklyEarnings'] ?? 0.0).toDouble(),
      memberStats: (json['memberStats'] as List<dynamic>? ?? [])
          .map((stats) => TaskStatsModel.fromJson(stats))
          .toList(),
      lastUpdatedAt: DateTime.parse(json['lastUpdatedAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'teamId': teamId,
      'teamName': teamName,
      'totalMembers': totalMembers,
      'totalEarnings': totalEarnings,
      'weeklyEarnings': weeklyEarnings,
      'memberStats': memberStats.map((stats) => stats.toJson()).toList(),
      'lastUpdatedAt': lastUpdatedAt.toIso8601String(),
    };
  }

  // Helper methods
  List<TaskStatsModel> get topPerformers {
    final sorted = List<TaskStatsModel>.from(memberStats)
      ..sort((a, b) => b.contributionScore.compareTo(a.contributionScore));
    return sorted.take(5).toList();
  }

  TaskStatsModel? getMemberStats(String userId) {
    try {
      return memberStats.firstWhere((stats) => stats.userId == userId);
    } catch (e) {
      return null;
    }
  }

  double get averageRating {
    if (memberStats.isEmpty) return 0.0;
    final totalRating = memberStats.fold(0.0, (sum, stats) => sum + stats.averageRating);
    return totalRating / memberStats.length;
  }

  int get totalTasksCompleted {
    return memberStats.fold(0, (sum, stats) => sum + stats.tasksCompleted);
  }

  int get totalAdsWatched {
    return memberStats.fold(0, (sum, stats) => sum + stats.adsWatched);
  }
}