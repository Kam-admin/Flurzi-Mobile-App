class WithdrawalModel {
  final String id;
  final String userId;
  final String teamId;
  final double amount;
  final String currency;
  final String method; // 'paypal', 'bank_transfer', 'crypto', etc.
  final Map<String, dynamic> methodDetails;
  final String status; // 'pending', 'processing', 'completed', 'failed', 'cancelled'
  final DateTime requestedAt;
  final DateTime? processedAt;
  final DateTime? completedAt;
  final String? transactionId;
  final String? failureReason;
  final double? exchangeRate;
  final double? fees;
  final double? netAmount;

  WithdrawalModel({
    required this.id,
    required this.userId,
    required this.teamId,
    required this.amount,
    required this.currency,
    required this.method,
    this.methodDetails = const {},
    this.status = 'pending',
    required this.requestedAt,
    this.processedAt,
    this.completedAt,
    this.transactionId,
    this.failureReason,
    this.exchangeRate,
    this.fees,
    this.netAmount,
  });

  factory WithdrawalModel.fromJson(Map<String, dynamic> json) {
    return WithdrawalModel(
      id: json['id'] ?? '',
      userId: json['userId'] ?? '',
      teamId: json['teamId'] ?? '',
      amount: (json['amount'] ?? 0.0).toDouble(),
      currency: json['currency'] ?? 'GBP',
      method: json['method'] ?? '',
      methodDetails: Map<String, dynamic>.from(json['methodDetails'] ?? {}),
      status: json['status'] ?? 'pending',
      requestedAt: DateTime.parse(json['requestedAt']),
      processedAt: json['processedAt'] != null 
          ? DateTime.parse(json['processedAt']) 
          : null,
      completedAt: json['completedAt'] != null 
          ? DateTime.parse(json['completedAt']) 
          : null,
      transactionId: json['transactionId'],
      failureReason: json['failureReason'],
      exchangeRate: json['exchangeRate']?.toDouble(),
      fees: json['fees']?.toDouble(),
      netAmount: json['netAmount']?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'teamId': teamId,
      'amount': amount,
      'currency': currency,
      'method': method,
      'methodDetails': methodDetails,
      'status': status,
      'requestedAt': requestedAt.toIso8601String(),
      'processedAt': processedAt?.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'transactionId': transactionId,
      'failureReason': failureReason,
      'exchangeRate': exchangeRate,
      'fees': fees,
      'netAmount': netAmount,
    };
  }

  WithdrawalModel copyWith({
    String? id,
    String? userId,
    String? teamId,
    double? amount,
    String? currency,
    String? method,
    Map<String, dynamic>? methodDetails,
    String? status,
    DateTime? requestedAt,
    DateTime? processedAt,
    DateTime? completedAt,
    String? transactionId,
    String? failureReason,
    double? exchangeRate,
    double? fees,
    double? netAmount,
  }) {
    return WithdrawalModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      teamId: teamId ?? this.teamId,
      amount: amount ?? this.amount,
      currency: currency ?? this.currency,
      method: method ?? this.method,
      methodDetails: methodDetails ?? this.methodDetails,
      status: status ?? this.status,
      requestedAt: requestedAt ?? this.requestedAt,
      processedAt: processedAt ?? this.processedAt,
      completedAt: completedAt ?? this.completedAt,
      transactionId: transactionId ?? this.transactionId,
      failureReason: failureReason ?? this.failureReason,
      exchangeRate: exchangeRate ?? this.exchangeRate,
      fees: fees ?? this.fees,
      netAmount: netAmount ?? this.netAmount,
    );
  }

  // Helper getters
  bool get isPending => status == 'pending';
  bool get isProcessing => status == 'processing';
  bool get isCompleted => status == 'completed';
  bool get isFailed => status == 'failed';
  bool get isCancelled => status == 'cancelled';

  String get statusDisplayText {
    switch (status) {
      case 'pending':
        return 'Pending Review';
      case 'processing':
        return 'Processing';
      case 'completed':
        return 'Completed';
      case 'failed':
        return 'Failed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return 'Unknown';
    }
  }

  String get methodDisplayText {
    switch (method) {
      case 'paypal':
        return 'PayPal';
      case 'bank_transfer':
        return 'Bank Transfer';
      case 'crypto':
        return 'Cryptocurrency';
      case 'gift_card':
        return 'Gift Card';
      default:
        return method;
    }
  }

  Duration? get processingTime {
    if (processedAt != null) {
      return processedAt!.difference(requestedAt);
    }
    return null;
  }

  Duration? get completionTime {
    if (completedAt != null) {
      return completedAt!.difference(requestedAt);
    }
    return null;
  }
}

class BonusWithdrawalModel {
  final String id;
  final String userId;
  final String teamId;
  final double amount;
  final String currency;
  final String reason; // '5_star_bonus', 'performance_bonus', etc.
  final DateTime awardedAt;
  final DateTime? withdrawnAt;
  final bool isWithdrawn;
  final String? withdrawalId;

  BonusWithdrawalModel({
    required this.id,
    required this.userId,
    required this.teamId,
    required this.amount,
    required this.currency,
    required this.reason,
    required this.awardedAt,
    this.withdrawnAt,
    this.isWithdrawn = false,
    this.withdrawalId,
  });

  factory BonusWithdrawalModel.fromJson(Map<String, dynamic> json) {
    return BonusWithdrawalModel(
      id: json['id'] ?? '',
      userId: json['userId'] ?? '',
      teamId: json['teamId'] ?? '',
      amount: (json['amount'] ?? 0.0).toDouble(),
      currency: json['currency'] ?? 'GBP',
      reason: json['reason'] ?? '',
      awardedAt: DateTime.parse(json['awardedAt']),
      withdrawnAt: json['withdrawnAt'] != null 
          ? DateTime.parse(json['withdrawnAt']) 
          : null,
      isWithdrawn: json['isWithdrawn'] ?? false,
      withdrawalId: json['withdrawalId'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'teamId': teamId,
      'amount': amount,
      'currency': currency,
      'reason': reason,
      'awardedAt': awardedAt.toIso8601String(),
      'withdrawnAt': withdrawnAt?.toIso8601String(),
      'isWithdrawn': isWithdrawn,
      'withdrawalId': withdrawalId,
    };
  }

  BonusWithdrawalModel copyWith({
    String? id,
    String? userId,
    String? teamId,
    double? amount,
    String? currency,
    String? reason,
    DateTime? awardedAt,
    DateTime? withdrawnAt,
    bool? isWithdrawn,
    String? withdrawalId,
  }) {
    return BonusWithdrawalModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      teamId: teamId ?? this.teamId,
      amount: amount ?? this.amount,
      currency: currency ?? this.currency,
      reason: reason ?? this.reason,
      awardedAt: awardedAt ?? this.awardedAt,
      withdrawnAt: withdrawnAt ?? this.withdrawnAt,
      isWithdrawn: isWithdrawn ?? this.isWithdrawn,
      withdrawalId: withdrawalId ?? this.withdrawalId,
    );
  }

  // Helper getters
  bool get canWithdraw => !isWithdrawn;
  
  String get reasonDisplayText {
    switch (reason) {
      case '5_star_bonus':
        return '5-Star Rating Bonus';
      case 'performance_bonus':
        return 'Performance Bonus';
      case 'team_bonus':
        return 'Team Achievement Bonus';
      default:
        return reason;
    }
  }

  Duration get timeSinceAwarded {
    return DateTime.now().difference(awardedAt);
  }

  bool get isEligibleForWithdrawal {
    // Can withdraw once per month
    if (isWithdrawn && withdrawnAt != null) {
      final daysSinceWithdrawal = DateTime.now().difference(withdrawnAt!).inDays;
      return daysSinceWithdrawal >= 30;
    }
    return !isWithdrawn;
  }
}