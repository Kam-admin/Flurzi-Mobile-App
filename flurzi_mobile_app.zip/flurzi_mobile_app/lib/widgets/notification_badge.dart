import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../constants/theme.dart';

class NotificationBadge extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  
  const NotificationBadge({
    Key? key,
    required this.child,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, provider, _) {
        final hasNotifications = provider.hasUnreadNotifications;
        final count = provider.unreadNotificationCount;
        
        return GestureDetector(
          onTap: onTap,
          child: Stack(
            children: [
              child,
              if (hasNotifications)
                Positioned(
                  right: 0,
                  top: 0,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: AppTheme.accentColor,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: AppTheme.backgroundColor,
                        width: 2,
                      ),
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 20,
                      minHeight: 20,
                    ),
                    child: Text(
                      count > 99 ? '99+' : count.toString(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class NotificationPanel extends StatelessWidget {
  const NotificationPanel({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, provider, _) {
        final notifications = provider.teamNotifications;
        
        if (notifications.isEmpty) {
          return const Center(
            child: Text(
              'No notifications',
              style: TextStyle(color: Colors.grey),
            ),
          );
        }
        
        return ListView.builder(
          itemCount: notifications.length,
          itemBuilder: (context, index) {
            final notification = notifications[index];
            return NotificationTile(
              notification: notification,
              onTap: () => _handleNotificationTap(context, provider, notification),
            );
          },
        );
      },
    );
  }
  
  void _handleNotificationTap(BuildContext context, AppProvider provider, Map<String, dynamic> notification) {
    // Mark as read
    provider.markNotificationAsRead(notification['id']);
    
    // Handle different notification types
    switch (notification['type']) {
      case 'team_slot_unlock':
        _showSlotUnlockDialog(context, notification);
        break;
      default:
        break;
    }
  }
  
  void _showSlotUnlockDialog(BuildContext context, Map<String, dynamic> notification) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.cardColor,
        title: const Text(
          '🎉 Team Slot Unlocked!',
          style: TextStyle(color: AppTheme.textColor),
        ),
        content: Text(
          'A team member has unlocked the ${notification['slotType']} slot! New features are now available for your team.',
          style: const TextStyle(color: AppTheme.textColor),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text(
              'Awesome!',
              style: TextStyle(color: AppTheme.accentColor),
            ),
          ),
        ],
      ),
    );
  }
}

class NotificationTile extends StatelessWidget {
  final Map<String, dynamic> notification;
  final VoidCallback onTap;
  
  const NotificationTile({
    Key? key,
    required this.notification,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isRead = notification['read'] ?? false;
    final type = notification['type'] ?? '';
    final timestamp = notification['timestamp'];
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: isRead ? AppTheme.cardColor.withOpacity(0.5) : AppTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isRead ? Colors.transparent : AppTheme.accentColor.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: ListTile(
        leading: _getNotificationIcon(type),
        title: Text(
          _getNotificationTitle(type),
          style: TextStyle(
            color: AppTheme.textColor,
            fontWeight: isRead ? FontWeight.normal : FontWeight.bold,
          ),
        ),
        subtitle: Text(
          _getNotificationSubtitle(notification),
          style: TextStyle(
            color: AppTheme.textColor.withOpacity(0.7),
            fontSize: 12,
          ),
        ),
        trailing: !isRead
            ? Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                  color: AppTheme.accentColor,
                  shape: BoxShape.circle,
                ),
              )
            : null,
        onTap: onTap,
      ),
    );
  }
  
  Widget _getNotificationIcon(String type) {
    switch (type) {
      case 'team_slot_unlock':
        return const Icon(
          Icons.lock_open,
          color: AppTheme.accentColor,
        );
      default:
        return const Icon(
          Icons.notifications,
          color: AppTheme.accentColor,
        );
    }
  }
  
  String _getNotificationTitle(String type) {
    switch (type) {
      case 'team_slot_unlock':
        return 'Team Slot Unlocked';
      default:
        return 'Notification';
    }
  }
  
  String _getNotificationSubtitle(Map<String, dynamic> notification) {
    final type = notification['type'] ?? '';
    switch (type) {
      case 'team_slot_unlock':
        final slotType = notification['slotType'] ?? 'Unknown';
        return 'The $slotType slot has been unlocked for your team';
      default:
        return 'You have a new notification';
    }
  }
}