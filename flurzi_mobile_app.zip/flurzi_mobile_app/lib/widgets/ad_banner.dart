import 'package:flutter/material.dart';
import '../constants/theme.dart';

class AdBanner extends StatelessWidget {
  final VoidCallback? onTap;
  final String? adText;
  final bool isLoading;
  
  const AdBanner({
    super.key,
    this.onTap,
    this.adText,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 60,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
          AppTheme.colors.primary.withValues(alpha: 0.1),
          AppTheme.colors.secondary.withValues(alpha: 0.1),
        ],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.colors.primary.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isLoading ? null : onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                // Ad icon
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppTheme.colors.primary.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.play_circle_outline,
                    color: AppTheme.colors.primary,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                
                // Ad content
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        isLoading ? 'Loading ad...' : (adText ?? 'Watch Ad & Earn Rewards'),
                        style: TextStyle(
                          color: AppTheme.colors.text,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        isLoading ? 'Please wait...' : 'Tap to watch and earn coins',
                        style: TextStyle(
                          color: AppTheme.colors.textSecondary,
                          fontSize: 12,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                
                // Loading indicator or arrow
                if (isLoading)
                  SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        AppTheme.colors.primary,
                      ),
                    ),
                  )
                else
                  Icon(
                    Icons.arrow_forward_ios,
                    color: AppTheme.colors.primary,
                    size: 16,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Ad banner specifically for bottom placement
class BottomAdBanner extends StatelessWidget {
  final VoidCallback? onTap;
  final String? adText;
  final bool isLoading;
  
  const BottomAdBanner({
    super.key,
    this.onTap,
    this.adText,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.colors.cardBackground,
        border: Border(
          top: BorderSide(
            color: AppTheme.colors.primary.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        top: false,
        child: AdBanner(
          onTap: onTap,
          adText: adText,
          isLoading: isLoading,
        ),
      ),
    );
  }
}