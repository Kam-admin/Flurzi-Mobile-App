import 'package:flutter/foundation.dart';
import 'dart:async';
import 'package:flutter/material.dart';
// Removed firebase_auth import since the package is not installed
import '../models/user_model.dart';
import '../models/tier_model.dart';
import '../models/team_model.dart';
import '../models/quest_model.dart';
import '../models/timesheet_model.dart';
import '../models/withdrawal_model.dart';
import '../services/firebase_service.dart';
import '../services/team_management_service.dart';
import '../services/ad_monetization_service.dart';
import '../services/currency_service.dart';
import '../services/ad_service.dart';
import '../services/sdk_service.dart';

class AppProvider with ChangeNotifier {
  final FirebaseService _firebaseService = FirebaseService();
  final CurrencyService _currencyService = CurrencyService();
  final AdService _adService = AdService();
  final SDKService _sdkService = SDKService();
  final TeamManagementService _teamManagementService = TeamManagementService();
  final AdMonetizationService _adMonetizationService = AdMonetizationService();
  
  // Real-time streams
  StreamSubscription<UserModel?>? _userStreamSubscription;
  StreamSubscription<TeamModel?>? _teamStreamSubscription;
  StreamSubscription<List<UserModel>>? _teamMembersStreamSubscription;
  StreamSubscription<List<Map<String, dynamic>>>? _notificationsStreamSubscription;
  
  // Team notifications
  List<Map<String, dynamic>> _teamNotifications = [];
  List<UserModel> _teamMembers = [];

  // App state
  bool _isInitialized = false;
  bool _isLoading = false;
  String? _error;

  // User state
  dynamic _firebaseUser;
  UserModel? _user;
  bool _isAuthenticated = false;

  // Tiers state
  List<TierModel> _tiers = [];
  List<TierModel> _userTiers = [];

  // Team state
  TeamModel? _userTeam;
  List<LeaderboardEntry> _leaderboard = [];

  // Quests state
  List<QuestModel> _activeQuests = [];
  List<QuestModel> _completedQuests = [];

  // Ad state
  int _dailyAdsWatched = 0;
  int _offlineAdsCount = 0;
  bool _isOnline = true;

  // SDK state
  bool _isDeveloperMode = false;
  String? _developerToken;
  List<SDKClient> _sdkClients = [];

  // Getters
  bool get isInitialized => _isInitialized;
  bool get isLoading => _isLoading;
  String? get error => _error;
  
  dynamic get firebaseUser => _firebaseUser;
  UserModel? get user => _user;
  bool get isAuthenticated => _isAuthenticated;
  
  List<TierModel> get tiers => _tiers;
  List<TierModel> get userTiers => _userTiers;
  List<TierModel> get unlockedTiers => _userTiers.where((t) => t.isUnlocked).toList();
  List<TierModel> get activeTiers => _userTiers.where((t) => t.isActive).toList();
  
  TeamModel? get userTeam => _userTeam;
  List<LeaderboardEntry> get leaderboard => _leaderboard;
  
  List<QuestModel> get activeQuests => _activeQuests;
  List<QuestModel> get completedQuests => _completedQuests;
  
  int get dailyAdsWatched => _dailyAdsWatched;
  int get offlineAdsCount => _offlineAdsCount;
  bool get isOnline => _isOnline;
  
  bool get isDeveloperMode => _isDeveloperMode;
  String? get developerToken => _developerToken;
  List<SDKClient> get sdkClients => _sdkClients;

  // Computed getters
  double get totalEarnings => _user?.totalEarnings ?? 0.0;
  double get availableBalance => _user?.availableBalance ?? 0.0;
  int get totalAdsWatched => _user?.totalAdsWatched ?? 0;
  bool get hasAutoPlayUpgrade => _user?.hasAutoPlayUpgrade ?? false;
  
  String get userCurrency => _user?.currency ?? 'GBP';
  String get userCountry => _user?.country ?? 'GB';
  
  bool get canWatchMoreAds => _adService.canWatchMoreAds();
  int get remainingAdsToday => _adService.getRemainingAdsToday();
  double get dailyProgress => _adService.getDailyProgress();
  
  // Real-time data getters
  List<Map<String, dynamic>> get teamNotifications => _teamNotifications;
  List<UserModel> get teamMembers => _teamMembers;
  bool get hasUnreadNotifications => _teamNotifications.any((n) => !n['read']);
  int get unreadNotificationCount => _teamNotifications.where((n) => !n['read']).length;

  // Initialize the app
  Future<void> initialize() async {
    if (_isInitialized) return;
    
    _setLoading(true);
    
    try {
      // Initialize services
      await _firebaseService.initialize();
      await _currencyService.initialize();
      await _adService.initialize();
      await _sdkService.initialize();
      
      // Listen to auth state changes
      _firebaseService.authStateChanges.listen(_onAuthStateChanged);
      
      // Update ad state
      _updateAdState();
      
      _isInitialized = true;
      _setError(null);
    } catch (e) {
      _setError('Failed to initialize app: $e');
    } finally {
      _setLoading(false);
    }
  }

  void _onAuthStateChanged(dynamic firebaseUser) async {
    _firebaseUser = firebaseUser;
    _isAuthenticated = firebaseUser != null;
    
    if (firebaseUser != null) {
      await _loadUserData(firebaseUser.uid);
    } else {
      _clearUserData();
    }
    
    notifyListeners();
  }

  Future<void> _loadUserData(String userId) async {
    try {
      _setLoading(true);
      
      // Load user data
      _user = await _firebaseService.getUserData(userId);
      
      if (_user != null) {
        // Load user-specific data
        await Future.wait([
          _loadTiers(),
          _loadUserTeam(),
          _loadQuests(),
          _loadLeaderboard(),
        ]);
        
        // Initialize real-time streams for live updates
        _initializeRealTimeStreams();
        
        // Sync team stats if user is in a team
        if (_user!.teamId != null) {
          await syncTeamStats();
        }
        
        // Update developer mode state
        _isDeveloperMode = _user!.isDeveloperMode;
        _developerToken = _user!.developerToken;
        
        if (_isDeveloperMode) {
          _sdkClients = _sdkService.getUserSDKClients(userId);
        }
      }
      
      _setError(null);
    } catch (e) {
      _setError('Failed to load user data: $e');
    } finally {
      _setLoading(false);
    }
  }

  void _clearUserData() {
    // Dispose real-time streams
    _disposeRealTimeStreams();
    
    _user = null;
    _tiers = [];
    _userTiers = [];
    _userTeam = null;
    _activeQuests = [];
    _completedQuests = [];
    _leaderboard = [];
    _teamNotifications = [];
    _teamMembers = [];
    _isDeveloperMode = false;
    _developerToken = null;
    _sdkClients = [];
  }

  Future<void> _loadTiers() async {
    try {
      _tiers = await _firebaseService.getTiers();
      _updateUserTiers();
    } catch (e) {
      _setError('Error loading tiers: $e');
    }
  }

  void _updateUserTiers() {
    if (_user == null) return;
    
    _userTiers = _tiers.map((tier) {
      final isUnlocked = _user!.unlockedTiers.contains(tier.id);
      final isActive = _user!.activeTiers.contains(tier.id);
      
      return tier.copyWith(
        isUnlocked: isUnlocked,
        isActive: isActive,
      );
    }).toList();
  }

  Future<void> _loadUserTeam() async {
    if (_user?.teamId == null) return;
    
    try {
      _userTeam = await _firebaseService.getTeam(_user!.teamId!);
    } catch (e) {
      _setError('Error loading team: $e');
    }
  }

  Future<void> _loadQuests() async {
    try {
      final quests = await _firebaseService.getActiveQuests();
      
      if (_user != null) {
        _activeQuests = quests.where((q) => !q.isCompletedBy(_user!.id)).toList();
        _completedQuests = quests.where((q) => q.isCompletedBy(_user!.id)).toList();
      } else {
        _activeQuests = quests;
        _completedQuests = [];
      }
    } catch (e) {
      _setError('Error loading quests: $e');
    }
  }

  Future<void> _loadLeaderboard() async {
    try {
      _leaderboard = await _firebaseService.getWeeklyLeaderboard();
    } catch (e) {
      _setError('Error loading leaderboard: $e');
    }
  }

  // Public method to load leaderboard data
  Future<void> loadLeaderboard() async {
    _setLoading(true);
    try {
      await _loadLeaderboard();
      _setError(null);
    } catch (e) {
      _setError('Failed to load leaderboard: $e');
    } finally {
      _setLoading(false);
    }
  }

  void _updateAdState() {
    _dailyAdsWatched = _adService.dailyAdsWatched;
    _offlineAdsCount = _adService.getOfflineAdsCount();
    _isOnline = _adService.isOnline;
  }

  // Authentication methods
  Future<bool> signInWithGoogle() async {
    try {
      _setLoading(true);
      final result = await _firebaseService.signInWithGoogle();
      return result != null;
    } catch (e) {
      _setError('Google sign-in failed: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> signInWithApple() async {
    try {
      _setLoading(true);
      final result = await _firebaseService.signInWithApple();
      return result != null;
    } catch (e) {
      _setError('Apple sign-in failed: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<void> signOut() async {
    try {
      await _firebaseService.signOut();
    } catch (e) {
      _setError('Sign out failed: $e');
    }
  }

  // Tier methods
  Future<bool> unlockTier(String tierId) async {
    if (_user == null) return false;
    
    try {
      _setLoading(true);
      await _firebaseService.unlockTier(_user!.id, tierId);
      await _refreshUserData();
      return true;
    } catch (e) {
      _setError('Failed to unlock tier: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> renewTier(String tierId) async {
    if (_user == null) return false;
    
    try {
      _setLoading(true);
      await _firebaseService.renewTier(_user!.id, tierId);
      await _refreshUserData();
      return true;
    } catch (e) {
      _setError('Failed to renew tier: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Ad watching methods
  Future<AdWatchResult> watchAd([TierModel? tier, bool isAutoPlay = false]) async {
    if (_user == null) {
      return AdWatchResult(
        success: false,
        message: 'User not authenticated',
        earnings: 0.0,
      );
    }
    
    try {
      // If no tier specified, find the best available tier
      TierModel? targetTier = tier;
      if (targetTier == null) {
        targetTier = _findBestTierForAd();
        if (targetTier == null) {
          return AdWatchResult(
            success: false,
            message: 'No active tiers available for ad watching',
            earnings: 0.0,
          );
        }
      }
      
      final result = await _adService.watchAd(_user!.id, targetTier, isAutoPlay: isAutoPlay);
      
      if (result.success) {
        _updateAdState();
        await _refreshUserData();
      }
      
      return result;
    } catch (e) {
      return AdWatchResult(
        success: false,
        message: 'Failed to watch ad: $e',
        earnings: 0.0,
      );
    }
  }
  
  TierModel? _findBestTierForAd() {
    if (_user?.activeTiers.isEmpty ?? true) return null;
    
    // Find the highest earning active tier that can still watch ads
    return _user!.activeTiers
        .where((String tierId) {
          final tier = _tiers.firstWhere((t) => t.id == tierId);
          return tier.isActive && _adService.dailyAdsWatched < tier.dailyAdLimit;
        })
        .fold<TierModel?>(
          null,
          (TierModel? best, String current) {
            final currentTier = _tiers.firstWhere((t) => t.id == current);
            return best == null || currentTier.adEarnings > best.adEarnings
                ? currentTier
                : best;
          },
        );
  }

  // Team methods
  Future<bool> createTeam(String teamName, String description) async {
    if (_user == null) return false;
    
    try {
      _setLoading(true);
      final team = await _firebaseService.createTeam(_user!.id, teamName, description);
      if (team != null) {
        _userTeam = team;
        await _refreshUserData();
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to create team: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> joinTeam(String inviteCode) async {
    if (_user == null) return false;
    
    try {
      _setLoading(true);
      final success = await _firebaseService.joinTeam(_user!.id, inviteCode);
      if (success) {
        await _refreshUserData();
      }
      return success;
    } catch (e) {
      _setError('Failed to join team: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Quest methods
  Future<bool> completeQuest(String questId) async {
    if (_user == null) return false;
    
    try {
      await _firebaseService.completeQuest(_user!.id, questId);
      await _loadQuests();
      await _refreshUserData();
      return true;
    } catch (e) {
      _setError('Failed to complete quest: $e');
      return false;
    }
  }

  // Withdrawal methods
  Future<bool> requestWithdrawal(double amount, String method, Map<String, dynamic> paymentDetails) async {
    if (_user == null) return false;
    
    try {
      final request = WithdrawalRequest(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        userId: _user!.id,
        amount: amount,
        currency: _user!.currency,
        method: method,
        paymentDetails: paymentDetails,
        requestedAt: DateTime.now(),
      );
      
      await _firebaseService.requestWithdrawal(request);
      await _refreshUserData();
      return true;
    } catch (e) {
      _setError('Failed to request withdrawal: $e');
      return false;
    }
  }

  // Developer mode methods
  Future<bool> enableDeveloperMode() async {
    if (_user == null) return false;
    
    try {
      final tokenResult = await _sdkService.generateDeveloperToken(_user!.id);
      if (tokenResult.success) {
        _isDeveloperMode = true;
        _developerToken = tokenResult.token;
        _sdkClients = [tokenResult.client!];
        
        // Update user in database
        final updatedUser = _user!.copyWith(
          isDeveloperMode: true,
          developerToken: tokenResult.token,
        );
        await _firebaseService.createOrUpdateUser(updatedUser);
        _user = updatedUser;
        
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to enable developer mode: $e');
      return false;
    }
  }

  Future<void> disableDeveloperMode() async {
    if (_user == null) return;
    
    try {
      _isDeveloperMode = false;
      _developerToken = null;
      _sdkClients = [];
      
      // Revoke all SDK clients
      for (final client in _sdkClients) {
        await _sdkService.revokeAccess(client.clientId);
      }
      
      // Update user in database
      final updatedUser = _user!.copyWith(
        isDeveloperMode: false,
        developerToken: null,
      );
      await _firebaseService.createOrUpdateUser(updatedUser);
      _user = updatedUser;
      
      notifyListeners();
    } catch (e) {
      _setError('Failed to disable developer mode: $e');
    }
  }

  // Team member functionality
  Future<void> updateUserAvailability(Map<String, Map<String, bool>> availability) async {
    if (_user == null) throw Exception('User not authenticated');
    
    try {
      // Update user preferences with availability
      final updatedPreferences = Map<String, dynamic>.from(_user!.preferences);
      updatedPreferences['availability'] = availability;
      
      final updatedUser = _user!.copyWith(preferences: updatedPreferences);
      await _firebaseService.createOrUpdateUser(updatedUser);
      _user = updatedUser;
      
      notifyListeners();
    } catch (e) {
      throw Exception('Failed to update availability: $e');
    }
  }
  
  Future<void> processWithdrawal({
    required double amount,
    required String currency,
    required String method,
    required String accountDetails,
  }) async {
    if (_user == null) throw Exception('User not authenticated');
    
    try {
      // Create withdrawal request
      final withdrawalData = {
        'userId': _user!.id,
        'amount': amount,
        'currency': currency,
        'method': method,
        'accountDetails': accountDetails,
        'status': 'pending',
        'createdAt': DateTime.now().toIso8601String(),
      };
      
      // Submit withdrawal request to backend
      await _firebaseService.createWithdrawalRequest(withdrawalData);
      
      // Update user balance
      final updatedUser = _user!.copyWith(
        totalEarnings: _user!.totalEarnings - amount,
      );
      await _firebaseService.createOrUpdateUser(updatedUser);
      _user = updatedUser;
      
      notifyListeners();
    } catch (e) {
      throw Exception('Failed to process withdrawal: $e');
    }
  }
  
  Future<void> withdrawBonus() async {
    if (_user == null) throw Exception('User not authenticated');
    
    try {
      final bonusBalance = _user!.preferences['bonusBalance']?.toDouble() ?? 0;
      if (bonusBalance <= 0) {
        throw Exception('No bonus balance available');
      }
      
      // Check if user can withdraw bonus (once per month)
      final lastWithdrawal = _user!.preferences['lastBonusWithdrawal'];
      if (lastWithdrawal != null) {
        final lastDate = DateTime.parse(lastWithdrawal);
        final daysSince = DateTime.now().difference(lastDate).inDays;
        if (daysSince < 30) {
          throw Exception('Bonus can only be withdrawn once per month');
        }
      }
      
      // Transfer bonus to available balance
      final updatedPreferences = Map<String, dynamic>.from(_user!.preferences);
      updatedPreferences['bonusBalance'] = 0.0;
      updatedPreferences['lastBonusWithdrawal'] = DateTime.now().toIso8601String();
      
      final updatedUser = _user!.copyWith(
        totalEarnings: _user!.totalEarnings + bonusBalance,
        preferences: updatedPreferences,
      );
      
      await _firebaseService.createOrUpdateUser(updatedUser);
      _user = updatedUser;
      
      notifyListeners();
    } catch (e) {
      throw Exception('Failed to withdraw bonus: $e');
    }
  }
  
  Future<void> awardFiveStarBonus(String memberId) async {
    if (_user == null) throw Exception('User not authenticated');
    
    try {
      // Get the team member
      final memberData = await _firebaseService.getUserData(memberId);
      if (memberData == null) {
        throw Exception('Member not found');
      }
      
      // Add £5 bonus to member's bonus balance
      final updatedPreferences = Map<String, dynamic>.from(memberData.preferences);
      final currentBonus = updatedPreferences['bonusBalance']?.toDouble() ?? 0;
      updatedPreferences['bonusBalance'] = currentBonus + 5.0;
      
      final updatedMember = memberData.copyWith(preferences: updatedPreferences);
      await _firebaseService.createOrUpdateUser(updatedMember);
      
      // Record the bonus award
      await _firebaseService.recordBonusAward({
        'memberId': memberId,
        'amount': 5.0,
        'reason': '5-star rating',
        'awardedBy': _user!.id,
        'awardedAt': DateTime.now().toIso8601String(),
      });
      
      notifyListeners();
    } catch (e) {
      throw Exception('Failed to award bonus: $e');
    }
  }
  
  Future<void> registerTeamMember({
    required String name,
    required String email,
    required String phone,
    required String inviteCode,
  }) async {
    try {
      await _teamManagementService.registerNewMember(
        name: name,
        email: email,
        phone: phone,
        inviteCode: inviteCode,
      );
    } catch (e) {
      throw Exception('Failed to register team member: $e');
    }
  }
  
  Future<bool> validateTeamCode(String teamCode) async {
    try {
      final team = await _firebaseService.getTeamByInviteCode(teamCode);
      return team != null;
    } catch (e) {
      return false;
    }
  }
  
  Future<void> submitTimesheet(TimesheetModel timesheet) async {
    try {
      await _teamManagementService.submitTimesheet(timesheet);
      notifyListeners();
    } catch (e) {
      throw Exception('Failed to submit timesheet: $e');
    }
  }
  
  Future<void> processWithdrawal(WithdrawalModel withdrawal) async {
    try {
      await _teamManagementService.processWithdrawalRequest(withdrawal);
      await _refreshUserData();
    } catch (e) {
      throw Exception('Failed to process withdrawal: $e');
    }
  }

  // Utility methods
  Future<void> refreshUserData() async {
    if (_user != null) {
      await _loadUserData(_user!.id);
    }
  }

  Future<void> _refreshUserData() async {
    if (_user != null) {
      _user = await _firebaseService.getUserData(_user!.id);
      _updateUserTiers();
      notifyListeners();
    }
  }

  Future<void> refreshCurrencyRates() async {
    await _currencyService.refreshRates();
    notifyListeners();
  }

  Future<void> syncOfflineAds() async {
    final success = await _adService.forceSyncOfflineAds();
    if (success) {
      _updateAdState();
      await _refreshUserData();
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String? error) {
    _error = error;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  // Real-time communication methods
  void _initializeRealTimeStreams() {
    if (_user?.id == null) return;
    
    // Listen to user updates
    _userStreamSubscription = _firebaseService.getUserStream(_user!.id).listen(
      (user) {
        if (user != null) {
          _user = user;
          notifyListeners();
        }
      },
      onError: (error) => print('User stream error: $error'),
    );
    
    // Listen to team updates if user is in a team
    if (_user?.teamId != null) {
      _teamStreamSubscription = _firebaseService.getTeamStream(_user!.teamId!).listen(
        (team) {
          if (team != null) {
            _userTeam = team;
            notifyListeners();
          }
        },
        onError: (error) => print('Team stream error: $error'),
      );
      
      // Listen to team members
      _teamMembersStreamSubscription = _firebaseService.getTeamMembersStream(_user!.teamId!).listen(
        (members) {
          _teamMembers = members;
          notifyListeners();
        },
        onError: (error) => print('Team members stream error: $error'),
      );
      
      // Listen to team notifications
      _notificationsStreamSubscription = _firebaseService.getTeamNotificationsStream(_user!.teamId!).listen(
        (notifications) {
          _teamNotifications = notifications;
          notifyListeners();
        },
        onError: (error) => print('Notifications stream error: $error'),
      );
    }
  }
  
  void _disposeRealTimeStreams() {
    _userStreamSubscription?.cancel();
    _teamStreamSubscription?.cancel();
    _teamMembersStreamSubscription?.cancel();
    _notificationsStreamSubscription?.cancel();
  }
  
  // Team slot unlock functionality
  Future<void> unlockTeamSlot(String slotType) async {
    if (_user?.teamId == null) {
      _setError('User is not in a team');
      return;
    }
    
    _setLoading(true);
    try {
      // Notify team members about slot unlock
      await _firebaseService.notifyTeamSlotUnlock(
        _user!.teamId!,
        _user!.id,
        slotType,
      );
      
      // Update local team data
      if (_userTeam != null) {
        // This will be updated via real-time stream
        print('Team slot $slotType unlocked successfully');
      }
      
      _setError(null);
    } catch (e) {
      _setError('Failed to unlock team slot: $e');
    } finally {
      _setLoading(false);
    }
  }
  
  // Mark notification as read
  Future<void> markNotificationAsRead(String notificationId) async {
    try {
      await _firebaseService.markNotificationAsRead(notificationId);
      // Update will come through real-time stream
    } catch (e) {
      print('Error marking notification as read: $e');
    }
  }
  
  // Sync team stats in real-time
  Future<void> syncTeamStats() async {
    if (_user?.teamId == null) return;
    
    try {
      final stats = await _teamManagementService.getTeamStats(_user!.teamId!);
      await _firebaseService.syncTeamStats(_user!.teamId!, stats);
    } catch (e) {
      print('Error syncing team stats: $e');
    }
  }

  @override
  void dispose() {
    _disposeRealTimeStreams();
    _firebaseService.disposeListeners();
    _adService.dispose();
    super.dispose();
  }
}