import 'package:flutter/material.dart';

class AppTheme {
  static const colors = AppColors();
  static const spacing = AppSpacing();
  static const borderRadius = AppBorderRadius();
  static final shadows = AppShadows();
  static const fonts = AppFonts();
}

class AppColors {
  const AppColors();
  
  final primary = const Color(0xFF2563EB);
  final secondary = const Color(0xFF9333EA);
  final background = Colors.black;
  final surface = const Color(0xFF1F2937);
  final cardBackground = const Color(0xFF374151);
  final border = const Color(0xFF4B5563);
  final text = Colors.white;
  final textSecondary = Colors.white70;
  final error = const Color(0xFFDC2626);
  final success = const Color(0xFF22C55E);
  final warning = const Color(0xFFF59E0B);
}

class AppSpacing {
  const AppSpacing();
  
  final double xs = 4.0;
  final double sm = 8.0;
  final double md = 16.0;
  final double lg = 24.0;
  final double xl = 32.0;
}

class AppBorderRadius {
  const AppBorderRadius();
  
  final double small = 4.0;
  final double sm = 4.0;
  final double medium = 8.0;
  final double md = 8.0;
  final double large = 16.0;
  final double lg = 16.0;
  final double xl = 24.0;
}

class AppShadows {
  final primary = [
    BoxShadow(
      color: Colors.blue.withValues(alpha: 0.3),
      blurRadius: 8,
      spreadRadius: 2,
    ),
  ];

  final secondary = [
    BoxShadow(
      color: Colors.purple.withValues(alpha: 0.3),
      blurRadius: 8,
      spreadRadius: 2,
    ),
  ];

  final small = [
    BoxShadow(
      color: Colors.black.withValues(alpha: 0.1),
      blurRadius: 4,
      spreadRadius: 1,
    ),
  ];

  final medium = [
    BoxShadow(
      color: Colors.black.withValues(alpha: 0.2),
      blurRadius: 8,
      spreadRadius: 2,
    ),
  ];

  final large = [
    BoxShadow(
      color: Colors.black.withValues(alpha: 0.3),
      blurRadius: 16,
      spreadRadius: 4,
    ),
  ];
}

class AppFonts {
  const AppFonts();
  
  final String primary = 'Orbitron';
  final String secondary = 'Rajdhani';
}