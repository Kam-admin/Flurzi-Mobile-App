import 'dart:async';
import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../providers/app_provider.dart';
import 'firebase_service.dart';

class AdMonetizationService {
  static final AdMonetizationService _instance = AdMonetizationService._internal();
  factory AdMonetizationService() => _instance;
  AdMonetizationService._internal();

  final FirebaseService _firebaseService = FirebaseService();
  
  // Ad tracking
  int _adsWatchedToday = 0;
  DateTime _lastAdDate = DateTime.now();
  bool _isAutoPlayEnabled = false;
  Timer? _autoPlayTimer;
  
  // Anti-cheat system
  final Map<String, DateTime> _adInteractionTimes = {};
  final Map<String, int> _adSkipCounts = {};
  
  // Constants
  static const int maxDailyAds = 100;
  static const double adRewardAmount = 0.01; // £0.01 per ad
  static const double autoPlayFeaturePrice = 5.99;
  static const int autoPlayCountdownSeconds = 5;
  static const int teamMemberAutoPlayThreshold = 150; // ads needed for team members

  // Initialize service
  void initialize() {
    _resetDailyCountIfNeeded();
  }

  // Check if user can watch ads
  bool canWatchAd(UserModel user) {
    _resetDailyCountIfNeeded();
    
    if (_adsWatchedToday >= maxDailyAds) {
      return false;
    }
    
    // Check for suspicious activity
    if (_isSuspiciousActivity(user.id)) {
      return false;
    }
    
    return true;
  }

  // Watch a rewarded ad
  Future<AdWatchResult> watchRewardedAd({
    required UserModel user,
    required AppProvider appProvider,
    bool isAutoPlay = false,
  }) async {
    if (!canWatchAd(user)) {
      return AdWatchResult(
        success: false,
        message: 'Daily ad limit reached or suspicious activity detected',
      );
    }

    try {
      // Record ad interaction start time
      _adInteractionTimes[user.id] = DateTime.now();
      
      // Simulate ad loading and display
      await _simulateAdDisplay(isAutoPlay: isAutoPlay);
      
      // Validate ad completion
      if (!_validateAdCompletion(user.id)) {
        return AdWatchResult(
          success: false,
          message: 'Ad was not completed properly',
        );
      }
      
      // Award earnings
      await _awardAdEarnings(user, appProvider);
      
      // Update counters
      _adsWatchedToday++;
      
      // Check for auto-play eligibility
      if (!isAutoPlay && _shouldShowAutoPlayOption(user)) {
        return AdWatchResult(
          success: true,
          message: 'Ad completed successfully',
          showAutoPlayOption: true,
        );
      }
      
      return AdWatchResult(
        success: true,
        message: 'Ad completed successfully',
        earnedAmount: adRewardAmount,
      );
      
    } catch (e) {
      return AdWatchResult(
        success: false,
        message: 'Failed to load ad: $e',
      );
    }
  }

  // Start auto-play countdown
  Future<bool> startAutoPlayCountdown({
    required UserModel user,
    required AppProvider appProvider,
    required VoidCallback onCountdownComplete,
  }) async {
    if (!_canUseAutoPlay(user)) {
      return false;
    }
    
    // Start 5-second countdown
    int countdown = autoPlayCountdownSeconds;
    _autoPlayTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      countdown--;
      if (countdown <= 0) {
        timer.cancel();
        onCountdownComplete();
        // Automatically play next ad
        watchRewardedAd(
          user: user,
          appProvider: appProvider,
          isAutoPlay: true,
        );
      }
    });
    
    return true;
  }

  // Cancel auto-play countdown
  void cancelAutoPlayCountdown() {
    _autoPlayTimer?.cancel();
    _autoPlayTimer = null;
  }

  // Check if user can use auto-play feature
  bool _canUseAutoPlay(UserModel user) {
    // Team members need to watch 150 ads OR team owner has the feature
    if (user.teamRole == 'member') {
      return _adsWatchedToday >= teamMemberAutoPlayThreshold || user.hasAutoPlayUpgrade;
    }
    
    // Regular users and team owners need to purchase the feature
    return user.hasAutoPlayUpgrade;
  }

  // Check if should show auto-play option
  bool _shouldShowAutoPlayOption(UserModel user) {
    return _canUseAutoPlay(user);
  }

  // Simulate ad display (replace with actual ad SDK integration)
  Future<void> _simulateAdDisplay({bool isAutoPlay = false}) async {
    // Simulate ad loading time
    await Future.delayed(Duration(seconds: isAutoPlay ? 1 : 2));
    
    // Simulate ad display duration
    await Future.delayed(Duration(seconds: isAutoPlay ? 15 : 30));
  }

  // Validate ad completion (anti-cheat)
  bool _validateAdCompletion(String userId) {
    final startTime = _adInteractionTimes[userId];
    if (startTime == null) return false;
    
    final duration = DateTime.now().difference(startTime);
    
    // Ad must be watched for at least 15 seconds
    if (duration.inSeconds < 15) {
      _recordSuspiciousActivity(userId);
      return false;
    }
    
    // Check for rapid successive ad watching (bot behavior)
    if (duration.inSeconds < 20) {
      final skipCount = _adSkipCounts[userId] ?? 0;
      _adSkipCounts[userId] = skipCount + 1;
      
      if (skipCount > 3) {
        _recordSuspiciousActivity(userId);
        return false;
      }
    }
    
    return true;
  }

  // Award earnings for ad completion
  Future<void> _awardAdEarnings(UserModel user, AppProvider appProvider) async {
    try {
      // Add earnings to user account
      await _firebaseService.addUserEarnings(user.id, adRewardAmount);
      
      // Update local state
      await appProvider.refreshUserData();
      
      // Log analytics
      await _firebaseService.logEvent('ad_completed', {
        'userId': user.id,
        'amount': adRewardAmount,
        'adsWatchedToday': _adsWatchedToday,
      });
      
    } catch (e) {
      print('Error awarding ad earnings: $e');
    }
  }

  // Anti-cheat: Check for suspicious activity
  bool _isSuspiciousActivity(String userId) {
    final skipCount = _adSkipCounts[userId] ?? 0;
    return skipCount > 5; // Threshold for suspicious activity
  }

  // Record suspicious activity
  void _recordSuspiciousActivity(String userId) {
    _firebaseService.logEvent('suspicious_ad_activity', {
      'userId': userId,
      'timestamp': DateTime.now().toIso8601String(),
      'adsWatchedToday': _adsWatchedToday,
    });
  }

  // Reset daily counters if needed
  void _resetDailyCountIfNeeded() {
    final now = DateTime.now();
    if (!_isSameDay(_lastAdDate, now)) {
      _adsWatchedToday = 0;
      _lastAdDate = now;
      _adSkipCounts.clear();
    }
  }

  // Check if two dates are the same day
  bool _isSameDay(DateTime date1, DateTime date2) {
    return date1.year == date2.year &&
           date1.month == date2.month &&
           date1.day == date2.day;
  }

  // Purchase auto-play feature
  Future<bool> purchaseAutoPlayFeature(UserModel user, AppProvider appProvider) async {
    try {
      // Simulate payment processing
      await Future.delayed(const Duration(seconds: 2));
      
      // Update user's auto-play status
      // This would typically involve a backend call to process payment
      // and update the user's subscription status
      
      await _firebaseService.logEvent('autoplay_purchased', {
        'userId': user.id,
        'amount': autoPlayFeaturePrice,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      return true;
    } catch (e) {
      print('Error purchasing auto-play feature: $e');
      return false;
    }
  }

  // Getters
  int get adsWatchedToday => _adsWatchedToday;
  int get remainingAdsToday => maxDailyAds - _adsWatchedToday;
  bool get isAutoPlayActive => _autoPlayTimer?.isActive ?? false;

  // Dispose
  void dispose() {
    _autoPlayTimer?.cancel();
  }
}

class AdWatchResult {
  final bool success;
  final String message;
  final double? earnedAmount;
  final bool showAutoPlayOption;

  AdWatchResult({
    required this.success,
    required this.message,
    this.earnedAmount,
    this.showAutoPlayOption = false,
  });
}