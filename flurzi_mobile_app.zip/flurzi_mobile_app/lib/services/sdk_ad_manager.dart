library;

import 'package:flutter/material.dart';
import 'dart:async';
import 'ad_service.dart';
import 'firebase_service.dart';
import 'sdk_service.dart';

/// SDK Ad Manager - Main interface for external ad network integration
/// This class provides a simplified API for external plugins to integrate
/// with the Flurzi Mobile App's ad system
class SDKAdManager {
  static final SDKAdManager _instance = SDKAdManager._internal();
  factory SDKAdManager() => _instance;
  SDKAdManager._internal();

  final AdService _adService = AdService();
  final FirebaseService _firebaseService = FirebaseService();
  final SDKService _sdkService = SDKService();

  // Stream controllers for real-time updates
  final StreamController<AdStatusUpdate> _adStatusController = StreamController<AdStatusUpdate>.broadcast();
  final StreamController<AdRewardUpdate> _adRewardController = StreamController<AdRewardUpdate>.broadcast();

  // Public streams for external plugins
  Stream<AdStatusUpdate> get adStatusStream => _adStatusController.stream;
  Stream<AdRewardUpdate> get adRewardStream => _adRewardController.stream;

  /// Initialize the SDK Ad Manager with client credentials
  Future<SDKInitResult> initialize({
    required String clientId,
    required String clientSecret,
    String? userId,
  }) async {
    try {
      // Validate SDK client
      final validation = await _sdkService.validateToken(clientId);
      if (!validation.isValid) {
        return SDKInitResult(
          success: false,
          message: 'Invalid SDK credentials: ${validation.message}',
        );
      }

      // Initialize ad service
      await _adService.initialize();

      return SDKInitResult(
        success: true,
        message: 'SDK Ad Manager initialized successfully',
        clientId: clientId,
        userId: validation.userId,
      );
    } catch (e) {
      return SDKInitResult(
        success: false,
        message: 'Failed to initialize SDK: $e',
      );
    }
  }

  /// Check if ads can be watched
  Future<AdAvailabilityResult> checkAdAvailability(String clientId) async {
    try {
      final validation = await _sdkService.validateToken(clientId);
      if (!validation.isValid) {
        throw Exception('Invalid client ID');
      }

      final user = await _firebaseService.getUserData(validation.userId!);
      if (user == null) {
        throw Exception('User not found');
      }

      final availableTiers = user.activeTiers
          .where((tier) => tier.isActive && tier.adsWatched < tier.adsRequired)
          .toList();

      final canWatchAds = _adService.canWatchMoreAds() && availableTiers.isNotEmpty;

      return AdAvailabilityResult(
        canWatchAds: canWatchAds,
        availableTierCount: availableTiers.length,
        dailyAdsWatched: _adService.dailyAdsWatched,
        maxDailyAds: 50,
        nextAdAvailableIn: canWatchAds ? Duration.zero : Duration(minutes: 1),
        availableTiers: availableTiers.map((tier) => AdTierInfo(
          id: tier.id,
          name: tier.name,
          adsWatched: tier.adsWatched,
          adsRequired: tier.adsRequired,
          rewardPerAd: tier.dailyEarnings / tier.adsRequired,
          progress: tier.adsWatched / tier.adsRequired,
        )).toList(),
      );
    } catch (e) {
      return AdAvailabilityResult(
        canWatchAds: false,
        availableTierCount: 0,
        dailyAdsWatched: 0,
        maxDailyAds: 50,
        nextAdAvailableIn: Duration(hours: 24),
        error: e.toString(),
      );
    }
  }

  /// Watch an ad for a specific tier
  Future<AdWatchResult> watchAd(String clientId, {String? tierId}) async {
    try {
      final result = await _sdkService.watchAdViaSDK(clientId, tierId: tierId);
      
      final adResult = AdWatchResult(
        success: result['success'] ?? false,
        message: result['message'] ?? '',
        earnings: result['earnings']?.toDouble() ?? 0.0,
        tierId: result['tierId'] ?? '',
        tierName: result['tierName'] ?? '',
        adsWatched: result['adsWatched'] ?? 0,
        adsRequired: result['adsRequired'] ?? 0,
      );

      // Emit status update
      _adStatusController.add(AdStatusUpdate(
        type: AdStatusType.adWatched,
        tierId: adResult.tierId,
        adsWatched: adResult.adsWatched,
        adsRequired: adResult.adsRequired,
      ));

      // Emit reward update
      if (adResult.success && adResult.earnings > 0) {
        _adRewardController.add(AdRewardUpdate(
          amount: adResult.earnings,
          tierId: adResult.tierId,
          tierName: adResult.tierName,
          timestamp: DateTime.now(),
        ));
      }

      return adResult;
    } catch (e) {
      return AdWatchResult(
        success: false,
        message: 'Failed to watch ad: $e',
        earnings: 0.0,
      );
    }
  }

  /// Get current ad status
  Future<AdStatusResult> getAdStatus(String clientId) async {
    try {
      final result = await _sdkService.getAdStatus(clientId);
      
      return AdStatusResult(
        totalAdsWatched: result['totalAdsWatched'] ?? 0,
        weeklyAdsWatched: result['weeklyAdsWatched'] ?? 0,
        availableTiers: (result['availableTiers'] as List? ?? [])
            .map((tier) => AdTierInfo(
              id: tier['id'] ?? '',
              name: tier['name'] ?? '',
              adsWatched: tier['adsWatched'] ?? 0,
              adsRequired: tier['adsRequired'] ?? 0,
              rewardPerAd: tier['dailyEarnings']?.toDouble() ?? 0.0,
              progress: tier['progress']?.toDouble() ?? 0.0,
            ))
            .toList(),
      );
    } catch (e) {
      return AdStatusResult(
        totalAdsWatched: 0,
        weeklyAdsWatched: 0,
        availableTiers: [],
        error: e.toString(),
      );
    }
  }

  /// Process external ad reward (for when ads are shown by external networks)
  Future<AdRewardResult> processExternalAdReward({
    required String clientId,
    required String tierId,
    required double rewardAmount,
    String? adNetworkId,
    String? adUnitId,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      // Validate the reward
      final availability = await checkAdAvailability(clientId);
      if (!availability.canWatchAds) {
        throw Exception('No ads available for watching');
      }

      final targetTier = availability.availableTiers.firstWhere(
        (tier) => tier.id == tierId,
        orElse: () => throw Exception('Tier not found or not available'),
      );

      // Validate reward amount (should not exceed expected reward)
      if (rewardAmount > targetTier.rewardPerAd * 1.1) {
        throw Exception('Reward amount exceeds expected value');
      }

      // Process the reward
      final validation = await _sdkService.validateToken(clientId);
      if (!validation.isValid) {
        throw Exception('Invalid client ID');
      }

      await _firebaseService.addUserEarnings(validation.userId!, rewardAmount);
      await _firebaseService.incrementTierAdCount(validation.userId!, tierId);

      // Emit updates
      _adStatusController.add(AdStatusUpdate(
        type: AdStatusType.externalAdRewarded,
        tierId: tierId,
        adsWatched: targetTier.adsWatched + 1,
        adsRequired: targetTier.adsRequired,
      ));

      _adRewardController.add(AdRewardUpdate(
        amount: rewardAmount,
        tierId: tierId,
        tierName: targetTier.name,
        timestamp: DateTime.now(),
        isExternal: true,
        adNetworkId: adNetworkId,
        adUnitId: adUnitId,
        metadata: metadata,
      ));

      return AdRewardResult(
        success: true,
        message: 'External ad reward processed successfully',
        rewardAmount: rewardAmount,
        tierId: tierId,
      );
    } catch (e) {
      return AdRewardResult(
        success: false,
        message: 'Failed to process external ad reward: $e',
        rewardAmount: 0.0,
      );
    }
  }

  /// Get ad configuration for external networks
  Future<AdConfigResult> getAdConfiguration(String clientId) async {
    try {
      final result = await _sdkService.getAdConfiguration(clientId);
      
      return AdConfigResult(
        maxDailyAds: result['maxDailyAds'] ?? 50,
        adCooldownMinutes: result['adCooldownMinutes'] ?? 1,
        supportedAdTypes: List<String>.from(result['supportedAdTypes'] ?? []),
        adNetworks: List<String>.from(result['adNetworks'] ?? []),
        rewardMultiplier: result['adRewardMultiplier']?.toDouble() ?? 1.0,
      );
    } catch (e) {
      return AdConfigResult(
        maxDailyAds: 50,
        adCooldownMinutes: 1,
        supportedAdTypes: ['rewarded'],
        adNetworks: ['admob'],
        rewardMultiplier: 1.0,
        error: e.toString(),
      );
    }
  }

  /// Dispose resources
  void dispose() {
    _adStatusController.close();
    _adRewardController.close();
  }
}

// Data classes for SDK responses

class SDKInitResult {
  final bool success;
  final String message;
  final String? clientId;
  final String? userId;

  SDKInitResult({
    required this.success,
    required this.message,
    this.clientId,
    this.userId,
  });
}

class AdAvailabilityResult {
  final bool canWatchAds;
  final int availableTierCount;
  final int dailyAdsWatched;
  final int maxDailyAds;
  final Duration nextAdAvailableIn;
  final List<AdTierInfo> availableTiers;
  final String? error;

  AdAvailabilityResult({
    required this.canWatchAds,
    required this.availableTierCount,
    required this.dailyAdsWatched,
    required this.maxDailyAds,
    required this.nextAdAvailableIn,
    this.availableTiers = const [],
    this.error,
  });
}

class AdTierInfo {
  final String id;
  final String name;
  final int adsWatched;
  final int adsRequired;
  final double rewardPerAd;
  final double progress;

  AdTierInfo({
    required this.id,
    required this.name,
    required this.adsWatched,
    required this.adsRequired,
    required this.rewardPerAd,
    required this.progress,
  });
}

class AdWatchResult {
  final bool success;
  final String message;
  final double earnings;
  final String tierId;
  final String tierName;
  final int adsWatched;
  final int adsRequired;

  AdWatchResult({
    required this.success,
    required this.message,
    required this.earnings,
    this.tierId = '',
    this.tierName = '',
    this.adsWatched = 0,
    this.adsRequired = 0,
  });
}

class AdStatusResult {
  final int totalAdsWatched;
  final int weeklyAdsWatched;
  final List<AdTierInfo> availableTiers;
  final String? error;

  AdStatusResult({
    required this.totalAdsWatched,
    required this.weeklyAdsWatched,
    required this.availableTiers,
    this.error,
  });
}

class AdRewardResult {
  final bool success;
  final String message;
  final double rewardAmount;
  final String tierId;

  AdRewardResult({
    required this.success,
    required this.message,
    required this.rewardAmount,
    this.tierId = '',
  });
}

class AdConfigResult {
  final int maxDailyAds;
  final int adCooldownMinutes;
  final List<String> supportedAdTypes;
  final List<String> adNetworks;
  final double rewardMultiplier;
  final String? error;

  AdConfigResult({
    required this.maxDailyAds,
    required this.adCooldownMinutes,
    required this.supportedAdTypes,
    required this.adNetworks,
    required this.rewardMultiplier,
    this.error,
  });
}

// Event classes for streams

class AdStatusUpdate {
  final AdStatusType type;
  final String tierId;
  final int adsWatched;
  final int adsRequired;
  final DateTime timestamp;

  AdStatusUpdate({
    required this.type,
    required this.tierId,
    required this.adsWatched,
    required this.adsRequired,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();
}

class AdRewardUpdate {
  final double amount;
  final String tierId;
  final String tierName;
  final DateTime timestamp;
  final bool isExternal;
  final String? adNetworkId;
  final String? adUnitId;
  final Map<String, dynamic>? metadata;

  AdRewardUpdate({
    required this.amount,
    required this.tierId,
    required this.tierName,
    required this.timestamp,
    this.isExternal = false,
    this.adNetworkId,
    this.adUnitId,
    this.metadata,
  });
}

enum AdStatusType {
  adWatched,
  externalAdRewarded,
  tierCompleted,
  dailyLimitReached,
}