import 'dart:async';
import 'package:flutter/foundation.dart';
import 'firebase_service.dart';
import 'team_management_service.dart';
import 'ad_monetization_service.dart';
import 'currency_service.dart';
import '../models/user_model.dart';
import '../models/team_model.dart';

class RealTimeSyncService {
  static final RealTimeSyncService _instance = RealTimeSyncService._internal();
  factory RealTimeSyncService() => _instance;
  RealTimeSyncService._internal();

  final FirebaseService _firebaseService = FirebaseService();
  final TeamManagementService _teamManagementService = TeamManagementService();
  final AdMonetizationService _adMonetizationService = AdMonetizationService();
  final CurrencyService _currencyService = CurrencyService();

  // Stream controllers for real-time updates
  final StreamController<UserModel> _userUpdateController = StreamController<UserModel>.broadcast();
  final StreamController<TeamModel> _teamUpdateController = StreamController<TeamModel>.broadcast();
  final StreamController<Map<String, dynamic>> _teamSlotUnlockController = StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<List<Map<String, dynamic>>> _notificationController = StreamController<List<Map<String, dynamic>>>.broadcast();

  // Getters for streams
  Stream<UserModel> get userUpdates => _userUpdateController.stream;
  Stream<TeamModel> get teamUpdates => _teamUpdateController.stream;
  Stream<Map<String, dynamic>> get teamSlotUnlocks => _teamSlotUnlockController.stream;
  Stream<List<Map<String, dynamic>>> get notifications => _notificationController.stream;

  // Active subscriptions
  StreamSubscription<UserModel?>? _userSubscription;
  StreamSubscription<TeamModel?>? _teamSubscription;
  StreamSubscription<List<Map<String, dynamic>>>? _notificationSubscription;

  bool _isInitialized = false;
  String? _currentUserId;
  String? _currentTeamId;

  // Initialize real-time sync for a user
  Future<void> initialize(String userId) async {
    if (_isInitialized && _currentUserId == userId) return;

    // Dispose existing subscriptions
    await dispose();

    _currentUserId = userId;
    _isInitialized = true;

    // Start listening to user updates
    _userSubscription = _firebaseService.getUserStream(userId).listen(
      (user) {
        if (user != null) {
          _userUpdateController.add(user);
          
          // Update team subscription if team changed
          if (user.teamId != _currentTeamId) {
            _updateTeamSubscription(user.teamId);
          }
        }
      },
      onError: (error) => debugPrint('User stream error: $error'),
    );

    debugPrint('Real-time sync initialized for user: $userId');
  }

  // Update team subscription when user joins/leaves team
  void _updateTeamSubscription(String? teamId) {
    _teamSubscription?.cancel();
    _notificationSubscription?.cancel();
    
    _currentTeamId = teamId;

    if (teamId != null) {
      // Listen to team updates
      _teamSubscription = _firebaseService.getTeamStream(teamId).listen(
        (team) {
          if (team != null) {
            _teamUpdateController.add(team);
            _checkForSlotUnlocks(team);
          }
        },
        onError: (error) => debugPrint('Team stream error: $error'),
      );

      // Listen to team notifications
      _notificationSubscription = _firebaseService.getTeamNotificationsStream(teamId).listen(
        (notifications) {
          _notificationController.add(notifications);
          _processNotifications(notifications);
        },
        onError: (error) => debugPrint('Notification stream error: $error'),
      );

      debugPrint('Team subscription updated for team: $teamId');
    }
  }

  // Check for new slot unlocks and emit events
  void _checkForSlotUnlocks(TeamModel team) {
    if (team.slots != null) {
      for (final entry in team.slots!.entries) {
        final slotType = entry.key;
        final slotData = entry.value;
        
        if (slotData['unlocked'] == true && slotData['notified'] != true) {
          _teamSlotUnlockController.add({
            'teamId': team.id,
            'slotType': slotType,
            'unlockedBy': slotData['unlockedBy'],
            'unlockedAt': slotData['unlockedAt'],
          });
          
          // Mark as notified to prevent duplicate events
          _markSlotAsNotified(team.id, slotType);
        }
      }
    }
  }

  // Process incoming notifications
  void _processNotifications(List<Map<String, dynamic>> notifications) {
    for (final notification in notifications) {
      final type = notification['type'];
      
      switch (type) {
        case 'team_slot_unlock':
          _handleTeamSlotUnlockNotification(notification);
          break;
        case 'team_member_joined':
          _handleTeamMemberJoinedNotification(notification);
          break;
        case 'team_stats_update':
          _handleTeamStatsUpdateNotification(notification);
          break;
        default:
          debugPrint('Unknown notification type: $type');
      }
    }
  }

  // Handle team slot unlock notifications
  void _handleTeamSlotUnlockNotification(Map<String, dynamic> notification) {
    final slotType = notification['slotType'];
    debugPrint('Team slot unlocked: $slotType');
    
    // Trigger any additional actions needed when slot is unlocked
    _syncTeamCapabilities(slotType);
  }

  // Handle team member joined notifications
  void _handleTeamMemberJoinedNotification(Map<String, dynamic> notification) {
    debugPrint('New team member joined');
    // Refresh team data to get updated member list
    _refreshTeamData();
  }

  // Handle team stats update notifications
  void _handleTeamStatsUpdateNotification(Map<String, dynamic> notification) {
    debugPrint('Team stats updated');
    // Refresh team statistics
    _refreshTeamStats();
  }

  // Sync team capabilities when new slots are unlocked
  Future<void> _syncTeamCapabilities(String slotType) async {
    try {
      switch (slotType) {
        case 'advanced_analytics':
          // Enable advanced analytics features
          await _enableAdvancedAnalytics();
          break;
        case 'premium_ads':
          // Enable premium ad features
          await _enablePremiumAds();
          break;
        case 'currency_boost':
          // Enable currency boost features
          await _enableCurrencyBoost();
          break;
        default:
          debugPrint('Unknown slot type: $slotType');
      }
    } catch (e) {
      debugPrint('Error syncing team capabilities: $e');
    }
  }

  // Enable advanced analytics
  Future<void> _enableAdvancedAnalytics() async {
    if (_currentTeamId != null) {
      await _teamManagementService.enableAdvancedAnalytics(_currentTeamId!);
      debugPrint('Advanced analytics enabled for team');
    }
  }

  // Enable premium ads
  Future<void> _enablePremiumAds() async {
    await _adMonetizationService.enablePremiumFeatures();
    debugPrint('Premium ads enabled for team');
  }

  // Enable currency boost
  Future<void> _enableCurrencyBoost() async {
    await _currencyService.enableTeamBoost();
    debugPrint('Currency boost enabled for team');
  }

  // Mark slot as notified to prevent duplicate events
  Future<void> _markSlotAsNotified(String teamId, String slotType) async {
    try {
      await _firebaseService.updateTeamSlotNotificationStatus(teamId, slotType, true);
    } catch (e) {
      debugPrint('Error marking slot as notified: $e');
    }
  }

  // Refresh team data
  Future<void> _refreshTeamData() async {
    if (_currentTeamId != null) {
      try {
        final team = await _firebaseService.getTeam(_currentTeamId!);
        if (team != null) {
          _teamUpdateController.add(team);
        }
      } catch (e) {
        debugPrint('Error refreshing team data: $e');
      }
    }
  }

  // Refresh team stats
  Future<void> _refreshTeamStats() async {
    if (_currentTeamId != null) {
      try {
        final stats = await _teamManagementService.getTeamStats(_currentTeamId!);
        await _firebaseService.syncTeamStats(_currentTeamId!, stats);
      } catch (e) {
        debugPrint('Error refreshing team stats: $e');
      }
    }
  }

  // Manually trigger team slot unlock
  Future<void> unlockTeamSlot(String slotType) async {
    if (_currentUserId == null || _currentTeamId == null) {
      throw Exception('User or team not initialized');
    }

    try {
      await _firebaseService.notifyTeamSlotUnlock(
        _currentTeamId!,
        _currentUserId!,
        slotType,
      );
      
      debugPrint('Team slot unlock initiated: $slotType');
    } catch (e) {
      debugPrint('Error unlocking team slot: $e');
      rethrow;
    }
  }

  // Get current sync status
  Map<String, dynamic> getSyncStatus() {
    return {
      'isInitialized': _isInitialized,
      'currentUserId': _currentUserId,
      'currentTeamId': _currentTeamId,
      'hasUserSubscription': _userSubscription != null,
      'hasTeamSubscription': _teamSubscription != null,
      'hasNotificationSubscription': _notificationSubscription != null,
    };
  }

  // Dispose all subscriptions and controllers
  Future<void> dispose() async {
    await _userSubscription?.cancel();
    await _teamSubscription?.cancel();
    await _notificationSubscription?.cancel();
    
    _userSubscription = null;
    _teamSubscription = null;
    _notificationSubscription = null;
    
    _currentUserId = null;
    _currentTeamId = null;
    _isInitialized = false;
    
    debugPrint('Real-time sync service disposed');
  }

  // Close all stream controllers
  void close() {
    _userUpdateController.close();
    _teamUpdateController.close();
    _teamSlotUnlockController.close();
    _notificationController.close();
  }
}