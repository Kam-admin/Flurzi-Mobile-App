import 'dart:async';
import 'dart:math';
import '../models/user_model.dart';
import '../models/team_model.dart';
import '../models/task_stats_model.dart';
import '../models/timesheet_model.dart';
import '../models/withdrawal_model.dart';
import 'firebase_service.dart';
import 'currency_service.dart';

class TeamManagementService {
  static final TeamManagementService _instance = TeamManagementService._internal();
  factory TeamManagementService() => _instance;
  TeamManagementService._internal();

  final FirebaseService _firebaseService = FirebaseService();
  final CurrencyService _currencyService = CurrencyService();
  
  // Task allocation and fairness
  final Map<String, List<String>> _taskQueue = {}; // teamId -> list of taskIds
  final Map<String, DateTime> _lastTaskAssignment = {}; // userId -> last assignment time
  
  // Profit sharing constants
  static const double teamOwnerBaseShare = 0.15; // 15% base share for team owner
  static const double topPerformerBonusShare = 0.05; // 5% bonus for top performers
  static const int minTeamSizeForProfitSharing = 5;
  static const double fiveStarBonusAmount = 2.0; // £2 bonus for 5-star ratings

  // Initialize service
  Future<void> initialize() async {
    await _currencyService.initialize();
  }

  // Register a new team member
  Future<TeamRegistrationResult> registerTeamMember({
    required String teamCode,
    required String username,
    required String realName,
    required String email,
  }) async {
    try {
      // Validate team code
      final team = await _firebaseService.getTeamByInviteCode(teamCode);
      if (team == null) {
        return TeamRegistrationResult(
          success: false,
          message: 'Invalid team code. Please check and try again.',
        );
      }

      // Check if team has available slots
      if (!team.hasAvailableSlots) {
        return TeamRegistrationResult(
          success: false,
          message: 'Team is full. No available slots.',
        );
      }

      // Create new team member user
      final newUser = UserModel(
        id: _generateUserId(),
        email: email,
        displayName: username,
        realName: realName,
        teamId: team.id,
        teamRole: 'member',
        totalEarnings: 0.0,
        unlockedTiers: [],
        activeTiers: [],
        hasAutoPlayUpgrade: false,
      );

      // Add user to Firebase
      await _firebaseService.createUser(newUser);
      
      // Add member to team
      await _firebaseService.addTeamMember(team.id, newUser.id);
      
      // Initialize member stats
      await _initializeMemberStats(newUser.id, team.id);
      
      return TeamRegistrationResult(
        success: true,
        message: 'Successfully joined team ${team.name}!',
        user: newUser,
        team: team,
      );
      
    } catch (e) {
      return TeamRegistrationResult(
        success: false,
        message: 'Registration failed: $e',
      );
    }
  }

  // Submit timesheet for team member
  Future<bool> submitTimesheet({
    required String userId,
    required String teamId,
    required Map<String, List<String>> availability,
  }) async {
    try {
      final timesheet = TimesheetModel(
        id: _generateTimesheetId(),
        userId: userId,
        teamId: teamId,
        availability: availability,
        submittedAt: DateTime.now(),
      );

      await _firebaseService.saveTimesheet(timesheet);
      
      // Update task allocation based on new availability
      await _updateTaskAllocation(teamId);
      
      return true;
    } catch (e) {
      print('Error submitting timesheet: $e');
      return false;
    }
  }

  // Allocate tasks fairly among team members
  Future<void> allocateTasksToTeamMembers(String teamId) async {
    try {
      final team = await _firebaseService.getTeam(teamId);
      if (team == null) return;

      final activeMembers = team.members.where((m) => m.isActive).toList();
      if (activeMembers.isEmpty) return;

      // Get available tasks
      final availableTasks = await _getAvailableTasks(teamId);
      if (availableTasks.isEmpty) return;

      // Sort members by last task assignment time (fairness)
      activeMembers.sort((a, b) {
        final aLastAssignment = _lastTaskAssignment[a.userId] ?? DateTime(2000);
        final bLastAssignment = _lastTaskAssignment[b.userId] ?? DateTime(2000);
        return aLastAssignment.compareTo(bLastAssignment);
      });

      // Distribute tasks evenly
      for (int i = 0; i < availableTasks.length; i++) {
        final memberIndex = i % activeMembers.length;
        final member = activeMembers[memberIndex];
        final task = availableTasks[i];

        await _assignTaskToMember(task, member.userId);
        _lastTaskAssignment[member.userId] = DateTime.now();
      }
      
    } catch (e) {
      print('Error allocating tasks: $e');
    }
  }

  // Award 5-star rating bonus
  Future<void> awardFiveStarBonus({
    required String userId,
    required String teamId,
    required String taskId,
  }) async {
    try {
      final bonus = BonusWithdrawalModel(
        id: _generateBonusId(),
        userId: userId,
        teamId: teamId,
        amount: fiveStarBonusAmount,
        currency: 'GBP',
        reason: '5_star_bonus',
        awardedAt: DateTime.now(),
      );

      await _firebaseService.recordBonusAward(bonus.toJson());
      
      // Update user's total earnings
      await _firebaseService.addUserEarnings(userId, fiveStarBonusAmount);
      
      // Log analytics
      await _firebaseService.logEvent('five_star_bonus_awarded', {
        'userId': userId,
        'teamId': teamId,
        'taskId': taskId,
        'amount': fiveStarBonusAmount,
      });
      
    } catch (e) {
      print('Error awarding 5-star bonus: $e');
    }
  }

  // Calculate and distribute team owner profit sharing
  Future<void> distributeTeamOwnerProfits(String teamId) async {
    try {
      final team = await _firebaseService.getTeam(teamId);
      if (team == null) return;

      // Only distribute profits for teams with minimum size
      if (team.members.length < minTeamSizeForProfitSharing) return;

      final weeklyEarnings = team.weeklyEarnings;
      if (weeklyEarnings <= 0) return;

      // Calculate team owner base share
      final ownerBaseProfit = weeklyEarnings * teamOwnerBaseShare;
      
      // Calculate top performer bonus
      final topPerformers = await _getTopPerformers(teamId, limit: 3);
      final topPerformerBonus = weeklyEarnings * topPerformerBonusShare;
      
      // Distribute base profit to team owner
      await _firebaseService.addUserEarnings(team.ownerId, ownerBaseProfit);
      
      // Distribute top performer bonus
      if (topPerformers.isNotEmpty) {
        final bonusPerPerformer = topPerformerBonus / topPerformers.length;
        for (final performer in topPerformers) {
          await _firebaseService.addUserEarnings(performer.userId, bonusPerPerformer);
          
          // Record bonus
          final bonus = BonusWithdrawalModel(
            id: _generateBonusId(),
            userId: performer.userId,
            teamId: teamId,
            amount: bonusPerPerformer,
            currency: 'GBP',
            reason: 'performance_bonus',
            awardedAt: DateTime.now(),
          );
          
          await _firebaseService.recordBonusAward(bonus.toJson());
        }
      }
      
      // Log profit distribution
      await _firebaseService.logEvent('team_profit_distributed', {
        'teamId': teamId,
        'ownerProfit': ownerBaseProfit,
        'topPerformerBonus': topPerformerBonus,
        'topPerformersCount': topPerformers.length,
      });
      
    } catch (e) {
      print('Error distributing team profits: $e');
    }
  }

  // Process withdrawal request for team member
  Future<WithdrawalResult> processWithdrawal({
    required String userId,
    required String teamId,
    required double amount,
    required String currency,
    required String method,
    required Map<String, dynamic> methodDetails,
  }) async {
    try {
      // Validate withdrawal amount
      if (!_currencyService.canWithdraw(amount, currency)) {
        return WithdrawalResult(
          success: false,
          message: 'Amount below minimum withdrawal threshold',
        );
      }

      // Calculate fees and net amount
      final fee = _currencyService.calculateWithdrawalFee(amount, currency, method);
      final netAmount = amount - fee;
      
      // Create withdrawal request
      final withdrawal = WithdrawalModel(
        id: _generateWithdrawalId(),
        userId: userId,
        teamId: teamId,
        amount: amount,
        currency: currency,
        method: method,
        methodDetails: methodDetails,
        requestedAt: DateTime.now(),
        fees: fee,
        netAmount: netAmount,
      );

      await _firebaseService.createWithdrawalRequest(withdrawal.toJson());
      
      return WithdrawalResult(
        success: true,
        message: 'Withdrawal request submitted successfully',
        withdrawal: withdrawal,
      );
      
    } catch (e) {
      return WithdrawalResult(
        success: false,
        message: 'Withdrawal failed: $e',
      );
    }
  }

  // Get team statistics
  Future<TeamStatsModel?> getTeamStats(String teamId) async {
    try {
      final team = await _firebaseService.getTeam(teamId);
      if (team == null) return null;

      final memberStats = <TaskStatsModel>[];
      
      for (final member in team.members) {
        final stats = await _getMemberStats(member.userId, teamId);
        if (stats != null) {
          memberStats.add(stats);
        }
      }

      return TeamStatsModel(
        teamId: teamId,
        teamName: team.name,
        totalMembers: team.members.length,
        totalEarnings: team.totalEarnings,
        weeklyEarnings: team.weeklyEarnings,
        memberStats: memberStats,
        lastUpdatedAt: DateTime.now(),
      );
      
    } catch (e) {
      print('Error getting team stats: $e');
      return null;
    }
  }

  // Helper methods
  Future<void> _initializeMemberStats(String userId, String teamId) async {
    final stats = TaskStatsModel(
      id: _generateStatsId(),
      userId: userId,
      teamId: teamId,
      lastActiveAt: DateTime.now(),
    );
    
    await _firebaseService.saveTaskStats(stats);
  }

  Future<List<String>> _getAvailableTasks(String teamId) async {
    // This would typically fetch from a task queue or database
    // For now, return mock tasks
    return List.generate(10, (index) => 'task_${teamId}_$index');
  }

  Future<void> _assignTaskToMember(String taskId, String userId) async {
    // Implement task assignment logic
    await _firebaseService.logEvent('task_assigned', {
      'taskId': taskId,
      'userId': userId,
      'assignedAt': DateTime.now().toIso8601String(),
    });
  }

  Future<void> _updateTaskAllocation(String teamId) async {
    // Update task allocation based on member availability
    await allocateTasksToTeamMembers(teamId);
  }

  Future<List<TaskStatsModel>> _getTopPerformers(String teamId, {int limit = 3}) async {
    final teamStats = await getTeamStats(teamId);
    if (teamStats == null) return [];
    
    final performers = teamStats.memberStats
        .where((stats) => stats.isTopPerformer)
        .toList()
      ..sort((a, b) => b.contributionScore.compareTo(a.contributionScore));
    
    return performers.take(limit).toList();
  }

  Future<TaskStatsModel?> _getMemberStats(String userId, String teamId) async {
    // This would typically fetch from database
    // For now, return mock stats
    return TaskStatsModel(
      id: _generateStatsId(),
      userId: userId,
      teamId: teamId,
      tasksCompleted: Random().nextInt(50),
      adsWatched: Random().nextInt(100),
      totalEarnings: Random().nextDouble() * 100,
      averageRating: 4.0 + Random().nextDouble(),
      lastActiveAt: DateTime.now(),
    );
  }

  // ID generators
  String _generateUserId() => 'user_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(1000)}';
  String _generateTimesheetId() => 'timesheet_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(1000)}';
  String _generateBonusId() => 'bonus_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(1000)}';
  String _generateWithdrawalId() => 'withdrawal_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(1000)}';
  String _generateStatsId() => 'stats_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(1000)}';
}

class TeamRegistrationResult {
  final bool success;
  final String message;
  final UserModel? user;
  final TeamModel? team;

  TeamRegistrationResult({
    required this.success,
    required this.message,
    this.user,
    this.team,
  });
}

class WithdrawalResult {
  final bool success;
  final String message;
  final WithdrawalModel? withdrawal;

  WithdrawalResult({
    required this.success,
    required this.message,
    this.withdrawal,
  });
}