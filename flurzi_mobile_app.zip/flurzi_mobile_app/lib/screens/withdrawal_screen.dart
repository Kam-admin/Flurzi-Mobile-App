import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../widgets/neon_button.dart';

class WithdrawalScreen extends StatefulWidget {
  const WithdrawalScreen({super.key});

  @override
  State<WithdrawalScreen> createState() => _WithdrawalScreenState();
}

class _WithdrawalScreenState extends State<WithdrawalScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _slideAnimation;
  late Animation<double> _fadeAnimation;
  
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _accountController = TextEditingController();
  
  bool _isLoading = false;
  String _selectedCurrency = 'GBP';
  String _selectedMethod = 'Bank Transfer';
  double _availableBalance = 0;
  double _bonusBalance = 0;
  bool _canWithdrawBonus = false;
  DateTime? _lastBonusWithdrawal;
  
  final List<String> _currencies = ['GBP', 'USD', 'EUR', 'CAD', 'AUD'];
  final List<String> _withdrawalMethods = [
    'Bank Transfer',
    'PayPal',
    'Stripe',
    'Crypto Wallet'
  ];
  
  final Map<String, double> _exchangeRates = {
    'GBP': 1.0,
    'USD': 1.27,
    'EUR': 1.17,
    'CAD': 1.71,
    'AUD': 1.91,
  };

  @override
  void initState() {
    super.initState();
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _slideAnimation = Tween<double>(
      begin: 30,
      end: 0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutBack,
    ));
    
    _fadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));
    
    _animationController.forward();
    _loadBalanceData();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _amountController.dispose();
    _accountController.dispose();
    super.dispose();
  }

  void _loadBalanceData() {
    final appProvider = context.read<AppProvider>();
    final user = appProvider.user;
    
    if (user != null) {
      setState(() {
        _availableBalance = user.totalEarnings;
        _bonusBalance = user.preferences['bonusBalance']?.toDouble() ?? 0;
        
        // Check if user can withdraw bonus (once per month)
        final lastWithdrawal = user.preferences['lastBonusWithdrawal'];
        if (lastWithdrawal != null) {
          _lastBonusWithdrawal = DateTime.parse(lastWithdrawal);
          final now = DateTime.now();
          final daysSinceLastWithdrawal = now.difference(_lastBonusWithdrawal!).inDays;
          _canWithdrawBonus = daysSinceLastWithdrawal >= 30;
        } else {
          _canWithdrawBonus = _bonusBalance > 0;
        }
      });
    }
  }

  double _convertCurrency(double amount) {
    return amount * _exchangeRates[_selectedCurrency]!;
  }

  String _formatCurrency(double amount) {
    final converted = _convertCurrency(amount);
    final symbol = _getCurrencySymbol(_selectedCurrency);
    return '$symbol${converted.toStringAsFixed(2)}';
  }

  String _getCurrencySymbol(String currency) {
    switch (currency) {
      case 'GBP': return '£';
      case 'USD': return r'$';
      case 'EUR': return '€';
      case 'CAD': return 'C\$';
      case 'AUD': return 'A\$';
      default: return currency;
    }
  }

  Future<void> _processWithdrawal() async {
    final amount = double.tryParse(_amountController.text);
    if (amount == null || amount <= 0) {
      _showError('Please enter a valid amount');
      return;
    }
    
    if (amount > _availableBalance) {
      _showError('Insufficient balance');
      return;
    }
    
    if (_accountController.text.trim().isEmpty) {
      _showError('Please enter account details');
      return;
    }
    
    setState(() {
      _isLoading = true;
    });
    
    try {
      final appProvider = context.read<AppProvider>();
      
      // Process withdrawal
      await appProvider.processWithdrawal(
        amount: amount,
        currency: _selectedCurrency,
        method: _selectedMethod,
        accountDetails: _accountController.text.trim(),
      );
      
      setState(() {
        _isLoading = false;
        _availableBalance -= amount;
      });
      
      _amountController.clear();
      _accountController.clear();
      
      _showSuccess('Withdrawal request submitted successfully!');
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      _showError('Failed to process withdrawal: ${e.toString()}');
    }
  }

  Future<void> _withdrawBonus() async {
    if (!_canWithdrawBonus || _bonusBalance <= 0) {
      _showError('Bonus withdrawal not available');
      return;
    }
    
    setState(() {
      _isLoading = true;
    });
    
    try {
      final appProvider = context.read<AppProvider>();
      
      await appProvider.withdrawBonus();
      
      setState(() {
        _isLoading = false;
        _availableBalance += _bonusBalance;
        _bonusBalance = 0;
        _canWithdrawBonus = false;
        _lastBonusWithdrawal = DateTime.now();
      });
      
      _showSuccess('Bonus transferred to available balance!');
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      _showError('Failed to withdraw bonus: ${e.toString()}');
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.colors.error,
      ),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.colors.success,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.colors.background,
      body: SafeArea(
        child: AnimatedBuilder(
          animation: _animationController,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(0, _slideAnimation.value),
              child: Opacity(
                opacity: _fadeAnimation.value,
                child: Column(
                  children: [
                    // Header
                    _buildHeader(),
                    
                    // Content
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Balance cards
                            _buildBalanceCards(),
                            
                            const SizedBox(height: 20),
                            
                            // Withdrawal form
                            _buildWithdrawalForm(),
                            
                            const SizedBox(height: 20),
                            
                            // Recent transactions
                            _buildRecentTransactions(),
                            
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.colors.surface,
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                border: Border.all(
                  color: AppTheme.colors.border,
                  width: 1,
                ),
              ),
              child: Icon(
                LucideIcons.arrowLeft,
                color: AppTheme.colors.primary,
                size: 20,
              ),
            ),
          ),
          
          const SizedBox(width: 16),
          
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Withdrawal',
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
                Text(
                  'Withdraw your earnings',
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 14,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBalanceCards() {
    return Column(
      children: [
        // Available balance
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppTheme.colors.primary.withOpacity(0.2),
                AppTheme.colors.secondary.withOpacity(0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
            border: Border.all(
              color: AppTheme.colors.primary.withOpacity(0.5),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Icon(
                LucideIcons.wallet,
                color: AppTheme.colors.primary,
                size: 32,
              ),
              
              const SizedBox(width: 16),
              
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Available Balance',
                      style: TextStyle(
                        color: AppTheme.colors.text,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _formatCurrency(_availableBalance),
                      style: TextStyle(
                        color: AppTheme.colors.primary,
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 12),
        
        // Bonus balance
        if (_bonusBalance > 0)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.colors.surface,
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
              border: Border.all(
                color: _canWithdrawBonus
                    ? AppTheme.colors.success
                    : AppTheme.colors.border,
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  LucideIcons.gift,
                  color: _canWithdrawBonus
                      ? AppTheme.colors.success
                      : AppTheme.colors.textSecondary,
                  size: 24,
                ),
                
                const SizedBox(width: 12),
                
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Bonus Balance',
                        style: TextStyle(
                          color: AppTheme.colors.text,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                      Text(
                        _formatCurrency(_bonusBalance),
                        style: TextStyle(
                          color: _canWithdrawBonus
                              ? AppTheme.colors.success
                              : AppTheme.colors.textSecondary,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                      if (!_canWithdrawBonus && _lastBonusWithdrawal != null)
                        Text(
                          'Available in ${30 - DateTime.now().difference(_lastBonusWithdrawal!).inDays} days',
                          style: TextStyle(
                            color: AppTheme.colors.textSecondary,
                            fontSize: 12,
                            fontFamily: AppTheme.fonts.secondary,
                          ),
                        ),
                    ],
                  ),
                ),
                
                if (_canWithdrawBonus)
                  GestureDetector(
                    onTap: _isLoading ? null : _withdrawBonus,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.colors.success,
                        borderRadius: BorderRadius.circular(
                          AppTheme.borderRadius.small,
                        ),
                      ),
                      child: Text(
                        'Claim',
                        style: TextStyle(
                          color: AppTheme.colors.background,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildWithdrawalForm() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Withdraw Funds',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Currency selector
          Text(
            'Currency',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 14,
              fontWeight: FontWeight.w500,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: AppTheme.colors.background,
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
              border: Border.all(
                color: AppTheme.colors.border,
                width: 1,
              ),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedCurrency,
                isExpanded: true,
                dropdownColor: AppTheme.colors.surface,
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 16,
                  fontFamily: AppTheme.fonts.primary,
                ),
                items: _currencies.map((currency) {
                  return DropdownMenuItem(
                    value: currency,
                    child: Text('$currency (${_getCurrencySymbol(currency)})'),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      _selectedCurrency = value;
                    });
                  }
                },
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Amount input
          Text(
            'Amount',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 14,
              fontWeight: FontWeight.w500,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _amountController,
            keyboardType: TextInputType.number,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 16,
              fontFamily: AppTheme.fonts.primary,
            ),
            decoration: InputDecoration(
              hintText: 'Enter amount to withdraw',
              hintStyle: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontFamily: AppTheme.fonts.secondary,
              ),
              filled: true,
              fillColor: AppTheme.colors.background,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(
                  color: AppTheme.colors.border,
                  width: 1,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(
                  color: AppTheme.colors.border,
                  width: 1,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(
                  color: AppTheme.colors.primary,
                  width: 2,
                ),
              ),
              prefixText: _getCurrencySymbol(_selectedCurrency),
              prefixStyle: TextStyle(
                color: AppTheme.colors.text,
                fontSize: 16,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Withdrawal method
          Text(
            'Withdrawal Method',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 14,
              fontWeight: FontWeight.w500,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: AppTheme.colors.background,
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
              border: Border.all(
                color: AppTheme.colors.border,
                width: 1,
              ),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedMethod,
                isExpanded: true,
                dropdownColor: AppTheme.colors.surface,
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 16,
                  fontFamily: AppTheme.fonts.primary,
                ),
                items: _withdrawalMethods.map((method) {
                  return DropdownMenuItem(
                    value: method,
                    child: Text(method),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      _selectedMethod = value;
                    });
                  }
                },
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Account details
          Text(
            'Account Details',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 14,
              fontWeight: FontWeight.w500,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _accountController,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 16,
              fontFamily: AppTheme.fonts.primary,
            ),
            decoration: InputDecoration(
              hintText: _getAccountHint(),
              hintStyle: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontFamily: AppTheme.fonts.secondary,
              ),
              filled: true,
              fillColor: AppTheme.colors.background,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(
                  color: AppTheme.colors.border,
                  width: 1,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(
                  color: AppTheme.colors.border,
                  width: 1,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(
                  color: AppTheme.colors.primary,
                  width: 2,
                ),
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Submit button
          NeonButton(
            text: _isLoading ? 'Processing...' : 'Submit Withdrawal',
            onPressed: _isLoading ? null : _processWithdrawal,
            isLoading: _isLoading,
            width: double.infinity,
          ),
        ],
      ),
    );
  }

  String _getAccountHint() {
    switch (_selectedMethod) {
      case 'Bank Transfer':
        return 'Account number and sort code';
      case 'PayPal':
        return 'PayPal email address';
      case 'Stripe':
        return 'Stripe account ID';
      case 'Crypto Wallet':
        return 'Wallet address';
      default:
        return 'Account details';
    }
  }

  Widget _buildRecentTransactions() {
    // Mock transaction data
    final transactions = [
      {
        'type': 'withdrawal',
        'amount': 150.00,
        'currency': 'GBP',
        'method': 'Bank Transfer',
        'status': 'completed',
        'date': DateTime.now().subtract(const Duration(days: 2)),
      },
      {
        'type': 'bonus',
        'amount': 5.00,
        'currency': 'GBP',
        'method': 'Bonus Claim',
        'status': 'completed',
        'date': DateTime.now().subtract(const Duration(days: 7)),
      },
      {
        'type': 'withdrawal',
        'amount': 75.50,
        'currency': 'USD',
        'method': 'PayPal',
        'status': 'pending',
        'date': DateTime.now().subtract(const Duration(days: 14)),
      },
    ];
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Recent Transactions',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 16),
          
          ...transactions.map((transaction) {
            final isWithdrawal = transaction['type'] == 'withdrawal';
            final status = transaction['status'] as String;
            final amount = transaction['amount'] as double;
            final currency = transaction['currency'] as String;
            final method = transaction['method'] as String;
            final date = transaction['date'] as DateTime;
            
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.colors.background,
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                border: Border.all(
                  color: AppTheme.colors.border,
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    isWithdrawal ? LucideIcons.arrowUpRight : LucideIcons.gift,
                    color: isWithdrawal
                        ? AppTheme.colors.error
                        : AppTheme.colors.success,
                    size: 20,
                  ),
                  
                  const SizedBox(width: 12),
                  
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          method,
                          style: TextStyle(
                            color: AppTheme.colors.text,
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            fontFamily: AppTheme.fonts.primary,
                          ),
                        ),
                        Text(
                          '${date.day}/${date.month}/${date.year}',
                          style: TextStyle(
                            color: AppTheme.colors.textSecondary,
                            fontSize: 12,
                            fontFamily: AppTheme.fonts.secondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '${isWithdrawal ? '-' : '+'}${_getCurrencySymbol(currency)}${amount.toStringAsFixed(2)}',
                        style: TextStyle(
                          color: isWithdrawal
                              ? AppTheme.colors.error
                              : AppTheme.colors.success,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: status == 'completed'
                              ? AppTheme.colors.success.withOpacity(0.2)
                              : AppTheme.colors.warning.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(
                            AppTheme.borderRadius.small,
                          ),
                        ),
                        child: Text(
                          status.toUpperCase(),
                          style: TextStyle(
                            color: status == 'completed'
                                ? AppTheme.colors.success
                                : AppTheme.colors.warning,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: AppTheme.fonts.primary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }
}