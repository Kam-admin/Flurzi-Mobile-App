import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../models/team_model.dart';
import '../widgets/neon_button.dart';
import '../widgets/ad_banner.dart';
import '../widgets/notification_badge.dart';
import '../services/currency_service.dart';

class TeamScreen extends StatefulWidget {
  const TeamScreen({super.key});

  @override
  State<TeamScreen> createState() => _TeamScreenState();
}

class _TeamScreenState extends State<TeamScreen>
    with TickerProviderStateMixin {
  late AnimationController _headerAnimationController;
  late AnimationController _cardAnimationController;
  late Animation<double> _headerSlideAnimation;
  late Animation<double> _cardScaleAnimation;
  
  final TextEditingController _inviteCodeController = TextEditingController();
  final TextEditingController _teamNameController = TextEditingController();
  final TextEditingController _teamDescriptionController = TextEditingController();
  final CurrencyService _currencyService = CurrencyService();
  
  bool _showCreateTeamForm = false;
  bool _showJoinTeamForm = false;

  @override
  void initState() {
    super.initState();
    
    _headerAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _cardAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _headerSlideAnimation = Tween<double>(
      begin: -100,
      end: 0,
    ).animate(CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeOutBack,
    ));
    
    _cardScaleAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _cardAnimationController,
      curve: Curves.elasticOut,
    ));
    
    // Start animations
    _headerAnimationController.forward();
    Future.delayed(const Duration(milliseconds: 300), () {
      _cardAnimationController.forward();
    });
    
    // Load team data
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppProvider>().loadTeamData();
    });
  }

  @override
  void dispose() {
    _headerAnimationController.dispose();
    _cardAnimationController.dispose();
    _inviteCodeController.dispose();
    _teamNameController.dispose();
    _teamDescriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.colors.background,
      body: Column(
        children: [
          Expanded(
            child: SafeArea(
              bottom: false,
              child: Consumer<AppProvider>(builder: (context, appProvider, child) {
                return SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header
                      _buildHeader(appProvider),
                      
                      const SizedBox(height: 24),
                      
                      // Team status card
                      if (appProvider.userTeam != null)
                        _buildTeamCard(appProvider)
                      else
                        _buildNoTeamCard(appProvider),
                      
                      const SizedBox(height: 24),
                      
                      // Team actions
                      if (appProvider.userTeam == null) ..._buildTeamActions(appProvider),
                      
                      // Team members (if in a team)
                      if (appProvider.userTeam != null) ..._buildTeamMembers(appProvider),
                      
                      const SizedBox(height: 80), // Bottom padding for ad banner
                    ],
                  ),
                );
              }),
            ),
          ),
          // Ad banner at bottom
          Consumer<AppProvider>(
            builder: (context, appProvider, child) {
              return BottomAdBanner(
                onTap: () => appProvider.watchAd(),
                adText: 'Watch Ad & Boost Team Earnings',
                isLoading: appProvider.isWatchingAd,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(AppProvider appProvider) {
    return AnimatedBuilder(
      animation: _headerSlideAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _headerSlideAnimation.value),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Team Mining',
                        style: TextStyle(
                          color: AppTheme.colors.text,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        appProvider.userTeam != null
                            ? 'Team: ${appProvider.userTeam!.name}'
                            : 'Join a team to boost earnings',
                        style: TextStyle(
                          color: AppTheme.colors.textSecondary,
                          fontSize: 14,
                          fontFamily: AppTheme.fonts.secondary,
                        ),
                      ),
                    ],
                  ),
                  
                  Row(
                    children: [
                      // Notification badge
                      NotificationBadge(
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.colors.surface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: AppTheme.colors.border,
                              width: 1,
                            ),
                          ),
                          child: Icon(
                            LucideIcons.bell,
                            color: AppTheme.colors.text,
                            size: 20,
                          ),
                        ),
                        onTap: () => _showNotificationPanel(context),
                      ),
                      
                      const SizedBox(width: 12),
                      
                      // Team status indicator
                      Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: (appProvider.userTeam != null
                          ? AppTheme.colors.success
                          : AppTheme.colors.warning).withValues(alpha: 51), // 0.2 * 255 ≈ 51
                      borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                      border: Border.all(
                        color: appProvider.userTeam != null
                            ? AppTheme.colors.success
                            : AppTheme.colors.warning,
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          appProvider.userTeam != null
                              ? LucideIcons.users
                              : LucideIcons.userPlus,
                          color: appProvider.userTeam != null
                              ? AppTheme.colors.success
                              : AppTheme.colors.warning,
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          appProvider.userTeam != null ? 'IN TEAM' : 'NO TEAM',
                          style: TextStyle(
                            color: appProvider.userTeam != null
                                ? AppTheme.colors.success
                                : AppTheme.colors.warning,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: AppTheme.fonts.primary,
                          ),
                        ),
                      ],
                    ),
                  ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTeamCard(AppProvider appProvider) {
    final team = appProvider.userTeam!;
    final userMember = team.members.firstWhere(
      (member) => member.userId == appProvider.user?.id,
      orElse: () => team.members.first,
    );
    
    return AnimatedBuilder(
      animation: _cardScaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _cardScaleAnimation.value,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.colors.success.withValues(alpha: 26), // 0.1 * 255 ≈ 26
                AppTheme.colors.primary.withValues(alpha: 13), // 0.05 * 255 ≈ 13
                ],
              ),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
              border: Border.all(
                color: AppTheme.colors.success.withValues(alpha: 77), // 0.3 * 255 ≈ 77
                width: 2,
              ),
              boxShadow: AppTheme.shadows.medium,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Team header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            team.name,
                            style: TextStyle(
                              color: AppTheme.colors.text,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              fontFamily: AppTheme.fonts.primary,
                            ),
                          ),
                          if (team.description.isNotEmpty) ..[
                            const SizedBox(height: 4),
                            Text(
                              team.description,
                              style: TextStyle(
                                color: AppTheme.colors.textSecondary,
                                fontSize: 14,
                                fontFamily: AppTheme.fonts.secondary,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    
                    // Role badge
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: userMember.isOwner
                            ? AppTheme.colors.warning.withValues(alpha: 51) // 0.2 * 255 ≈ 51
                : AppTheme.colors.primary.withValues(alpha: 51), // 0.2 * 255 ≈ 51
                        borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
                        border: Border.all(
                          color: userMember.isOwner
                              ? AppTheme.colors.warning
                              : AppTheme.colors.primary,
                          width: 1,
                        ),
                      ),
                      child: Text(
                        userMember.role.toUpperCase(),
                        style: TextStyle(
                          color: userMember.isOwner
                              ? AppTheme.colors.warning
                              : AppTheme.colors.primary,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 20),
                
                // Team stats
                Row(
                  children: [
                    Expanded(
                      child: _buildTeamStatCard(
                        'Total Earnings',
                        _currencyService.formatCurrency(
                          team.totalEarnings,
                          appProvider.userCurrency,
                        ),
                        LucideIcons.dollarSign,
                        AppTheme.colors.success,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildTeamStatCard(
                        'Weekly Earnings',
                        _currencyService.formatCurrency(
                          team.weeklyEarnings,
                          appProvider.userCurrency,
                        ),
                        LucideIcons.calendar,
                        AppTheme.colors.primary,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                Row(
                  children: [
                    Expanded(
                      child: _buildTeamStatCard(
                        'Members',
                        '${team.members.length}/${team.maxMembers}',
                        LucideIcons.users,
                        AppTheme.colors.secondary,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildTeamStatCard(
                        'Your Share',
                        _currencyService.formatCurrency(
                          userMember.contributedEarnings,
                          appProvider.userCurrency,
                        ),
                        LucideIcons.pieChart,
                        AppTheme.colors.warning,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 20),
                
                // Team actions
                Row(
                  children: [
                    Expanded(
                      child: NeonButton(
                        text: 'INVITE CODE',
                        onPressed: () => _showInviteCode(team.inviteCode),
                        variant: NeonButtonVariant.secondary,
                        icon: LucideIcons.share,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: NeonButton(
                        text: 'LEAVE TEAM',
                        onPressed: () => _showLeaveTeamDialog(appProvider),
                        variant: NeonButtonVariant.error,
                        icon: LucideIcons.logOut,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildNoTeamCard(AppProvider appProvider) {
    return AnimatedBuilder(
      animation: _cardScaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _cardScaleAnimation.value,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.colors.warning.withValues(alpha: 26), // 0.1 * 255 ≈ 26
                AppTheme.colors.secondary.withValues(alpha: 13), // 0.05 * 255 ≈ 13
                ],
              ),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
              border: Border.all(
                color: AppTheme.colors.warning.withValues(alpha: 77), // 0.3 * 255 ≈ 77
                width: 2,
              ),
              boxShadow: AppTheme.shadows.medium,
            ),
            child: Column(
              children: [
                Icon(
                  LucideIcons.users,
                  color: AppTheme.colors.warning,
                  size: 48,
                ),
                const SizedBox(height: 16),
                Text(
                  'No Team Yet',
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Join a team to share earnings and compete together in weekly leaderboards!',
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 14,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                
                // Benefits list
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.colors.surface,
                    borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                  ),
                  child: Column(
                    children: [
                      _buildBenefitItem('Share earnings with team members', LucideIcons.dollarSign),
                      const SizedBox(height: 8),
                      _buildBenefitItem('Compete in weekly leaderboards', LucideIcons.trophy),
                      const SizedBox(height: 8),
                      _buildBenefitItem('Unlock team-exclusive quests', LucideIcons.target),
                      const SizedBox(height: 8),
                      _buildBenefitItem('Get bonus rewards for teamwork', LucideIcons.gift),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildBenefitItem(String text, IconData icon) {
    return Row(
      children: [
        Icon(
          icon,
          color: AppTheme.colors.primary,
          size: 16,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 12,
              fontFamily: AppTheme.fonts.secondary,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTeamStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: color.withValues(alpha: 77), // 0.3 * 255 ≈ 77
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                icon,
                color: color,
                size: 16,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 11,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  List<Widget> _buildTeamActions(AppProvider appProvider) {
    return [
      // Action buttons
      Row(
        children: [
          Expanded(
            child: NeonButton(
              text: 'JOIN TEAM',
              onPressed: () => _toggleJoinTeamForm(),
              variant: NeonButtonVariant.primary,
              icon: LucideIcons.userPlus,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: NeonButton(
              text: 'CREATE TEAM',
              onPressed: () => _toggleCreateTeamForm(),
              variant: NeonButtonVariant.secondary,
              icon: LucideIcons.plus,
            ),
          ),
        ],
      ),
      
      const SizedBox(height: 16),
      
      // Join team form
      if (_showJoinTeamForm) _buildJoinTeamForm(appProvider),
      
      // Create team form
      if (_showCreateTeamForm) _buildCreateTeamForm(appProvider),
    ];
  }

  Widget _buildJoinTeamForm(AppProvider appProvider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.primary.withValues(alpha: 77), // 0.3 * 255 ≈ 77
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Join Team',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _inviteCodeController,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontFamily: AppTheme.fonts.secondary,
            ),
            decoration: InputDecoration(
              labelText: 'Invite Code',
              labelStyle: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontFamily: AppTheme.fonts.secondary,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(color: AppTheme.colors.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(color: AppTheme.colors.primary),
              ),
              prefixIcon: Icon(
                LucideIcons.key,
                color: AppTheme.colors.textSecondary,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: NeonButton(
                  text: 'CANCEL',
                  onPressed: _toggleJoinTeamForm,
                  variant: NeonButtonVariant.secondary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: NeonButton(
                  text: 'JOIN',
                  onPressed: () => _joinTeam(appProvider),
                  variant: NeonButtonVariant.primary,
                  isLoading: appProvider.isLoading,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCreateTeamForm(AppProvider appProvider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.secondary.withValues(alpha: 77), // 0.3 * 255 ≈ 77
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Create Team',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _teamNameController,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontFamily: AppTheme.fonts.secondary,
            ),
            decoration: InputDecoration(
              labelText: 'Team Name',
              labelStyle: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontFamily: AppTheme.fonts.secondary,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(color: AppTheme.colors.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(color: AppTheme.colors.secondary),
              ),
              prefixIcon: Icon(
                LucideIcons.users,
                color: AppTheme.colors.textSecondary,
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _teamDescriptionController,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontFamily: AppTheme.fonts.secondary,
            ),
            maxLines: 3,
            decoration: InputDecoration(
              labelText: 'Description (Optional)',
              labelStyle: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontFamily: AppTheme.fonts.secondary,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(color: AppTheme.colors.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                borderSide: BorderSide(color: AppTheme.colors.secondary),
              ),
              prefixIcon: Icon(
                LucideIcons.fileText,
                color: AppTheme.colors.textSecondary,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: NeonButton(
                  text: 'CANCEL',
                  onPressed: _toggleCreateTeamForm,
                  variant: NeonButtonVariant.secondary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: NeonButton(
                  text: 'CREATE',
                  onPressed: () => _createTeam(appProvider),
                  variant: NeonButtonVariant.primary,
                  isLoading: appProvider.isLoading,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  List<Widget> _buildTeamMembers(AppProvider appProvider) {
    final team = appProvider.userTeam!;
    
    return [
      Text(
        'Team Members (${team.members.length}/${team.maxMembers})',
        style: TextStyle(
          color: AppTheme.colors.text,
          fontSize: 18,
          fontWeight: FontWeight.bold,
          fontFamily: AppTheme.fonts.primary,
        ),
      ),
      
      const SizedBox(height: 16),
      
      ...team.members.asMap().entries.map((entry) {
        final index = entry.key;
        final member = entry.value;
        
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.colors.surface,
            borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
            border: Border.all(
              color: member.isOwner
                  ? AppTheme.colors.warning.withValues(alpha: 77) // 0.3 * 255 ≈ 77
                  : AppTheme.colors.border,
              width: 1,
            ),
          ),
          child: Row(
            children: [
              // Avatar
              CircleAvatar(
                radius: 20,
                backgroundColor: AppTheme.colors.primary.withValues(alpha: 51), // 0.2 * 255 ≈ 51
                backgroundImage: member.photoUrl != null
                    ? NetworkImage(member.photoUrl!)
                    : null,
                child: member.photoUrl == null
                    ? Text(
                        member.displayName.isNotEmpty
                            ? member.displayName[0].toUpperCase()
                            : 'U',
                        style: TextStyle(
                          color: AppTheme.colors.primary,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      )
                    : null,
              ),
              
              const SizedBox(width: 12),
              
              // Member info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            member.displayName,
                            style: TextStyle(
                              color: AppTheme.colors.text,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: AppTheme.fonts.primary,
                            ),
                          ),
                        ),
                        if (member.isOwner)
                          Icon(
                            LucideIcons.crown,
                            color: AppTheme.colors.warning,
                            size: 16,
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          'Contributed: ',
                          style: TextStyle(
                            color: AppTheme.colors.textSecondary,
                            fontSize: 12,
                            fontFamily: AppTheme.fonts.secondary,
                          ),
                        ),
                        Text(
                          _currencyService.formatCurrency(
                            member.contributedEarnings,
                            appProvider.userCurrency,
                          ),
                          style: TextStyle(
                            color: AppTheme.colors.success,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: AppTheme.fonts.primary,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              // Status indicator
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: member.isActive
                      ? AppTheme.colors.success
                      : AppTheme.colors.textSecondary,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
        ).animate().slideX(delay: Duration(milliseconds: 100 * index));
      }),
    ];
  }

  // Action methods
  void _toggleJoinTeamForm() {
    setState(() {
      _showJoinTeamForm = !_showJoinTeamForm;
      if (_showJoinTeamForm) {
        _showCreateTeamForm = false;
      }
    });
  }

  void _toggleCreateTeamForm() {
    setState(() {
      _showCreateTeamForm = !_showCreateTeamForm;
      if (_showCreateTeamForm) {
        _showJoinTeamForm = false;
      }
    });
  }

  void _joinTeam(AppProvider appProvider) async {
    if (_inviteCodeController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please enter an invite code'),
          backgroundColor: AppTheme.colors.error,
        ),
      );
      return;
    }

    final success = await appProvider.joinTeam(_inviteCodeController.text.trim());
    if (mounted) {
      if (success) {
        _inviteCodeController.clear();
        _toggleJoinTeamForm();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Successfully joined team!'),
            backgroundColor: AppTheme.colors.success,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Failed to join team. Check invite code.'),
            backgroundColor: AppTheme.colors.error,
          ),
        );
      }
    }
  }

  void _createTeam(AppProvider appProvider) async {
    if (_teamNameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please enter a team name'),
          backgroundColor: AppTheme.colors.error,
        ),
      );
      return;
    }

    final success = await appProvider.createTeam(
      _teamNameController.text.trim(),
      _teamDescriptionController.text.trim(),
    );
    
    if (mounted) {
      if (success) {
        _teamNameController.clear();
        _teamDescriptionController.clear();
        _toggleCreateTeamForm();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Team created successfully!'),
            backgroundColor: AppTheme.colors.success,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Failed to create team'),
            backgroundColor: AppTheme.colors.error,
          ),
        );
      }
    }
  }

  void _showInviteCode(String inviteCode) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.colors.surface,
        title: Text(
          'Team Invite Code',
          style: TextStyle(
            color: AppTheme.colors.text,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.colors.background,
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                border: Border.all(
                  color: AppTheme.colors.primary,
                  width: 2,
                ),
              ),
              child: Text(
                inviteCode,
                style: TextStyle(
                  color: AppTheme.colors.primary,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                  letterSpacing: 2,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Share this code with friends to invite them to your team',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 14,
                fontFamily: AppTheme.fonts.secondary,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          NeonButton(
            text: 'COPY',
            onPressed: () {
              Clipboard.setData(ClipboardData(text: inviteCode));
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text('Invite code copied to clipboard'),
                  backgroundColor: AppTheme.colors.success,
                ),
              );
            },
            variant: NeonButtonVariant.primary,
          ),
        ],
      ),
    );
  }

  void _showLeaveTeamDialog(AppProvider appProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.colors.surface,
        title: Text(
          'Leave Team',
          style: TextStyle(
            color: AppTheme.colors.text,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        content: Text(
          'Are you sure you want to leave this team? You will lose access to team earnings and leaderboard progress.',
          style: TextStyle(
            color: AppTheme.colors.textSecondary,
            fontFamily: AppTheme.fonts.secondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'Cancel',
              style: TextStyle(color: AppTheme.colors.textSecondary),
            ),
          ),
          NeonButton(
            text: 'LEAVE',
            onPressed: () async {
              Navigator.of(context).pop();
              final success = await appProvider.leaveTeam();
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(success ? 'Left team successfully' : 'Failed to leave team'),
                    backgroundColor: success ? AppTheme.colors.success : AppTheme.colors.error,
                  ),
                );
              }
            },
            variant: NeonButtonVariant.error,
          ),
        ],
      ),
    );
  }
  
  void _showNotificationPanel(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.colors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.6,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Team Notifications',
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: Icon(
                    LucideIcons.x,
                    color: AppTheme.colors.textSecondary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Expanded(
              child: NotificationPanel(),
            ),
          ],
        ),
      ),
    );
  }
  
  void _showTeamSlotUnlockDialog(String slotType) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.colors.surface,
        title: Text(
          'Unlock Team Slot',
          style: TextStyle(
            color: AppTheme.colors.text,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        content: Text(
          'Do you want to unlock the $slotType slot for your team? This will enable new features for all team members.',
          style: TextStyle(
            color: AppTheme.colors.textSecondary,
            fontFamily: AppTheme.fonts.secondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'Cancel',
              style: TextStyle(color: AppTheme.colors.textSecondary),
            ),
          ),
          NeonButton(
            text: 'UNLOCK',
            onPressed: () async {
              Navigator.of(context).pop();
              final provider = context.read<AppProvider>();
              await provider.unlockTeamSlot(slotType);
              
              if (mounted && provider.error == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('$slotType slot unlocked successfully!'),
                    backgroundColor: AppTheme.colors.success,
                  ),
                );
              }
            },
            variant: NeonButtonVariant.primary,
          ),
        ],
      ),
    );
  }
}