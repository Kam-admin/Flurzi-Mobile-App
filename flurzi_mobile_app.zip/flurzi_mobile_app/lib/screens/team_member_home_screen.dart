import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../widgets/ad_banner.dart';
import '../services/currency_service.dart';
import 'timesheet_screen.dart';
import 'task_stats_screen.dart';
import 'withdrawal_screen.dart';

class TeamMemberHomeScreen extends StatefulWidget {
  const TeamMemberHomeScreen({super.key});

  @override
  State<TeamMemberHomeScreen> createState() => _TeamMemberHomeScreenState();
}

class _TeamMemberHomeScreenState extends State<TeamMemberHomeScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _slideAnimation;
  late Animation<double> _fadeAnimation;
  
  final CurrencyService _currencyService = CurrencyService();
  int _selectedIndex = 0;
  
  final List<Widget> _pages = [];
  final List<String> _pageTitles = ['Withdrawal', 'Timesheet', 'Task Stats'];
  final List<IconData> _pageIcons = [LucideIcons.wallet, LucideIcons.calendar, LucideIcons.barChart3];

  @override
  void initState() {
    super.initState();
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _slideAnimation = Tween<double>(
      begin: 30,
      end: 0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutBack,
    ));
    
    _fadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));
    
    _animationController.forward();
    
    // Initialize pages
    _pages.addAll([
      _buildWithdrawalPage(),
      _buildTimesheetPage(),
      _buildTaskStatsPage(),
    ]);
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.colors.background,
      body: Column(
        children: [
          // Header
          SafeArea(
            bottom: false,
            child: AnimatedBuilder(
              animation: _animationController,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, _slideAnimation.value),
                  child: Opacity(
                    opacity: _fadeAnimation.value,
                    child: _buildHeader(),
                  ),
                );
              },
            ),
          ),
          
          // Navigation tabs
          _buildNavigationTabs(),
          
          // Page content
          Expanded(
            child: AnimatedBuilder(
              animation: _animationController,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, _slideAnimation.value),
                  child: Opacity(
                    opacity: _fadeAnimation.value,
                    child: _pages[_selectedIndex],
                  ),
                );
              },
            ),
          ),
          
          // Ad banner
          Consumer<AppProvider>(
            builder: (context, appProvider, child) {
              return BottomAdBanner(
                onTap: () => appProvider.watchAd(),
                adText: 'Watch Ad & Earn More',
                isLoading: appProvider.isWatchingAd,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Consumer<AppProvider>(
      builder: (context, appProvider, child) {
        final user = appProvider.user;
        final realName = user?.preferences['realName'] ?? 'Team Member';
        
        return Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppTheme.colors.primary.withOpacity(0.2),
                AppTheme.colors.secondary.withOpacity(0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(AppTheme.borderRadius.xl),
            border: Border.all(
              color: AppTheme.colors.primary.withOpacity(0.5),
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: AppTheme.colors.primary.withOpacity(0.3),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            children: [
              // Avatar
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.colors.primary.withOpacity(0.2),
                  border: Border.all(
                    color: AppTheme.colors.primary,
                    width: 2,
                  ),
                ),
                child: Icon(
                  LucideIcons.user,
                  color: AppTheme.colors.primary,
                  size: 24,
                ),
              ),
              
              const SizedBox(width: 16),
              
              // User info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      realName,
                      style: TextStyle(
                        color: AppTheme.colors.text,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '@${user?.displayName ?? 'username'}',
                      style: TextStyle(
                        color: AppTheme.colors.textSecondary,
                        fontSize: 14,
                        fontFamily: AppTheme.fonts.secondary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.colors.secondary.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(
                          AppTheme.borderRadius.small,
                        ),
                        border: Border.all(
                          color: AppTheme.colors.secondary,
                          width: 1,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            LucideIcons.users,
                            color: AppTheme.colors.secondary,
                            size: 12,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Team Member',
                            style: TextStyle(
                              color: AppTheme.colors.secondary,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: AppTheme.fonts.primary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              // Earnings display
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    _currencyService.formatCurrency(
                      user?.availableBalance ?? 0.0,
                      user?.currency ?? 'GBP',
                    ),
                    style: TextStyle(
                      color: AppTheme.colors.success,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: AppTheme.fonts.primary,
                    ),
                  ),
                  Text(
                    'Available',
                    style: TextStyle(
                      color: AppTheme.colors.textSecondary,
                      fontSize: 12,
                      fontFamily: AppTheme.fonts.secondary,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildNavigationTabs() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Row(
        children: List.generate(_pageTitles.length, (index) {
          final isSelected = _selectedIndex == index;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedIndex = index),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppTheme.colors.primary
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(
                    AppTheme.borderRadius.medium,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _pageIcons[index],
                      color: isSelected
                          ? AppTheme.colors.background
                          : AppTheme.colors.textSecondary,
                      size: 16,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      _pageTitles[index],
                      style: TextStyle(
                        color: isSelected
                            ? AppTheme.colors.background
                            : AppTheme.colors.textSecondary,
                        fontSize: 14,
                        fontWeight: isSelected
                            ? FontWeight.bold
                            : FontWeight.normal,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildWithdrawalPage() {
    return Consumer<AppProvider>(
      builder: (context, appProvider, child) {
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Balance overview
              _buildBalanceCard(appProvider),
              
              const SizedBox(height: 20),
              
              // Withdrawal options
              _buildWithdrawalOptions(appProvider),
              
              const SizedBox(height: 20),
              
              // Recent transactions
              _buildRecentTransactions(appProvider),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTimesheetPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Availability Timesheet',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 24,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 8),
          
          Text(
            'Submit your availability for task allocation',
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: 16,
              fontFamily: AppTheme.fonts.secondary,
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Timesheet will be implemented in next step
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.colors.surface,
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
              border: Border.all(
                color: AppTheme.colors.border,
                width: 1,
              ),
            ),
            child: Center(
              child: Text(
                'Timesheet functionality coming soon...',
                style: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontSize: 16,
                  fontFamily: AppTheme.fonts.secondary,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTaskStatsPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Task Statistics',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 24,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 8),
          
          Text(
            'Team contributions and performance metrics',
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: 16,
              fontFamily: AppTheme.fonts.secondary,
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Task stats will be implemented in next step
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.colors.surface,
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
              border: Border.all(
                color: AppTheme.colors.border,
                width: 1,
              ),
            ),
            child: Center(
              child: Text(
                'Task statistics coming soon...',
                style: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontSize: 16,
                  fontFamily: AppTheme.fonts.secondary,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBalanceCard(AppProvider appProvider) {
    final user = appProvider.user;
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.colors.success.withOpacity(0.2),
            AppTheme.colors.primary.withOpacity(0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.success.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                LucideIcons.wallet,
                color: AppTheme.colors.success,
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Available Balance',
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          Text(
            _currencyService.formatCurrency(
              user?.availableBalance ?? 0.0,
              user?.currency ?? 'GBP',
            ),
            style: TextStyle(
              color: AppTheme.colors.success,
              fontSize: 32,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 8),
          
          Text(
            'Ready for withdrawal',
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: 14,
              fontFamily: AppTheme.fonts.secondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWithdrawalOptions(AppProvider appProvider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Withdrawal Options',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Withdrawal options will be implemented
          Text(
            'Withdrawal functionality coming soon...',
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: 14,
              fontFamily: AppTheme.fonts.secondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentTransactions(AppProvider appProvider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Recent Transactions',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 16),
          
          Text(
            'No transactions yet',
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: 14,
              fontFamily: AppTheme.fonts.secondary,
            ),
          ),
        ],
      ),
    );
  }
}