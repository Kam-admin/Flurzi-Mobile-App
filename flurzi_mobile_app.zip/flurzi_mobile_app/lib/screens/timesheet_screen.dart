import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../widgets/neon_button.dart';

class TimesheetScreen extends StatefulWidget {
  const TimesheetScreen({super.key});

  @override
  State<TimesheetScreen> createState() => _TimesheetScreenState();
}

class _TimesheetScreenState extends State<TimesheetScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _slideAnimation;
  late Animation<double> _fadeAnimation;
  
  final Map<String, Map<String, bool>> _availability = {};
  final List<String> _daysOfWeek = [
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
  ];
  final List<String> _timeSlots = [
    '09:00-12:00', '12:00-15:00', '15:00-18:00', '18:00-21:00', '21:00-00:00'
  ];
  
  bool _isLoading = false;
  String? _successMessage;

  @override
  void initState() {
    super.initState();
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _slideAnimation = Tween<double>(
      begin: 30,
      end: 0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutBack,
    ));
    
    _fadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));
    
    _animationController.forward();
    
    // Initialize availability map
    for (String day in _daysOfWeek) {
      _availability[day] = {};
      for (String slot in _timeSlots) {
        _availability[day]![slot] = false;
      }
    }
    
    _loadExistingAvailability();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _loadExistingAvailability() {
    final appProvider = context.read<AppProvider>();
    final user = appProvider.user;
    
    if (user?.preferences['availability'] != null) {
      final savedAvailability = Map<String, dynamic>.from(
        user!.preferences['availability'],
      );
      
      setState(() {
        for (String day in _daysOfWeek) {
          if (savedAvailability[day] != null) {
            _availability[day] = Map<String, bool>.from(
              savedAvailability[day],
            );
          }
        }
      });
    }
  }

  Future<void> _saveAvailability() async {
    setState(() {
      _isLoading = true;
      _successMessage = null;
    });
    
    try {
      final appProvider = context.read<AppProvider>();
      await appProvider.updateUserAvailability(_availability);
      
      setState(() {
        _successMessage = 'Availability updated successfully!';
        _isLoading = false;
      });
      
      // Clear success message after 3 seconds
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) {
          setState(() {
            _successMessage = null;
          });
        }
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to save availability: ${e.toString()}'),
          backgroundColor: AppTheme.colors.error,
        ),
      );
    }
  }

  void _toggleAvailability(String day, String slot) {
    setState(() {
      _availability[day]![slot] = !_availability[day]![slot]!;
    });
  }

  void _toggleFullDay(String day, bool available) {
    setState(() {
      for (String slot in _timeSlots) {
        _availability[day]![slot] = available;
      }
    });
  }

  int _getAvailableHours() {
    int totalHours = 0;
    for (String day in _daysOfWeek) {
      for (String slot in _timeSlots) {
        if (_availability[day]![slot]!) {
          totalHours += 3; // Each slot is 3 hours
        }
      }
    }
    return totalHours;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.colors.background,
      body: SafeArea(
        child: AnimatedBuilder(
          animation: _animationController,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(0, _slideAnimation.value),
              child: Opacity(
                opacity: _fadeAnimation.value,
                child: Column(
                  children: [
                    // Header
                    _buildHeader(),
                    
                    // Content
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Summary card
                            _buildSummaryCard(),
                            
                            const SizedBox(height: 20),
                            
                            // Availability grid
                            _buildAvailabilityGrid(),
                            
                            const SizedBox(height: 24),
                            
                            // Success message
                            if (_successMessage != null)
                              Container(
                                padding: const EdgeInsets.all(12),
                                margin: const EdgeInsets.only(bottom: 20),
                                decoration: BoxDecoration(
                                  color: AppTheme.colors.success.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(
                                    AppTheme.borderRadius.medium,
                                  ),
                                  border: Border.all(
                                    color: AppTheme.colors.success,
                                    width: 1,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      LucideIcons.checkCircle,
                                      color: AppTheme.colors.success,
                                      size: 16,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        _successMessage!,
                                        style: TextStyle(
                                          color: AppTheme.colors.success,
                                          fontSize: 14,
                                          fontFamily: AppTheme.fonts.secondary,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            
                            // Save button
                            NeonButton(
                              text: _isLoading ? 'Saving...' : 'Save Availability',
                              onPressed: _isLoading ? null : _saveAvailability,
                              isLoading: _isLoading,
                              width: double.infinity,
                            ),
                            
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.colors.surface,
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                border: Border.all(
                  color: AppTheme.colors.border,
                  width: 1,
                ),
              ),
              child: Icon(
                LucideIcons.arrowLeft,
                color: AppTheme.colors.primary,
                size: 20,
              ),
            ),
          ),
          
          const SizedBox(width: 16),
          
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Availability Timesheet',
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
                Text(
                  'Set your weekly availability',
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 14,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCard() {
    final availableHours = _getAvailableHours();
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.colors.primary.withOpacity(0.2),
            AppTheme.colors.secondary.withOpacity(0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.primary.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            LucideIcons.clock,
            color: AppTheme.colors.primary,
            size: 32,
          ),
          
          const SizedBox(width: 16),
          
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Weekly Availability',
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$availableHours hours selected',
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 14,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
              ],
            ),
          ),
          
          Text(
            '${availableHours}h',
            style: TextStyle(
              color: AppTheme.colors.primary,
              fontSize: 24,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAvailabilityGrid() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Select Your Available Time Slots',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Days of week
          ...List.generate(_daysOfWeek.length, (dayIndex) {
            final day = _daysOfWeek[dayIndex];
            final dayAvailability = _availability[day]!;
            final allSelected = dayAvailability.values.every((v) => v);
            final noneSelected = dayAvailability.values.every((v) => !v);
            
            return Column(
              children: [
                // Day header
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    color: AppTheme.colors.background,
                    borderRadius: BorderRadius.circular(
                      AppTheme.borderRadius.medium,
                    ),
                    border: Border.all(
                      color: AppTheme.colors.border,
                      width: 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          day,
                          style: TextStyle(
                            color: AppTheme.colors.text,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: AppTheme.fonts.primary,
                          ),
                        ),
                      ),
                      
                      // Quick select buttons
                      if (!allSelected)
                        GestureDetector(
                          onTap: () => _toggleFullDay(day, true),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.colors.success.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(
                                AppTheme.borderRadius.small,
                              ),
                            ),
                            child: Text(
                              'All',
                              style: TextStyle(
                                color: AppTheme.colors.success,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                fontFamily: AppTheme.fonts.primary,
                              ),
                            ),
                          ),
                        ),
                      
                      if (!noneSelected) ..[
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () => _toggleFullDay(day, false),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.colors.error.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(
                                AppTheme.borderRadius.small,
                              ),
                            ),
                            child: Text(
                              'None',
                              style: TextStyle(
                                color: AppTheme.colors.error,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                fontFamily: AppTheme.fonts.primary,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                
                const SizedBox(height: 8),
                
                // Time slots
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _timeSlots.map((slot) {
                    final isSelected = dayAvailability[slot]!;
                    
                    return GestureDetector(
                      onTap: () => _toggleAvailability(day, slot),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppTheme.colors.primary
                              : AppTheme.colors.background,
                          borderRadius: BorderRadius.circular(
                            AppTheme.borderRadius.small,
                          ),
                          border: Border.all(
                            color: isSelected
                                ? AppTheme.colors.primary
                                : AppTheme.colors.border,
                            width: 1,
                          ),
                        ),
                        child: Text(
                          slot,
                          style: TextStyle(
                            color: isSelected
                                ? AppTheme.colors.background
                                : AppTheme.colors.text,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            fontFamily: AppTheme.fonts.secondary,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                
                if (dayIndex < _daysOfWeek.length - 1)
                  const SizedBox(height: 16),
              ],
            );
          }),
        ],
      ),
    );
  }
}