import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../models/team_model.dart';
import '../models/user_model.dart';

class TaskStatsScreen extends StatefulWidget {
  const TaskStatsScreen({super.key});

  @override
  State<TaskStatsScreen> createState() => _TaskStatsScreenState();
}

class _TaskStatsScreenState extends State<TaskStatsScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _slideAnimation;
  late Animation<double> _fadeAnimation;
  
  bool _isLoading = true;
  List<TeamMember> _teamMembers = [];
  Map<String, double> _memberContributions = {};
  Map<String, double> _memberEarnings = {};
  double _totalTeamEarnings = 0;
  String _selectedPeriod = 'This Week';
  
  final List<String> _periods = ['This Week', 'This Month', 'All Time'];

  @override
  void initState() {
    super.initState();
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _slideAnimation = Tween<double>(
      begin: 30,
      end: 0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutBack,
    ));
    
    _fadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));
    
    _animationController.forward();
    _loadTaskStats();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadTaskStats() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final appProvider = context.read<AppProvider>();
      final team = appProvider.team;
      
      if (team != null) {
        // Load team members and their stats
        _teamMembers = team.members;
        
        // Calculate contributions and earnings
        // This would typically come from your backend API
        _calculateMemberStats();
      }
      
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to load task stats: ${e.toString()}'),
          backgroundColor: AppTheme.colors.error,
        ),
      );
    }
  }

  void _calculateMemberStats() {
    // Mock data - in real app, this would come from backend
    _totalTeamEarnings = 1250.75;
    
    for (int i = 0; i < _teamMembers.length; i++) {
      final member = _teamMembers[i];
      
      // Mock contribution percentages
      final contributions = [25.5, 22.3, 18.7, 15.2, 12.1, 6.2];
      final earnings = [318.94, 278.67, 233.89, 190.11, 151.34, 77.55];
      
      if (i < contributions.length) {
        _memberContributions[member.userId] = contributions[i];
        _memberEarnings[member.userId] = earnings[i];
      } else {
        _memberContributions[member.userId] = 0;
        _memberEarnings[member.userId] = 0;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.colors.background,
      body: SafeArea(
        child: AnimatedBuilder(
          animation: _animationController,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(0, _slideAnimation.value),
              child: Opacity(
                opacity: _fadeAnimation.value,
                child: Column(
                  children: [
                    // Header
                    _buildHeader(),
                    
                    // Content
                    Expanded(
                      child: _isLoading
                          ? _buildLoadingState()
                          : SingleChildScrollView(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Period selector
                                  _buildPeriodSelector(),
                                  
                                  const SizedBox(height: 20),
                                  
                                  // Team overview
                                  _buildTeamOverview(),
                                  
                                  const SizedBox(height: 20),
                                  
                                  // Contribution chart
                                  _buildContributionChart(),
                                  
                                  const SizedBox(height: 20),
                                  
                                  // Member list
                                  _buildMemberList(),
                                  
                                  const SizedBox(height: 20),
                                ],
                              ),
                            ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.colors.surface,
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                border: Border.all(
                  color: AppTheme.colors.border,
                  width: 1,
                ),
              ),
              child: Icon(
                LucideIcons.arrowLeft,
                color: AppTheme.colors.primary,
                size: 20,
              ),
            ),
          ),
          
          const SizedBox(width: 16),
          
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Task Statistics',
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
                Text(
                  'Team contributions & earnings',
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 14,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(AppTheme.colors.primary),
          ),
          const SizedBox(height: 16),
          Text(
            'Loading task statistics...',
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: 16,
              fontFamily: AppTheme.fonts.secondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPeriodSelector() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Row(
        children: _periods.map((period) {
          final isSelected = period == _selectedPeriod;
          
          return Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedPeriod = period;
                });
                _loadTaskStats();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppTheme.colors.primary
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(
                    AppTheme.borderRadius.small,
                  ),
                ),
                child: Text(
                  period,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isSelected
                        ? AppTheme.colors.background
                        : AppTheme.colors.text,
                    fontSize: 14,
                    fontWeight: isSelected
                        ? FontWeight.bold
                        : FontWeight.normal,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildTeamOverview() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.colors.primary.withOpacity(0.2),
            AppTheme.colors.secondary.withOpacity(0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.primary.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                LucideIcons.trendingUp,
                color: AppTheme.colors.primary,
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Team Performance',
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  'Total Earnings',
                  '£${_totalTeamEarnings.toStringAsFixed(2)}',
                  LucideIcons.dollarSign,
                  AppTheme.colors.success,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildStatCard(
                  'Active Members',
                  '${_teamMembers.length}',
                  LucideIcons.users,
                  AppTheme.colors.primary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                icon,
                color: color,
                size: 16,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 12,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContributionChart() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Contribution Breakdown',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Simple bar chart representation
          ...List.generate(_teamMembers.length, (index) {
            if (index >= 5) return const SizedBox.shrink(); // Show top 5
            
            final member = _teamMembers[index];
            final contribution = _memberContributions[member.userId] ?? 0;
            final maxContribution = _memberContributions.values.isNotEmpty
                ? _memberContributions.values.reduce((a, b) => a > b ? a : b)
                : 1;
            
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        member.displayName,
                        style: TextStyle(
                          color: AppTheme.colors.text,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                      Text(
                        '${contribution.toStringAsFixed(1)}%',
                        style: TextStyle(
                          color: AppTheme.colors.primary,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Container(
                    height: 8,
                    decoration: BoxDecoration(
                      color: AppTheme.colors.background,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: contribution / maxContribution,
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              AppTheme.colors.primary,
                              AppTheme.colors.secondary,
                            ],
                          ),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildMemberList() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Member Earnings',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 16),
          
          ...List.generate(_teamMembers.length, (index) {
            final member = _teamMembers[index];
            final earnings = _memberEarnings[member.userId] ?? 0;
            final contribution = _memberContributions[member.userId] ?? 0;
            
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.colors.background,
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                border: Border.all(
                  color: AppTheme.colors.border,
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  // Avatar
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          AppTheme.colors.primary,
                          AppTheme.colors.secondary,
                        ],
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(
                      child: Text(
                        member.displayName.isNotEmpty
                            ? member.displayName[0].toUpperCase()
                            : 'U',
                        style: TextStyle(
                          color: AppTheme.colors.background,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                    ),
                  ),
                  
                  const SizedBox(width: 12),
                  
                  // Member info
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          member.displayName,
                          style: TextStyle(
                            color: AppTheme.colors.text,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: AppTheme.fonts.primary,
                          ),
                        ),
                        Text(
                          '${contribution.toStringAsFixed(1)}% contribution',
                          style: TextStyle(
                            color: AppTheme.colors.textSecondary,
                            fontSize: 12,
                            fontFamily: AppTheme.fonts.secondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // Earnings
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '£${earnings.toStringAsFixed(2)}',
                        style: TextStyle(
                          color: AppTheme.colors.success,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                      if (index < 5)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.colors.primary.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(
                              AppTheme.borderRadius.small,
                            ),
                          ),
                          child: Text(
                            'TOP ${index + 1}',
                            style: TextStyle(
                              color: AppTheme.colors.primary,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              fontFamily: AppTheme.fonts.primary,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}