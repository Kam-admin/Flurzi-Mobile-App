# Flurzi Mining App

A Flutter-based, production-ready mobile app that serves as a dark-themed, mining-dashboard-style, reward-based ad-watching platform with comprehensive features and SDK integration capabilities.

## 🚀 Features

### Core Functionality
- **20 Tier Cards**: Dynamic unlock/renew system with progressive costs
- **Ad Watching System**: Reward-based ad viewing with offline caching
- **Team System**: Join teams, share earnings, and collaborate
- **Weekly Leaderboards**: Compete for £4,500 in weekly prizes
- **Quest System**: Complete daily, weekly, and special tasks
- **Multi-Currency Wallet**: PayPal and bank withdrawal support
- **Real-time Sync**: Firebase-powered backend with offline support

### Advanced Features
- **Auto-play Upgrade**: Premium feature for enhanced ad watching
- **Currency Conversion**: Global support with real-time exchange rates
- **Developer Mode**: SDK testing and integration tools
- **Remote Config**: Dynamic feature toggles and settings
- **Analytics Integration**: Comprehensive user behavior tracking

## 🏗️ Architecture

### Tech Stack
- **Frontend**: Flutter with Material 3 design
- **Backend**: Firebase (Firestore, Functions, Auth, Remote Config)
- **State Management**: Provider pattern
- **Navigation**: GoRouter for declarative routing
- **UI Theme**: Dark mining dashboard aesthetic with neon accents

### Project Structure
```
lib/
├── constants/
│   └── theme.dart              # App theme and color definitions
├── models/
│   ├── tier_model.dart         # Tier card data structure
│   ├── user_model.dart         # User profile and stats
│   ├── team_model.dart         # Team and member data
│   └── quest_model.dart        # Quest and leaderboard models
├── providers/
│   └── app_provider.dart       # Global state management
├── screens/
│   ├── onboarding_screen.dart  # User onboarding flow
│   ├── tutorial_screen.dart    # App tutorial
│   ├── home_screen.dart        # Main navigation hub
│   ├── mining_screen.dart      # Tier cards dashboard
│   ├── team_screen.dart        # Team management
│   ├── leaderboard_screen.dart # Rankings and competitions
│   ├── quests_screen.dart      # Task management
│   ├── wallet_screen.dart      # Earnings and withdrawals
│   └── profile_screen.dart     # User settings and developer tools
├── services/
│   ├── firebase_service.dart   # Firebase operations
│   ├── currency_service.dart   # Exchange rates and conversions
│   ├── ad_service.dart         # Ad management and caching
│   └── sdk_service.dart        # External API and SDK endpoints
├── widgets/
│   ├── neon_button.dart        # Custom UI components
│   └── tier_card.dart          # Mining tier display widget
└── main.dart                   # App entry point
```

## 🔧 Setup Instructions

### Prerequisites
- Flutter SDK (3.0+)
- Firebase project setup
- Android Studio / VS Code
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd flurzi_mining_app
   ```

2. **Install dependencies**
   ```bash
   flutter pub get
   ```

3. **Firebase Setup**
   - Create a Firebase project at [Firebase Console](https://console.firebase.google.com)
   - Enable Authentication, Firestore, Functions, and Remote Config
   - Download configuration files:
     - `google-services.json` for Android (place in `android/app/`)
     - `GoogleService-Info.plist` for iOS (place in `ios/Runner/`)
   - Update `lib/firebase_options.dart` with your project credentials

4. **Run the app**
   ```bash
   flutter run
   ```

## 📱 App Features Detail

### Mining System
- **20 Progressive Tiers**: From Bronze to Diamond levels
- **Dynamic Pricing**: Tier costs calculated as `£0.03 = 600 ads watched`
- **30-Day Timer**: Automatic tier expiration and renewal system
- **Progress Tracking**: Real-time ad watch progress and earnings

### Team Features
- **Team Creation**: Form teams with custom names and descriptions
- **Invite System**: Share invite codes for team recruitment
- **Earnings Sharing**: Configurable team earning distribution
- **Member Management**: Role-based permissions and activity tracking

### Leaderboard System
- **Weekly Competitions**: £4,500 prize pool distribution
- **Individual Rankings**: Personal performance tracking
- **Team Rankings**: Collaborative competition
- **Real-time Updates**: Live leaderboard refresh

### Wallet & Payments
- **Multi-Currency Support**: Global currency conversion
- **PayPal Integration**: Direct PayPal withdrawals
- **Bank Transfers**: Traditional banking support
- **Transaction History**: Complete withdrawal tracking
- **Fee Calculation**: Transparent fee structure

## 🔌 SDK & API Integration

### Post-Launch SDK Features

After app store deployment, Flurzi exposes secure APIs for external integrations:

#### 1. RESTful API Endpoints
```
GET  /v1/user/progress        # Query user ad progress
POST /v1/user/reward          # Trigger external rewards
GET  /v1/team/data            # Read team structures
POST /v1/quest/submit         # Submit third-party quests
GET  /v1/leaderboard/snapshot # Get current rankings
```

#### 2. Firebase Callable Functions
- `claimTierReward(tierId)` - Process tier completions
- `getUserEarnings()` - Retrieve user financial data
- `getLeaderboardSnapshot()` - Export competition data
- `submitQuestAnswer(questId, payload)` - Handle quest submissions

#### 3. Authentication & Security
- **OAuth2 Integration**: Secure token-based access
- **Firebase App Check**: Anti-abuse protection
- **Rate Limiting**: API usage controls
- **Audit Logging**: Complete access tracking

#### 4. Developer Tools
- **Developer Mode**: In-app SDK testing interface
- **Token Generation**: Secure API key management
- **Sandbox Environment**: Safe testing environment
- **Documentation Access**: Integrated API docs

### Remote Configuration
- **Feature Toggles**: Dynamic feature control
- **Regional Settings**: Location-based configurations
- **A/B Testing**: Experimental feature rollouts
- **Emergency Controls**: Instant feature disable capabilities

## 🚀 Deployment

### Pre-Deployment Checklist
- [ ] Firebase project configured
- [ ] App signing certificates generated
- [ ] Store listings prepared (Google Play & App Store)
- [ ] Privacy policy and terms of service finalized
- [ ] Payment processing verified
- [ ] SDK documentation completed

### Store Deployment
1. **Android (Google Play)**
   ```bash
   flutter build appbundle --release
   ```

2. **iOS (App Store)**
   ```bash
   flutter build ios --release
   ```

### Post-Deployment SDK Activation
1. Enable Remote Config SDK switches
2. Deploy Firebase Cloud Functions
3. Configure API rate limits
4. Set up monitoring and analytics
5. Activate developer portal access

## 📊 Analytics & Monitoring

- **Firebase Analytics**: User behavior tracking
- **Crashlytics**: Error monitoring and reporting
- **Performance Monitoring**: App performance metrics
- **Custom Events**: Business-specific tracking
- **SDK Usage Analytics**: API consumption monitoring

## 🔒 Security Features

- **Firebase App Check**: Anti-abuse protection
- **Secure API Endpoints**: Token-based authentication
- **Data Encryption**: End-to-end data protection
- **Privacy Controls**: GDPR compliance features
- **Audit Trails**: Complete action logging

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Implement changes with tests
4. Submit a pull request
5. Ensure CI/CD passes

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 📞 Support

- **Documentation**: [API Documentation](https://docs.flurzi.app)
- **Developer Portal**: [SDK Integration Guide](https://developers.flurzi.app)
- **Support Email**: support@flurzi.app
- **Community**: [Discord Server](https://discord.gg/flurzi)

---

**Flurzi Mining App** - Transforming ad engagement into rewarding experiences with comprehensive SDK integration for endless possibilities.
