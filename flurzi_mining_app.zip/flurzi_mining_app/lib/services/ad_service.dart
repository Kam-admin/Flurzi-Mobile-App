import 'dart:async';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../models/tier_model.dart';
import '../models/user_model.dart';
import 'firebase_service.dart';
import 'currency_service.dart';

class AdService {
  static final AdService _instance = AdService._internal();
  factory AdService() => _instance;
  AdService._internal();

  final FirebaseService _firebaseService = FirebaseService();
  final CurrencyService _currencyService = CurrencyService();
  final Connectivity _connectivity = Connectivity();

  static const String _offlineAdsKey = 'offline_ads';
  static const String _dailyAdsCountKey = 'daily_ads_count';
  static const String _lastAdDateKey = 'last_ad_date';
  static const String _cachedAdsKey = 'cached_ads';

  List<OfflineAdRecord> _offlineAds = [];
  List<CachedAd> _cachedAds = [];
  int _dailyAdsCount = 0;
  DateTime? _lastAdDate;
  bool _isOnline = true;
  StreamSubscription<ConnectivityResult>? _connectivitySubscription;

  Future<void> initialize() async {
    await _loadOfflineData();
    await _loadCachedAds();
    _setupConnectivityListener();
    await _syncOfflineAds();
  }

  void _setupConnectivityListener() {
    _connectivitySubscription = _connectivity.onConnectivityChanged.listen((result) {
      final wasOnline = _isOnline;
      _isOnline = result != ConnectivityResult.none;
      
      if (!wasOnline && _isOnline) {
        // Just came back online, sync offline ads
        _syncOfflineAds();
      }
    });
  }

  Future<void> _loadOfflineData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Load offline ads
      final offlineAdsJson = prefs.getString(_offlineAdsKey);
      if (offlineAdsJson != null) {
        final List<dynamic> adsList = json.decode(offlineAdsJson);
        _offlineAds = adsList.map((ad) => OfflineAdRecord.fromJson(ad)).toList();
      }
      
      // Load daily count
      _dailyAdsCount = prefs.getInt(_dailyAdsCountKey) ?? 0;
      
      // Load last ad date
      final lastAdDateMs = prefs.getInt(_lastAdDateKey);
      if (lastAdDateMs != null) {
        _lastAdDate = DateTime.fromMillisecondsSinceEpoch(lastAdDateMs);
        
        // Reset daily count if it's a new day
        if (_lastAdDate != null && !_isSameDay(_lastAdDate!, DateTime.now())) {
          _dailyAdsCount = 0;
          await prefs.setInt(_dailyAdsCountKey, 0);
        }
      }
    } catch (e) {
      print('Error loading offline data: $e');
    }
  }

  Future<void> _loadCachedAds() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedAdsJson = prefs.getString(_cachedAdsKey);
      if (cachedAdsJson != null) {
        final List<dynamic> adsList = json.decode(cachedAdsJson);
        _cachedAds = adsList.map((ad) => CachedAd.fromJson(ad)).toList();
      }
    } catch (e) {
      print('Error loading cached ads: $e');
    }
  }

  Future<void> _saveOfflineData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_offlineAdsKey, json.encode(_offlineAds.map((ad) => ad.toJson()).toList()));
      await prefs.setInt(_dailyAdsCountKey, _dailyAdsCount);
      if (_lastAdDate != null) {
        await prefs.setInt(_lastAdDateKey, _lastAdDate!.millisecondsSinceEpoch);
      }
    } catch (e) {
      print('Error saving offline data: $e');
    }
  }

  Future<void> _saveCachedAds() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_cachedAdsKey, json.encode(_cachedAds.map((ad) => ad.toJson()).toList()));
    } catch (e) {
      print('Error saving cached ads: $e');
    }
  }

  bool _isSameDay(DateTime date1, DateTime date2) {
    return date1.year == date2.year && date1.month == date2.month && date1.day == date2.day;
  }

  // Watch an ad for a specific tier
  Future<AdWatchResult> watchAd(String userId, TierModel tier, {bool isAutoPlay = false}) async {
    try {
      // Check daily limit
      if (_dailyAdsCount >= _firebaseService.maxDailyAds) {
        return AdWatchResult(
          success: false,
          message: 'Daily ad limit reached',
          earnings: 0.0,
        );
      }

      // Calculate earnings
      final earnings = _calculateAdEarnings(tier);
      
      // Simulate ad watching delay (unless auto-play)
      if (!isAutoPlay) {
        await Future.delayed(const Duration(seconds: 30)); // Simulate 30-second ad
      } else {
        await Future.delayed(const Duration(seconds: 5)); // Auto-play delay
      }

      final adRecord = OfflineAdRecord(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        userId: userId,
        tierId: tier.id,
        earnings: earnings,
        watchedAt: DateTime.now(),
        isAutoPlay: isAutoPlay,
        synced: false,
      );

      // Update counters
      _dailyAdsCount++;
      _lastAdDate = DateTime.now();
      _offlineAds.add(adRecord);
      await _saveOfflineData();

      // Try to sync immediately if online
      if (_isOnline) {
        await _syncSingleAd(adRecord);
      }

      return AdWatchResult(
        success: true,
        message: 'Ad watched successfully',
        earnings: earnings,
        adRecord: adRecord,
      );
    } catch (e) {
      print('Error watching ad: $e');
      return AdWatchResult(
        success: false,
        message: 'Failed to watch ad: $e',
        earnings: 0.0,
      );
    }
  }

  double _calculateAdEarnings(TierModel tier) {
    // Base earnings per ad (in GBP)
    const baseEarningsPerAd = 0.0001; // £0.0001 per ad
    
    // Tier multiplier
    final tierMultiplier = tier.tierNumber * 0.1;
    
    return baseEarningsPerAd * (1 + tierMultiplier);
  }

  Future<void> _syncSingleAd(OfflineAdRecord adRecord) async {
    try {
      await _firebaseService.recordAdWatch(
        adRecord.userId,
        adRecord.tierId,
        adRecord.earnings,
      );
      
      adRecord.synced = true;
      await _saveOfflineData();
    } catch (e) {
      print('Error syncing single ad: $e');
    }
  }

  Future<void> _syncOfflineAds() async {
    if (!_isOnline || _offlineAds.isEmpty) return;

    final unsyncedAds = _offlineAds.where((ad) => !ad.synced).toList();
    
    for (final ad in unsyncedAds) {
      try {
        await _firebaseService.recordAdWatch(
          ad.userId,
          ad.tierId,
          ad.earnings,
        );
        
        ad.synced = true;
      } catch (e) {
        print('Error syncing ad ${ad.id}: $e');
        break; // Stop syncing if there's an error
      }
    }
    
    // Remove old synced ads (keep last 100)
    _offlineAds.removeWhere((ad) => ad.synced && 
        DateTime.now().difference(ad.watchedAt).inDays > 7);
    
    await _saveOfflineData();
  }

  // Cache ads for offline viewing
  Future<void> cacheAdsForOffline({int count = 50}) async {
    try {
      // In a real implementation, this would download ad content
      // For now, we'll simulate cached ad data
      
      final newCachedAds = List.generate(count, (index) => CachedAd(
        id: 'cached_${DateTime.now().millisecondsSinceEpoch}_$index',
        title: 'Cached Ad ${index + 1}',
        description: 'This is a cached advertisement',
        duration: 30,
        cachedAt: DateTime.now(),
        expiresAt: DateTime.now().add(const Duration(days: 7)),
      ));
      
      _cachedAds.addAll(newCachedAds);
      
      // Remove expired cached ads
      _cachedAds.removeWhere((ad) => ad.isExpired);
      
      await _saveCachedAds();
    } catch (e) {
      print('Error caching ads: $e');
    }
  }

  // Get available cached ads
  List<CachedAd> getAvailableCachedAds() {
    return _cachedAds.where((ad) => !ad.isExpired).toList();
  }

  // Check if user can watch more ads today
  bool canWatchMoreAds() {
    return _dailyAdsCount < _firebaseService.maxDailyAds;
  }

  // Get remaining ads for today
  int getRemainingAdsToday() {
    return (_firebaseService.maxDailyAds - _dailyAdsCount).clamp(0, _firebaseService.maxDailyAds);
  }

  // Get daily progress
  double getDailyProgress() {
    return (_dailyAdsCount / _firebaseService.maxDailyAds).clamp(0.0, 1.0);
  }

  // Get offline ads count
  int getOfflineAdsCount() {
    return _offlineAds.where((ad) => !ad.synced).length;
  }

  // Force sync offline ads
  Future<bool> forceSyncOfflineAds() async {
    try {
      await _syncOfflineAds();
      return true;
    } catch (e) {
      print('Error force syncing ads: $e');
      return false;
    }
  }

  void dispose() {
    _connectivitySubscription?.cancel();
  }

  // Getters
  int get dailyAdsWatched => _dailyAdsCount;
  bool get isOnline => _isOnline;
  List<OfflineAdRecord> get offlineAds => List.unmodifiable(_offlineAds);
}

class AdWatchResult {
  final bool success;
  final String message;
  final double earnings;
  final OfflineAdRecord? adRecord;

  AdWatchResult({
    required this.success,
    required this.message,
    required this.earnings,
    this.adRecord,
  });
}

class OfflineAdRecord {
  final String id;
  final String userId;
  final String tierId;
  final double earnings;
  final DateTime watchedAt;
  final bool isAutoPlay;
  bool synced;

  OfflineAdRecord({
    required this.id,
    required this.userId,
    required this.tierId,
    required this.earnings,
    required this.watchedAt,
    this.isAutoPlay = false,
    this.synced = false,
  });

  factory OfflineAdRecord.fromJson(Map<String, dynamic> json) {
    return OfflineAdRecord(
      id: json['id'] ?? '',
      userId: json['userId'] ?? '',
      tierId: json['tierId'] ?? '',
      earnings: (json['earnings'] ?? 0.0).toDouble(),
      watchedAt: DateTime.parse(json['watchedAt']),
      isAutoPlay: json['isAutoPlay'] ?? false,
      synced: json['synced'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'tierId': tierId,
      'earnings': earnings,
      'watchedAt': watchedAt.toIso8601String(),
      'isAutoPlay': isAutoPlay,
      'synced': synced,
    };
  }
}

class CachedAd {
  final String id;
  final String title;
  final String description;
  final int duration; // in seconds
  final DateTime cachedAt;
  final DateTime expiresAt;

  CachedAd({
    required this.id,
    required this.title,
    required this.description,
    required this.duration,
    required this.cachedAt,
    required this.expiresAt,
  });

  factory CachedAd.fromJson(Map<String, dynamic> json) {
    return CachedAd(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      duration: json['duration'] ?? 30,
      cachedAt: DateTime.parse(json['cachedAt']),
      expiresAt: DateTime.parse(json['expiresAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'duration': duration,
      'cachedAt': cachedAt.toIso8601String(),
      'expiresAt': expiresAt.toIso8601String(),
    };
  }

  bool get isExpired => DateTime.now().isAfter(expiresAt);
}