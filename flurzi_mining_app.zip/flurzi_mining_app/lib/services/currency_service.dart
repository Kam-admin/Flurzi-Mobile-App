import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class CurrencyService {
  static final CurrencyService _instance = CurrencyService._internal();
  factory CurrencyService() => _instance;
  CurrencyService._internal();

  static const String _baseUrl = 'https://api.exchangerate-api.com/v4/latest';
  static const String _cacheKey = 'currency_rates';
  static const String _cacheTimeKey = 'currency_cache_time';
  static const Duration _cacheExpiry = Duration(hours: 1);

  Map<String, double> _cachedRates = {};
  DateTime? _lastCacheTime;

  // Supported currencies
  static const Map<String, String> supportedCurrencies = {
    'GBP': '£',
    'USD': '\$',
    'EUR': '€',
    'CAD': 'C\$',
    'AUD': 'A\$',
    'JPY': '¥',
    'CHF': 'CHF',
    'CNY': '¥',
    'INR': '₹',
    'BRL': 'R\$',
  };

  Future<void> initialize() async {
    await _loadCachedRates();
    if (_shouldRefreshRates()) {
      await _fetchLatestRates();
    }
  }

  Future<void> _loadCachedRates() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final ratesJson = prefs.getString(_cacheKey);
      final cacheTimeMs = prefs.getInt(_cacheTimeKey);
      
      if (ratesJson != null && cacheTimeMs != null) {
        _cachedRates = Map<String, double>.from(json.decode(ratesJson));
        _lastCacheTime = DateTime.fromMillisecondsSinceEpoch(cacheTimeMs);
      }
    } catch (e) {
      print('Error loading cached rates: $e');
    }
  }

  Future<void> _saveCachedRates() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_cacheKey, json.encode(_cachedRates));
      await prefs.setInt(_cacheTimeKey, DateTime.now().millisecondsSinceEpoch);
    } catch (e) {
      print('Error saving cached rates: $e');
    }
  }

  bool _shouldRefreshRates() {
    if (_lastCacheTime == null || _cachedRates.isEmpty) return true;
    return DateTime.now().difference(_lastCacheTime!) > _cacheExpiry;
  }

  Future<bool> _fetchLatestRates() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/GBP'),
        headers: {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        _cachedRates = Map<String, double>.from(data['rates']);
        _cachedRates['GBP'] = 1.0; // Base currency
        _lastCacheTime = DateTime.now();
        await _saveCachedRates();
        return true;
      }
    } catch (e) {
      print('Error fetching currency rates: $e');
    }
    return false;
  }

  double convertFromGBP(double gbpAmount, String toCurrency) {
    if (toCurrency == 'GBP') return gbpAmount;
    
    final rate = _cachedRates[toCurrency];
    if (rate == null) {
      print('Currency rate not found for $toCurrency');
      return gbpAmount; // Fallback to GBP
    }
    
    return gbpAmount * rate;
  }

  double convertToGBP(double amount, String fromCurrency) {
    if (fromCurrency == 'GBP') return amount;
    
    final rate = _cachedRates[fromCurrency];
    if (rate == null) {
      print('Currency rate not found for $fromCurrency');
      return amount; // Fallback
    }
    
    return amount / rate;
  }

  double convert(double amount, String fromCurrency, String toCurrency) {
    if (fromCurrency == toCurrency) return amount;
    
    // Convert to GBP first, then to target currency
    final gbpAmount = convertToGBP(amount, fromCurrency);
    return convertFromGBP(gbpAmount, toCurrency);
  }

  String formatCurrency(double amount, String currency) {
    final symbol = supportedCurrencies[currency] ?? currency;
    
    // Format based on currency
    switch (currency) {
      case 'JPY':
      case 'CNY':
        return '$symbol${amount.toStringAsFixed(0)}';
      default:
        return '$symbol${amount.toStringAsFixed(2)}';
    }
  }

  String formatGBP(double amount) {
    return formatCurrency(amount, 'GBP');
  }

  // Get user's local currency based on country
  String getCurrencyForCountry(String countryCode) {
    const countryToCurrency = {
      'GB': 'GBP',
      'US': 'USD',
      'CA': 'CAD',
      'AU': 'AUD',
      'DE': 'EUR',
      'FR': 'EUR',
      'IT': 'EUR',
      'ES': 'EUR',
      'NL': 'EUR',
      'JP': 'JPY',
      'CH': 'CHF',
      'CN': 'CNY',
      'IN': 'INR',
      'BR': 'BRL',
    };
    
    return countryToCurrency[countryCode] ?? 'GBP';
  }

  // Calculate tier unlock cost in user's currency
  double getTierUnlockCost(int tierNumber, String userCurrency) {
    // Base formula: £0.03 per tier level
    final gbpCost = 0.03 * tierNumber;
    return convertFromGBP(gbpCost, userCurrency);
  }

  // Calculate ads required for tier unlock
  int getAdsRequiredForTier(int tierNumber) {
    // Formula: £0.03 = 600 ads watched
    // So each tier requires tierNumber * 600 ads
    return tierNumber * 600;
  }

  // Calculate daily earnings for tier
  double getTierDailyEarnings(int tierNumber, String userCurrency) {
    // Base earnings in GBP (example formula)
    final gbpEarnings = 0.01 * tierNumber;
    return convertFromGBP(gbpEarnings, userCurrency);
  }

  // Validate withdrawal amount
  bool isValidWithdrawalAmount(double amount, String currency) {
    // Minimum withdrawal amounts by currency
    const minimumAmounts = {
      'GBP': 5.0,
      'USD': 6.0,
      'EUR': 5.5,
      'CAD': 7.0,
      'AUD': 8.0,
      'JPY': 600.0,
      'CHF': 5.5,
      'CNY': 40.0,
      'INR': 400.0,
      'BRL': 25.0,
    };
    
    final minimum = minimumAmounts[currency] ?? 5.0;
    return amount >= minimum;
  }

  double getMinimumWithdrawal(String currency) {
    const minimumAmounts = {
      'GBP': 5.0,
      'USD': 6.0,
      'EUR': 5.5,
      'CAD': 7.0,
      'AUD': 8.0,
      'JPY': 600.0,
      'CHF': 5.5,
      'CNY': 40.0,
      'INR': 400.0,
      'BRL': 25.0,
    };
    
    return minimumAmounts[currency] ?? 5.0;
  }

  // Calculate processing fees
  double calculateWithdrawalFee(double amount, String currency, String method) {
    // PayPal fees: 2.9% + fixed fee
    // Bank transfer: Fixed fee
    
    if (method == 'paypal') {
      const fixedFees = {
        'GBP': 0.30,
        'USD': 0.30,
        'EUR': 0.35,
        'CAD': 0.30,
        'AUD': 0.30,
        'JPY': 40.0,
        'CHF': 0.55,
        'CNY': 2.3,
        'INR': 15.0,
        'BRL': 0.60,
      };
      
      final fixedFee = fixedFees[currency] ?? 0.30;
      return (amount * 0.029) + fixedFee;
    } else {
      // Bank transfer fixed fees
      const bankFees = {
        'GBP': 1.0,
        'USD': 1.5,
        'EUR': 1.2,
        'CAD': 2.0,
        'AUD': 2.0,
        'JPY': 150.0,
        'CHF': 2.0,
        'CNY': 10.0,
        'INR': 50.0,
        'BRL': 5.0,
      };
      
      return bankFees[currency] ?? 1.0;
    }
  }

  Future<void> refreshRates() async {
    await _fetchLatestRates();
  }

  Map<String, double> get currentRates => Map.unmodifiable(_cachedRates);
  DateTime? get lastUpdateTime => _lastCacheTime;
}