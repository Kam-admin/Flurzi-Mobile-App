import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_functions/firebase_functions.dart';
import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import '../models/user_model.dart';
import '../models/tier_model.dart';
import '../models/team_model.dart';
import '../models/quest_model.dart';

class FirebaseService {
  static final FirebaseService _instance = FirebaseService._internal();
  factory FirebaseService() => _instance;
  FirebaseService._internal();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseFunctions _functions = FirebaseFunctions.instance;
  final FirebaseRemoteConfig _remoteConfig = FirebaseRemoteConfig.instance;
  final FirebaseAnalytics _analytics = FirebaseAnalytics.instance;

  // Initialize Firebase services
  Future<void> initialize() async {
    await Firebase.initializeApp();
    await FirebaseAppCheck.instance.activate(
      webRecaptchaSiteKey: 'your-recaptcha-site-key',
      androidProvider: AndroidProvider.debug,
      appleProvider: AppleProvider.debug,
    );
    await _initializeRemoteConfig();
  }

  Future<void> _initializeRemoteConfig() async {
    await _remoteConfig.setConfigSettings(RemoteConfigSettings(
      fetchTimeout: const Duration(minutes: 1),
      minimumFetchInterval: const Duration(hours: 1),
    ));
    
    await _remoteConfig.setDefaults({
      'sdk_enabled': true,
      'max_daily_ads': 100,
      'tier_unlock_formula': '0.03',
      'weekly_prize_pool': 4500.0,
      'auto_play_price': 5.99,
    });
    
    await _remoteConfig.fetchAndActivate();
  }

  // Authentication methods
  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<UserCredential?> signInWithGoogle() async {
    try {
      // Implement Google Sign-In
      // This would require google_sign_in package
      throw UnimplementedError('Google Sign-In not implemented');
    } catch (e) {
      print('Google Sign-In error: $e');
      return null;
    }
  }

  Future<UserCredential?> signInWithApple() async {
    try {
      // Implement Apple Sign-In
      // This would require sign_in_with_apple package
      throw UnimplementedError('Apple Sign-In not implemented');
    } catch (e) {
      print('Apple Sign-In error: $e');
      return null;
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  // User data methods
  Future<UserModel?> getUserData(String userId) async {
    try {
      final doc = await _firestore.collection('users').doc(userId).get();
      if (doc.exists) {
        return UserModel.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      print('Error getting user data: $e');
      return null;
    }
  }

  Future<void> createOrUpdateUser(UserModel user) async {
    try {
      await _firestore.collection('users').doc(user.id).set(
        user.toJson(),
        SetOptions(merge: true),
      );
    } catch (e) {
      print('Error creating/updating user: $e');
    }
  }

  Stream<UserModel?> getUserStream(String userId) {
    return _firestore
        .collection('users')
        .doc(userId)
        .snapshots()
        .map((doc) => doc.exists ? UserModel.fromJson(doc.data()!) : null);
  }

  // Tier methods
  Future<List<TierModel>> getTiers() async {
    try {
      final snapshot = await _firestore
          .collection('tiers')
          .orderBy('tierNumber')
          .get();
      return snapshot.docs
          .map((doc) => TierModel.fromJson(doc.data()))
          .toList();
    } catch (e) {
      print('Error getting tiers: $e');
      return [];
    }
  }

  Future<void> unlockTier(String userId, String tierId) async {
    try {
      final callable = _functions.httpsCallable('unlockTier');
      await callable.call({
        'userId': userId,
        'tierId': tierId,
      });
    } catch (e) {
      print('Error unlocking tier: $e');
    }
  }

  Future<void> renewTier(String userId, String tierId) async {
    try {
      final callable = _functions.httpsCallable('renewTier');
      await callable.call({
        'userId': userId,
        'tierId': tierId,
      });
    } catch (e) {
      print('Error renewing tier: $e');
    }
  }

  // Team methods
  Future<TeamModel?> getTeam(String teamId) async {
    try {
      final doc = await _firestore.collection('teams').doc(teamId).get();
      if (doc.exists) {
        return TeamModel.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      print('Error getting team: $e');
      return null;
    }
  }

  Future<TeamModel?> createTeam(String userId, String teamName, String description) async {
    try {
      final callable = _functions.httpsCallable('createTeam');
      final result = await callable.call({
        'userId': userId,
        'teamName': teamName,
        'description': description,
      });
      return TeamModel.fromJson(result.data);
    } catch (e) {
      print('Error creating team: $e');
      return null;
    }
  }

  Future<bool> joinTeam(String userId, String inviteCode) async {
    try {
      final callable = _functions.httpsCallable('joinTeam');
      await callable.call({
        'userId': userId,
        'inviteCode': inviteCode,
      });
      return true;
    } catch (e) {
      print('Error joining team: $e');
      return false;
    }
  }

  // Quest methods
  Future<List<QuestModel>> getActiveQuests() async {
    try {
      final snapshot = await _firestore
          .collection('quests')
          .where('isActive', isEqualTo: true)
          .where('endDate', isGreaterThan: Timestamp.now())
          .get();
      return snapshot.docs
          .map((doc) => QuestModel.fromJson(doc.data()))
          .toList();
    } catch (e) {
      print('Error getting quests: $e');
      return [];
    }
  }

  Future<void> completeQuest(String userId, String questId) async {
    try {
      final callable = _functions.httpsCallable('completeQuest');
      await callable.call({
        'userId': userId,
        'questId': questId,
      });
    } catch (e) {
      print('Error completing quest: $e');
    }
  }

  // Leaderboard methods
  Future<List<LeaderboardEntry>> getWeeklyLeaderboard({int limit = 100}) async {
    try {
      final snapshot = await _firestore
          .collection('leaderboard')
          .doc('weekly')
          .collection('entries')
          .orderBy('earnings', descending: true)
          .limit(limit)
          .get();
      return snapshot.docs
          .map((doc) => LeaderboardEntry.fromJson(doc.data()))
          .toList();
    } catch (e) {
      print('Error getting leaderboard: $e');
      return [];
    }
  }

  // Ad watching methods
  Future<void> recordAdWatch(String userId, String tierId, double earnings) async {
    try {
      final callable = _functions.httpsCallable('recordAdWatch');
      await callable.call({
        'userId': userId,
        'tierId': tierId,
        'earnings': earnings,
      });
    } catch (e) {
      print('Error recording ad watch: $e');
    }
  }

  // Withdrawal methods
  Future<void> requestWithdrawal(WithdrawalRequest request) async {
    try {
      await _firestore
          .collection('withdrawals')
          .doc(request.id)
          .set(request.toJson());
    } catch (e) {
      print('Error requesting withdrawal: $e');
    }
  }

  Future<List<WithdrawalRequest>> getUserWithdrawals(String userId) async {
    try {
      final snapshot = await _firestore
          .collection('withdrawals')
          .where('userId', isEqualTo: userId)
          .orderBy('requestedAt', descending: true)
          .get();
      return snapshot.docs
          .map((doc) => WithdrawalRequest.fromJson(doc.data()))
          .toList();
    } catch (e) {
      print('Error getting withdrawals: $e');
      return [];
    }
  }

  // SDK/API methods
  Future<String?> generateDeveloperToken(String userId) async {
    try {
      final callable = _functions.httpsCallable('generateDeveloperToken');
      final result = await callable.call({'userId': userId});
      return result.data['token'];
    } catch (e) {
      print('Error generating developer token: $e');
      return null;
    }
  }

  Future<Map<String, dynamic>?> getUserProgress(String userId, String apiKey) async {
    try {
      final callable = _functions.httpsCallable('getUserProgress');
      final result = await callable.call({
        'userId': userId,
        'apiKey': apiKey,
      });
      return result.data;
    } catch (e) {
      print('Error getting user progress: $e');
      return null;
    }
  }

  // Remote config getters
  bool get isSdkEnabled => _remoteConfig.getBool('sdk_enabled');
  int get maxDailyAds => _remoteConfig.getInt('max_daily_ads');
  double get tierUnlockFormula => _remoteConfig.getDouble('tier_unlock_formula');
  double get weeklyPrizePool => _remoteConfig.getDouble('weekly_prize_pool');
  double get autoPlayPrice => _remoteConfig.getDouble('auto_play_price');

  // Analytics
  Future<void> logEvent(String name, Map<String, dynamic>? parameters) async {
    await _analytics.logEvent(name: name, parameters: parameters);
  }
}