import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../models/team_model.dart';
import '../models/quest_model.dart';
import 'firebase_service.dart';

class SDKService {
  static final SDKService _instance = SDKService._internal();
  factory SDKService() => _instance;
  SDKService._internal();

  final FirebaseService _firebaseService = FirebaseService();
  static const String _apiVersion = 'v1';
  static const String _sdkTokenKey = 'sdk_developer_token';
  
  Map<String, SDKClient> _registeredClients = {};
  Map<String, APIUsageLog> _usageLogs = {};

  Future<void> initialize() async {
    await _loadSDKClients();
  }

  Future<void> _loadSDKClients() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final clientsJson = prefs.getString('sdk_clients');
      if (clientsJson != null) {
        final Map<String, dynamic> clientsData = json.decode(clientsJson);
        _registeredClients = clientsData.map(
          (key, value) => MapEntry(key, SDKClient.fromJson(value)),
        );
      }
    } catch (e) {
      print('Error loading SDK clients: $e');
    }
  }

  Future<void> _saveSDKClients() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final clientsData = _registeredClients.map(
        (key, value) => MapEntry(key, value.toJson()),
      );
      await prefs.setString('sdk_clients', json.encode(clientsData));
    } catch (e) {
      print('Error saving SDK clients: $e');
    }
  }

  // Generate developer token for SDK access
  Future<SDKTokenResult> generateDeveloperToken(String userId) async {
    try {
      // Check if SDK is enabled via Remote Config
      if (!_firebaseService.isSdkEnabled) {
        return SDKTokenResult(
          success: false,
          message: 'SDK access is currently disabled',
        );
      }

      // Generate secure token
      final tokenData = {
        'userId': userId,
        'clientId': _generateClientId(),
        'issuedAt': DateTime.now().millisecondsSinceEpoch,
        'expiresAt': DateTime.now().add(const Duration(days: 365)).millisecondsSinceEpoch,
        'permissions': ['read:user', 'read:team', 'write:quest', 'read:progress'],
        'version': _apiVersion,
      };

      final token = _generateJWT(tokenData);
      final clientId = tokenData['clientId'] as String;

      // Create SDK client record
      final client = SDKClient(
        clientId: clientId,
        userId: userId,
        token: token,
        createdAt: DateTime.now(),
        lastUsed: DateTime.now(),
        isActive: true,
        permissions: List<String>.from(tokenData['permissions']),
        usageCount: 0,
        rateLimit: 1000, // 1000 requests per hour
      );

      _registeredClients[clientId] = client;
      await _saveSDKClients();

      // Save to user preferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_sdkTokenKey, token);

      return SDKTokenResult(
        success: true,
        message: 'Developer token generated successfully',
        token: token,
        clientId: clientId,
        client: client,
      );
    } catch (e) {
      return SDKTokenResult(
        success: false,
        message: 'Failed to generate token: $e',
      );
    }
  }

  String _generateClientId() {
    final random = Random.secure();
    final bytes = List<int>.generate(16, (i) => random.nextInt(256));
    return base64Url.encode(bytes).replaceAll('=', '');
  }

  String _generateJWT(Map<String, dynamic> payload) {
    // In a real implementation, use a proper JWT library with RSA/HMAC signing
    final header = {'alg': 'HS256', 'typ': 'JWT'};
    final headerEncoded = base64Url.encode(utf8.encode(json.encode(header)));
    final payloadEncoded = base64Url.encode(utf8.encode(json.encode(payload)));
    
    final signature = _generateSignature('$headerEncoded.$payloadEncoded');
    return '$headerEncoded.$payloadEncoded.$signature';
  }

  String _generateSignature(String data) {
    // Simple HMAC-SHA256 signature (use proper secret in production)
    const secret = 'flurzi_sdk_secret_key_change_in_production';
    final key = utf8.encode(secret);
    final bytes = utf8.encode(data);
    final hmac = Hmac(sha256, key);
    final digest = hmac.convert(bytes);
    return base64Url.encode(digest.bytes).replaceAll('=', '');
  }

  // Validate API token and get client
  Future<SDKValidationResult> validateToken(String token) async {
    try {
      // Decode JWT (simplified validation)
      if (JwtDecoder.isExpired(token)) {
        return SDKValidationResult(
          isValid: false,
          message: 'Token has expired',
        );
      }

      final payload = JwtDecoder.decode(token);
      final clientId = payload['clientId'] as String?;
      
      if (clientId == null) {
        return SDKValidationResult(
          isValid: false,
          message: 'Invalid token format',
        );
      }

      final client = _registeredClients[clientId];
      if (client == null || !client.isActive) {
        return SDKValidationResult(
          isValid: false,
          message: 'Client not found or inactive',
        );
      }

      // Check rate limiting
      if (!_checkRateLimit(client)) {
        return SDKValidationResult(
          isValid: false,
          message: 'Rate limit exceeded',
        );
      }

      // Update usage
      client.usageCount++;
      client.lastUsed = DateTime.now();
      await _saveSDKClients();

      return SDKValidationResult(
        isValid: true,
        message: 'Token is valid',
        client: client,
        userId: payload['userId'] as String?,
      );
    } catch (e) {
      return SDKValidationResult(
        isValid: false,
        message: 'Token validation failed: $e',
      );
    }
  }

  bool _checkRateLimit(SDKClient client) {
    final now = DateTime.now();
    final hourAgo = now.subtract(const Duration(hours: 1));
    
    // Simple rate limiting - count requests in last hour
    final recentLogs = _usageLogs.values
        .where((log) => log.clientId == client.clientId && log.timestamp.isAfter(hourAgo))
        .length;
    
    return recentLogs < client.rateLimit;
  }

  void _logAPIUsage(String clientId, String endpoint, String method) {
    final logId = '${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(1000)}';
    _usageLogs[logId] = APIUsageLog(
      id: logId,
      clientId: clientId,
      endpoint: endpoint,
      method: method,
      timestamp: DateTime.now(),
    );

    // Clean old logs (keep last 24 hours)
    final dayAgo = DateTime.now().subtract(const Duration(hours: 24));
    _usageLogs.removeWhere((key, log) => log.timestamp.isBefore(dayAgo));
  }

  // SDK API Endpoints

  // GET /v1/user/progress
  Future<Map<String, dynamic>?> getUserProgress(String token, String userId) async {
    final validation = await validateToken(token);
    if (!validation.isValid) {
      throw SDKException(validation.message);
    }

    _logAPIUsage(validation.client!.clientId, '/v1/user/progress', 'GET');

    final user = await _firebaseService.getUserData(userId);
    if (user == null) {
      throw SDKException('User not found');
    }

    return {
      'userId': user.id,
      'totalEarnings': user.totalEarnings,
      'totalAdsWatched': user.totalAdsWatched,
      'weeklyEarnings': user.weeklyEarnings,
      'weeklyAdsWatched': user.weeklyAdsWatched,
      'unlockedTiers': user.unlockedTiers,
      'activeTiers': user.activeTiers,
      'lastActiveAt': user.lastActiveAt.toIso8601String(),
    };
  }

  // GET /v1/team/data
  Future<Map<String, dynamic>?> getTeamData(String token, String teamId) async {
    final validation = await validateToken(token);
    if (!validation.isValid) {
      throw SDKException(validation.message);
    }

    _logAPIUsage(validation.client!.clientId, '/v1/team/data', 'GET');

    final team = await _firebaseService.getTeam(teamId);
    if (team == null) {
      throw SDKException('Team not found');
    }

    return {
      'teamId': team.id,
      'name': team.name,
      'memberCount': team.members.length,
      'totalEarnings': team.totalEarnings,
      'weeklyEarnings': team.weeklyEarnings,
      'members': team.members.map((m) => {
        'userId': m.userId,
        'displayName': m.displayName,
        'role': m.role,
        'contributedEarnings': m.contributedEarnings,
        'adsWatched': m.adsWatched,
      }).toList(),
    };
  }

  // POST /v1/quest/submit
  Future<Map<String, dynamic>> submitExternalQuest(String token, Map<String, dynamic> questData) async {
    final validation = await validateToken(token);
    if (!validation.isValid) {
      throw SDKException(validation.message);
    }

    if (!validation.client!.permissions.contains('write:quest')) {
      throw SDKException('Insufficient permissions');
    }

    _logAPIUsage(validation.client!.clientId, '/v1/quest/submit', 'POST');

    // Validate quest data
    final requiredFields = ['title', 'description', 'reward', 'type'];
    for (final field in requiredFields) {
      if (!questData.containsKey(field)) {
        throw SDKException('Missing required field: $field');
      }
    }

    // Create quest with partner info
    final quest = QuestModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: questData['title'],
      description: questData['description'],
      type: 'partner',
      reward: (questData['reward'] as num).toDouble(),
      startDate: DateTime.now(),
      endDate: questData['endDate'] != null 
          ? DateTime.parse(questData['endDate']) 
          : DateTime.now().add(const Duration(days: 7)),
      partnerName: validation.client!.clientId,
      externalUrl: questData['externalUrl'],
      requirements: questData['requirements'] ?? {},
      metadata: {
        'submittedBy': validation.client!.clientId,
        'submittedAt': DateTime.now().toIso8601String(),
      },
    );

    // Save to Firestore (would need to implement in FirebaseService)
    // await _firebaseService.createQuest(quest);

    return {
      'success': true,
      'questId': quest.id,
      'message': 'Quest submitted successfully',
    };
  }

  // POST /v1/reward/trigger
  Future<Map<String, dynamic>> triggerExternalReward(String token, String userId, double amount, String reason) async {
    final validation = await validateToken(token);
    if (!validation.isValid) {
      throw SDKException(validation.message);
    }

    _logAPIUsage(validation.client!.clientId, '/v1/reward/trigger', 'POST');

    // Trigger reward via Firebase Function
    // This would call a cloud function to add earnings to user
    
    return {
      'success': true,
      'userId': userId,
      'amount': amount,
      'reason': reason,
      'triggeredBy': validation.client!.clientId,
      'timestamp': DateTime.now().toIso8601String(),
    };
  }

  // GET /v1/leaderboard
  Future<Map<String, dynamic>> getLeaderboardSnapshot(String token, {int limit = 50}) async {
    final validation = await validateToken(token);
    if (!validation.isValid) {
      throw SDKException(validation.message);
    }

    _logAPIUsage(validation.client!.clientId, '/v1/leaderboard', 'GET');

    final leaderboard = await _firebaseService.getWeeklyLeaderboard(limit: limit);
    
    return {
      'leaderboard': leaderboard.map((entry) => {
        'rank': entry.rank,
        'userId': entry.userId,
        'displayName': entry.displayName,
        'earnings': entry.earnings,
        'adsWatched': entry.adsWatched,
        'teamName': entry.teamName,
      }).toList(),
      'generatedAt': DateTime.now().toIso8601String(),
      'totalEntries': leaderboard.length,
    };
  }

  // Get SDK documentation URL
  String getSDKDocumentationUrl() {
    return 'https://docs.flurzi.app/sdk/v1';
  }

  // Get API usage statistics
  Map<String, dynamic> getUsageStatistics(String clientId) {
    final client = _registeredClients[clientId];
    if (client == null) return {};

    final now = DateTime.now();
    final hourAgo = now.subtract(const Duration(hours: 1));
    final dayAgo = now.subtract(const Duration(hours: 24));

    final hourlyUsage = _usageLogs.values
        .where((log) => log.clientId == clientId && log.timestamp.isAfter(hourAgo))
        .length;
    
    final dailyUsage = _usageLogs.values
        .where((log) => log.clientId == clientId && log.timestamp.isAfter(dayAgo))
        .length;

    return {
      'clientId': clientId,
      'totalUsage': client.usageCount,
      'hourlyUsage': hourlyUsage,
      'dailyUsage': dailyUsage,
      'rateLimit': client.rateLimit,
      'remainingRequests': (client.rateLimit - hourlyUsage).clamp(0, client.rateLimit),
      'lastUsed': client.lastUsed.toIso8601String(),
    };
  }

  // Revoke SDK access
  Future<bool> revokeAccess(String clientId) async {
    final client = _registeredClients[clientId];
    if (client != null) {
      client.isActive = false;
      await _saveSDKClients();
      return true;
    }
    return false;
  }

  // Get user's SDK clients
  List<SDKClient> getUserSDKClients(String userId) {
    return _registeredClients.values
        .where((client) => client.userId == userId)
        .toList();
  }
}

class SDKClient {
  final String clientId;
  final String userId;
  final String token;
  final DateTime createdAt;
  DateTime lastUsed;
  bool isActive;
  final List<String> permissions;
  int usageCount;
  final int rateLimit;

  SDKClient({
    required this.clientId,
    required this.userId,
    required this.token,
    required this.createdAt,
    required this.lastUsed,
    required this.isActive,
    required this.permissions,
    required this.usageCount,
    required this.rateLimit,
  });

  factory SDKClient.fromJson(Map<String, dynamic> json) {
    return SDKClient(
      clientId: json['clientId'],
      userId: json['userId'],
      token: json['token'],
      createdAt: DateTime.parse(json['createdAt']),
      lastUsed: DateTime.parse(json['lastUsed']),
      isActive: json['isActive'],
      permissions: List<String>.from(json['permissions']),
      usageCount: json['usageCount'],
      rateLimit: json['rateLimit'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'clientId': clientId,
      'userId': userId,
      'token': token,
      'createdAt': createdAt.toIso8601String(),
      'lastUsed': lastUsed.toIso8601String(),
      'isActive': isActive,
      'permissions': permissions,
      'usageCount': usageCount,
      'rateLimit': rateLimit,
    };
  }
}

class SDKTokenResult {
  final bool success;
  final String message;
  final String? token;
  final String? clientId;
  final SDKClient? client;

  SDKTokenResult({
    required this.success,
    required this.message,
    this.token,
    this.clientId,
    this.client,
  });
}

class SDKValidationResult {
  final bool isValid;
  final String message;
  final SDKClient? client;
  final String? userId;

  SDKValidationResult({
    required this.isValid,
    required this.message,
    this.client,
    this.userId,
  });
}

class APIUsageLog {
  final String id;
  final String clientId;
  final String endpoint;
  final String method;
  final DateTime timestamp;

  APIUsageLog({
    required this.id,
    required this.clientId,
    required this.endpoint,
    required this.method,
    required this.timestamp,
  });
}

class SDKException implements Exception {
  final String message;
  SDKException(this.message);
  
  @override
  String toString() => 'SDKException: $message';
}