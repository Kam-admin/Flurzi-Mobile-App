import 'package:flutter/material.dart';

class AppTheme {
  static const colors = AppColors();
  static const spacing = AppSpacing();
  static const borderRadius = AppBorderRadius();
  static final shadows = AppShadows();
  static const fonts = AppFonts();
}

class AppColors {
  const AppColors();
  
  final primary = const Color(0xFF2563EB);
  final secondary = const Color(0xFF9333EA);
  final background = Colors.black;
  final surface = const Color(0xFF1F2937);
  final text = Colors.white;
  final textSecondary = Colors.white70;
  final error = const Color(0xFFDC2626);
  final success = const Color(0xFF22C55E);
}

class AppSpacing {
  const AppSpacing();
  
  final double xs = 4.0;
  final double sm = 8.0;
  final double md = 16.0;
  final double lg = 24.0;
  final double xl = 32.0;
}

class AppBorderRadius {
  const AppBorderRadius();
  
  final double sm = 4.0;
  final double md = 8.0;
  final double lg = 16.0;
  final double xl = 24.0;
}

class AppShadows {
  final primary = [
    BoxShadow(
      color: Colors.blue.withOpacity(0.3),
      blurRadius: 8,
      spreadRadius: 2,
    ),
  ];
  
  final secondary = [
    BoxShadow(
      color: Colors.purple.withOpacity(0.3),
      blurRadius: 8,
      spreadRadius: 2,
    ),
  ];
}

class AppFonts {
  const AppFonts();
  
  final String primary = 'Orbitron';
  final String secondary = 'Rajdhani';
}