import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';
import '../models/tier_model.dart';
import '../models/team_model.dart';
import '../models/quest_model.dart';
import '../services/firebase_service.dart';
import '../services/currency_service.dart';
import '../services/ad_service.dart';
import '../services/sdk_service.dart';

class AppProvider with ChangeNotifier {
  final FirebaseService _firebaseService = FirebaseService();
  final CurrencyService _currencyService = CurrencyService();
  final AdService _adService = AdService();
  final SDKService _sdkService = SDKService();

  // App state
  bool _isInitialized = false;
  bool _isLoading = false;
  String? _error;

  // User state
  User? _firebaseUser;
  UserModel? _user;
  bool _isAuthenticated = false;

  // Tiers state
  List<TierModel> _tiers = [];
  List<TierModel> _userTiers = [];

  // Team state
  TeamModel? _userTeam;
  List<LeaderboardEntry> _leaderboard = [];

  // Quests state
  List<QuestModel> _activeQuests = [];
  List<QuestModel> _completedQuests = [];

  // Ad state
  int _dailyAdsWatched = 0;
  int _offlineAdsCount = 0;
  bool _isOnline = true;

  // SDK state
  bool _isDeveloperMode = false;
  String? _developerToken;
  List<SDKClient> _sdkClients = [];

  // Getters
  bool get isInitialized => _isInitialized;
  bool get isLoading => _isLoading;
  String? get error => _error;
  
  User? get firebaseUser => _firebaseUser;
  UserModel? get user => _user;
  bool get isAuthenticated => _isAuthenticated;
  
  List<TierModel> get tiers => _tiers;
  List<TierModel> get userTiers => _userTiers;
  List<TierModel> get unlockedTiers => _userTiers.where((t) => t.isUnlocked).toList();
  List<TierModel> get activeTiers => _userTiers.where((t) => t.isActive).toList();
  
  TeamModel? get userTeam => _userTeam;
  List<LeaderboardEntry> get leaderboard => _leaderboard;
  
  List<QuestModel> get activeQuests => _activeQuests;
  List<QuestModel> get completedQuests => _completedQuests;
  
  int get dailyAdsWatched => _dailyAdsWatched;
  int get offlineAdsCount => _offlineAdsCount;
  bool get isOnline => _isOnline;
  
  bool get isDeveloperMode => _isDeveloperMode;
  String? get developerToken => _developerToken;
  List<SDKClient> get sdkClients => _sdkClients;

  // Computed getters
  double get totalEarnings => _user?.totalEarnings ?? 0.0;
  double get availableBalance => _user?.availableBalance ?? 0.0;
  int get totalAdsWatched => _user?.totalAdsWatched ?? 0;
  bool get hasAutoPlayUpgrade => _user?.hasAutoPlayUpgrade ?? false;
  
  String get userCurrency => _user?.currency ?? 'GBP';
  String get userCountry => _user?.country ?? 'GB';
  
  bool get canWatchMoreAds => _adService.canWatchMoreAds();
  int get remainingAdsToday => _adService.getRemainingAdsToday();
  double get dailyProgress => _adService.getDailyProgress();

  // Initialize the app
  Future<void> initialize() async {
    if (_isInitialized) return;
    
    _setLoading(true);
    
    try {
      // Initialize services
      await _firebaseService.initialize();
      await _currencyService.initialize();
      await _adService.initialize();
      await _sdkService.initialize();
      
      // Listen to auth state changes
      _firebaseService.authStateChanges.listen(_onAuthStateChanged);
      
      // Update ad state
      _updateAdState();
      
      _isInitialized = true;
      _setError(null);
    } catch (e) {
      _setError('Failed to initialize app: $e');
    } finally {
      _setLoading(false);
    }
  }

  void _onAuthStateChanged(User? firebaseUser) async {
    _firebaseUser = firebaseUser;
    _isAuthenticated = firebaseUser != null;
    
    if (firebaseUser != null) {
      await _loadUserData(firebaseUser.uid);
    } else {
      _clearUserData();
    }
    
    notifyListeners();
  }

  Future<void> _loadUserData(String userId) async {
    try {
      _setLoading(true);
      
      // Load user data
      _user = await _firebaseService.getUserData(userId);
      
      if (_user != null) {
        // Load user-specific data
        await Future.wait([
          _loadTiers(),
          _loadUserTeam(),
          _loadQuests(),
          _loadLeaderboard(),
        ]);
        
        // Update developer mode state
        _isDeveloperMode = _user!.isDeveloperMode;
        _developerToken = _user!.developerToken;
        
        if (_isDeveloperMode) {
          _sdkClients = _sdkService.getUserSDKClients(userId);
        }
      }
      
      _setError(null);
    } catch (e) {
      _setError('Failed to load user data: $e');
    } finally {
      _setLoading(false);
    }
  }

  void _clearUserData() {
    _user = null;
    _tiers = [];
    _userTiers = [];
    _userTeam = null;
    _activeQuests = [];
    _completedQuests = [];
    _leaderboard = [];
    _isDeveloperMode = false;
    _developerToken = null;
    _sdkClients = [];
  }

  Future<void> _loadTiers() async {
    try {
      _tiers = await _firebaseService.getTiers();
      _updateUserTiers();
    } catch (e) {
      print('Error loading tiers: $e');
    }
  }

  void _updateUserTiers() {
    if (_user == null) return;
    
    _userTiers = _tiers.map((tier) {
      final isUnlocked = _user!.unlockedTiers.contains(tier.id);
      final isActive = _user!.activeTiers.contains(tier.id);
      
      return tier.copyWith(
        isUnlocked: isUnlocked,
        isActive: isActive,
      );
    }).toList();
  }

  Future<void> _loadUserTeam() async {
    if (_user?.teamId == null) return;
    
    try {
      _userTeam = await _firebaseService.getTeam(_user!.teamId!);
    } catch (e) {
      print('Error loading team: $e');
    }
  }

  Future<void> _loadQuests() async {
    try {
      final quests = await _firebaseService.getActiveQuests();
      
      if (_user != null) {
        _activeQuests = quests.where((q) => !q.isCompletedBy(_user!.id)).toList();
        _completedQuests = quests.where((q) => q.isCompletedBy(_user!.id)).toList();
      } else {
        _activeQuests = quests;
        _completedQuests = [];
      }
    } catch (e) {
      print('Error loading quests: $e');
    }
  }

  Future<void> _loadLeaderboard() async {
    try {
      _leaderboard = await _firebaseService.getWeeklyLeaderboard();
    } catch (e) {
      print('Error loading leaderboard: $e');
    }
  }

  void _updateAdState() {
    _dailyAdsWatched = _adService.dailyAdsWatched;
    _offlineAdsCount = _adService.getOfflineAdsCount();
    _isOnline = _adService.isOnline;
  }

  // Authentication methods
  Future<bool> signInWithGoogle() async {
    try {
      _setLoading(true);
      final result = await _firebaseService.signInWithGoogle();
      return result != null;
    } catch (e) {
      _setError('Google sign-in failed: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> signInWithApple() async {
    try {
      _setLoading(true);
      final result = await _firebaseService.signInWithApple();
      return result != null;
    } catch (e) {
      _setError('Apple sign-in failed: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<void> signOut() async {
    try {
      await _firebaseService.signOut();
    } catch (e) {
      _setError('Sign out failed: $e');
    }
  }

  // Tier methods
  Future<bool> unlockTier(String tierId) async {
    if (_user == null) return false;
    
    try {
      _setLoading(true);
      await _firebaseService.unlockTier(_user!.id, tierId);
      await _refreshUserData();
      return true;
    } catch (e) {
      _setError('Failed to unlock tier: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> renewTier(String tierId) async {
    if (_user == null) return false;
    
    try {
      _setLoading(true);
      await _firebaseService.renewTier(_user!.id, tierId);
      await _refreshUserData();
      return true;
    } catch (e) {
      _setError('Failed to renew tier: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Ad watching methods
  Future<AdWatchResult> watchAd(TierModel tier, {bool isAutoPlay = false}) async {
    if (_user == null) {
      return AdWatchResult(
        success: false,
        message: 'User not authenticated',
        earnings: 0.0,
      );
    }
    
    try {
      final result = await _adService.watchAd(_user!.id, tier, isAutoPlay: isAutoPlay);
      
      if (result.success) {
        _updateAdState();
        await _refreshUserData();
      }
      
      return result;
    } catch (e) {
      return AdWatchResult(
        success: false,
        message: 'Failed to watch ad: $e',
        earnings: 0.0,
      );
    }
  }

  // Team methods
  Future<bool> createTeam(String teamName, String description) async {
    if (_user == null) return false;
    
    try {
      _setLoading(true);
      final team = await _firebaseService.createTeam(_user!.id, teamName, description);
      if (team != null) {
        _userTeam = team;
        await _refreshUserData();
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to create team: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> joinTeam(String inviteCode) async {
    if (_user == null) return false;
    
    try {
      _setLoading(true);
      final success = await _firebaseService.joinTeam(_user!.id, inviteCode);
      if (success) {
        await _refreshUserData();
      }
      return success;
    } catch (e) {
      _setError('Failed to join team: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Quest methods
  Future<bool> completeQuest(String questId) async {
    if (_user == null) return false;
    
    try {
      await _firebaseService.completeQuest(_user!.id, questId);
      await _loadQuests();
      await _refreshUserData();
      return true;
    } catch (e) {
      _setError('Failed to complete quest: $e');
      return false;
    }
  }

  // Withdrawal methods
  Future<bool> requestWithdrawal(double amount, String method, Map<String, dynamic> paymentDetails) async {
    if (_user == null) return false;
    
    try {
      final request = WithdrawalRequest(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        userId: _user!.id,
        amount: amount,
        currency: _user!.currency,
        method: method,
        paymentDetails: paymentDetails,
        requestedAt: DateTime.now(),
      );
      
      await _firebaseService.requestWithdrawal(request);
      await _refreshUserData();
      return true;
    } catch (e) {
      _setError('Failed to request withdrawal: $e');
      return false;
    }
  }

  // Developer mode methods
  Future<bool> enableDeveloperMode() async {
    if (_user == null) return false;
    
    try {
      final tokenResult = await _sdkService.generateDeveloperToken(_user!.id);
      if (tokenResult.success) {
        _isDeveloperMode = true;
        _developerToken = tokenResult.token;
        _sdkClients = [tokenResult.client!];
        
        // Update user in database
        final updatedUser = _user!.copyWith(
          isDeveloperMode: true,
          developerToken: tokenResult.token,
        );
        await _firebaseService.createOrUpdateUser(updatedUser);
        _user = updatedUser;
        
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      _setError('Failed to enable developer mode: $e');
      return false;
    }
  }

  Future<void> disableDeveloperMode() async {
    if (_user == null) return;
    
    try {
      _isDeveloperMode = false;
      _developerToken = null;
      _sdkClients = [];
      
      // Revoke all SDK clients
      for (final client in _sdkClients) {
        await _sdkService.revokeAccess(client.clientId);
      }
      
      // Update user in database
      final updatedUser = _user!.copyWith(
        isDeveloperMode: false,
        developerToken: null,
      );
      await _firebaseService.createOrUpdateUser(updatedUser);
      _user = updatedUser;
      
      notifyListeners();
    } catch (e) {
      _setError('Failed to disable developer mode: $e');
    }
  }

  // Utility methods
  Future<void> refreshUserData() async {
    if (_user != null) {
      await _loadUserData(_user!.id);
    }
  }

  Future<void> _refreshUserData() async {
    if (_user != null) {
      _user = await _firebaseService.getUserData(_user!.id);
      _updateUserTiers();
      notifyListeners();
    }
  }

  Future<void> refreshCurrencyRates() async {
    await _currencyService.refreshRates();
    notifyListeners();
  }

  Future<void> syncOfflineAds() async {
    final success = await _adService.forceSyncOfflineAds();
    if (success) {
      _updateAdState();
      await _refreshUserData();
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String? error) {
    _error = error;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _adService.dispose();
    super.dispose();
  }
}