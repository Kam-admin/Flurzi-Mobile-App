import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../models/quest_model.dart';
import '../services/currency_service.dart';

class QuestsScreen extends StatefulWidget {
  const QuestsScreen({super.key});

  @override
  State<QuestsScreen> createState() => _QuestsScreenState();
}

class _QuestsScreenState extends State<QuestsScreen>
    with TickerProviderStateMixin {
  late AnimationController _headerAnimationController;
  late AnimationController _questsAnimationController;
  late Animation<double> _headerSlideAnimation;
  late Animation<double> _questsFadeAnimation;
  
  final CurrencyService _currencyService = CurrencyService();
  int _selectedFilter = 0; // 0: All, 1: Available, 2: Completed

  @override
  void initState() {
    super.initState();
    
    _headerAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _questsAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _headerSlideAnimation = Tween<double>(
      begin: -100,
      end: 0,
    ).animate(CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeOutBack,
    ));
    
    _questsFadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _questsAnimationController,
      curve: Curves.easeOut,
    ));
    
    // Start animations
    _headerAnimationController.forward();
    Future.delayed(const Duration(milliseconds: 300), () {
      _questsAnimationController.forward();
    });
    
    // Load quests data
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppProvider>().loadQuests();
    });
  }

  @override
  void dispose() {
    _headerAnimationController.dispose();
    _questsAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.colors.background,
      body: SafeArea(
        child: Consumer<AppProvider>(builder: (context, appProvider, child) {
          return Column(
            children: [
              // Header with stats
              _buildHeader(appProvider),
              
              // Filter tabs
              _buildFilterTabs(),
              
              // Quests list
              Expanded(
                child: _buildQuestsList(appProvider),
              ),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildHeader(AppProvider appProvider) {
    return AnimatedBuilder(
      animation: _headerSlideAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _headerSlideAnimation.value),
          child: Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.colors.secondary.withOpacity(0.2),
                  AppTheme.colors.primary.withOpacity(0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
              border: Border.all(
                color: AppTheme.colors.secondary.withOpacity(0.5),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.colors.secondary.withOpacity(0.3),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
                ...AppTheme.shadows.medium,
              ],
            ),
            child: Column(
              children: [
                // Title and icon
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      LucideIcons.target,
                      color: AppTheme.colors.secondary,
                      size: 32,
                    ).animate(onPlay: (controller) => controller.repeat())
                      .scale(duration: 2000.ms, begin: 0.8, end: 1.2)
                      .then()
                      .scale(duration: 2000.ms, begin: 1.2, end: 0.8),
                    const SizedBox(width: 12),
                    Text(
                      'Daily Quests',
                      style: TextStyle(
                        color: AppTheme.colors.text,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 16),
                
                // Stats row
                Row(
                  children: [
                    Expanded(
                      child: _buildHeaderStat(
                        'Available',
                        _getAvailableQuestsCount(appProvider).toString(),
                        LucideIcons.clock,
                        AppTheme.colors.warning,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _buildHeaderStat(
                        'Completed',
                        _getCompletedQuestsCount(appProvider).toString(),
                        LucideIcons.checkCircle,
                        AppTheme.colors.success,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _buildHeaderStat(
                        'Total Rewards',
                        _currencyService.formatCurrency(
                          _getTotalRewards(appProvider),
                          appProvider.userCurrency,
                        ),
                        LucideIcons.gift,
                        AppTheme.colors.primary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeaderStat(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: color,
            size: 20,
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: 10,
              fontFamily: AppTheme.fonts.secondary,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildFilterTabs() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildFilterTab('All', 0, LucideIcons.list),
          ),
          Expanded(
            child: _buildFilterTab('Available', 1, LucideIcons.clock),
          ),
          Expanded(
            child: _buildFilterTab('Completed', 2, LucideIcons.checkCircle),
          ),
        ],
      ),
    ).animate().slideY(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack);
  }

  Widget _buildFilterTab(String title, int index, IconData icon) {
    final isSelected = _selectedFilter == index;
    
    return GestureDetector(
      onTap: () => _selectFilter(index),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.colors.primary
              : Colors.transparent,
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isSelected
                  ? AppTheme.colors.background
                  : AppTheme.colors.textSecondary,
              size: 16,
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                color: isSelected
                    ? AppTheme.colors.background
                    : AppTheme.colors.textSecondary,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestsList(AppProvider appProvider) {
    if (appProvider.isLoading && appProvider.quests.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppTheme.colors.primary),
            ),
            const SizedBox(height: 16),
            Text(
              'Loading quests...',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 16,
                fontFamily: AppTheme.fonts.secondary,
              ),
            ),
          ],
        ),
      );
    }

    final filteredQuests = _getFilteredQuests(appProvider);

    if (filteredQuests.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              LucideIcons.target,
              color: AppTheme.colors.textSecondary,
              size: 64,
            ),
            const SizedBox(height: 16),
            Text(
              _getEmptyMessage(),
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 16,
                fontFamily: AppTheme.fonts.secondary,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return AnimatedBuilder(
      animation: _questsFadeAnimation,
      builder: (context, child) {
        return Opacity(
          opacity: _questsFadeAnimation.value,
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: filteredQuests.length,
            itemBuilder: (context, index) {
              final quest = filteredQuests[index];
              
              return _buildQuestCard(quest, appProvider)
                  .animate(delay: Duration(milliseconds: index * 100))
                  .slideX(begin: 1, duration: 400.ms, curve: Curves.easeOutBack);
            },
          ),
        );
      },
    );
  }

  Widget _buildQuestCard(QuestModel quest, AppProvider appProvider) {
    final isCompleted = quest.isCompleted;
    final isExpired = quest.isExpired;
    final canComplete = quest.canComplete;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: isCompleted
              ? AppTheme.colors.success
              : isExpired
                  ? AppTheme.colors.error
                  : AppTheme.colors.border,
          width: isCompleted || isExpired ? 2 : 1,
        ),
        boxShadow: AppTheme.shadows.small,
      ),
      child: Column(
        children: [
          // Header with type and status
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _getQuestTypeColor(quest.type).withOpacity(0.1),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                // Quest type icon
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _getQuestTypeColor(quest.type).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
                  ),
                  child: Icon(
                    _getQuestTypeIcon(quest.type),
                    color: _getQuestTypeColor(quest.type),
                    size: 20,
                  ),
                ),
                
                const SizedBox(width: 12),
                
                // Quest info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        quest.title,
                        style: TextStyle(
                          color: AppTheme.colors.text,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _getQuestTypeLabel(quest.type),
                        style: TextStyle(
                          color: _getQuestTypeColor(quest.type),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.secondary,
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Status badge
                _buildStatusBadge(quest),
              ],
            ),
          ),
          
          // Content
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Description
                Text(
                  quest.description,
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 14,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
                
                const SizedBox(height: 16),
                
                // Requirements and progress
                if (quest.requirements.isNotEmpty) ..._buildRequirements(quest),
                
                const SizedBox(height: 16),
                
                // Reward and action
                Row(
                  children: [
                    // Reward
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppTheme.colors.success.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                          border: Border.all(
                            color: AppTheme.colors.success.withOpacity(0.3),
                            width: 1,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              LucideIcons.gift,
                              color: AppTheme.colors.success,
                              size: 16,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'Reward: ',
                              style: TextStyle(
                                color: AppTheme.colors.textSecondary,
                                fontSize: 12,
                                fontFamily: AppTheme.fonts.secondary,
                              ),
                            ),
                            Text(
                              _currencyService.formatCurrency(
                                quest.reward,
                                appProvider.userCurrency,
                              ),
                              style: TextStyle(
                                color: AppTheme.colors.success,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: AppTheme.fonts.primary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    
                    const SizedBox(width: 12),
                    
                    // Action button
                    _buildActionButton(quest, appProvider),
                  ],
                ),
                
                // Expiry info
                if (!isCompleted && !isExpired)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Row(
                      children: [
                        Icon(
                          LucideIcons.clock,
                          color: AppTheme.colors.warning,
                          size: 12,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Expires: ${_formatDate(quest.expiryDate)}',
                          style: TextStyle(
                            color: AppTheme.colors.warning,
                            fontSize: 10,
                            fontFamily: AppTheme.fonts.secondary,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusBadge(QuestModel quest) {
    String text;
    Color color;
    IconData icon;
    
    if (quest.isCompleted) {
      text = 'Completed';
      color = AppTheme.colors.success;
      icon = LucideIcons.checkCircle;
    } else if (quest.isExpired) {
      text = 'Expired';
      color = AppTheme.colors.error;
      icon = LucideIcons.xCircle;
    } else {
      text = 'Available';
      color = AppTheme.colors.warning;
      icon = LucideIcons.clock;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
        border: Border.all(
          color: color,
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: color,
            size: 12,
          ),
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildRequirements(QuestModel quest) {
    return quest.requirements.entries.map((entry) {
      final current = quest.progress[entry.key] ?? 0;
      final required = entry.value;
      final progress = (current / required).clamp(0.0, 1.0);
      final isComplete = current >= required;
      
      return Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppTheme.colors.background,
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
          border: Border.all(
            color: isComplete
                ? AppTheme.colors.success.withOpacity(0.3)
                : AppTheme.colors.border,
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  isComplete ? LucideIcons.checkCircle : LucideIcons.circle,
                  color: isComplete
                      ? AppTheme.colors.success
                      : AppTheme.colors.textSecondary,
                  size: 16,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _getRequirementLabel(entry.key),
                    style: TextStyle(
                      color: AppTheme.colors.text,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: AppTheme.fonts.primary,
                    ),
                  ),
                ),
                Text(
                  '$current / $required',
                  style: TextStyle(
                    color: isComplete
                        ? AppTheme.colors.success
                        : AppTheme.colors.textSecondary,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 8),
            
            // Progress bar
            Container(
              height: 6,
              decoration: BoxDecoration(
                color: AppTheme.colors.border,
                borderRadius: BorderRadius.circular(3),
              ),
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: progress,
                child: Container(
                  decoration: BoxDecoration(
                    color: isComplete
                        ? AppTheme.colors.success
                        : AppTheme.colors.primary,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }).toList();
  }

  Widget _buildActionButton(QuestModel quest, AppProvider appProvider) {
    if (quest.isCompleted) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: AppTheme.colors.success.withOpacity(0.2),
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
          border: Border.all(
            color: AppTheme.colors.success,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              LucideIcons.checkCircle,
              color: AppTheme.colors.success,
              size: 16,
            ),
            const SizedBox(width: 6),
            Text(
              'Claimed',
              style: TextStyle(
                color: AppTheme.colors.success,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ],
        ),
      );
    }
    
    if (quest.isExpired) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: AppTheme.colors.error.withOpacity(0.2),
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
          border: Border.all(
            color: AppTheme.colors.error,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              LucideIcons.xCircle,
              color: AppTheme.colors.error,
              size: 16,
            ),
            const SizedBox(width: 6),
            Text(
              'Expired',
              style: TextStyle(
                color: AppTheme.colors.error,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ],
        ),
      );
    }
    
    if (quest.canComplete) {
      return GestureDetector(
        onTap: () => _completeQuest(quest, appProvider),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: AppTheme.colors.primary,
            borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
            boxShadow: [
              BoxShadow(
                color: AppTheme.colors.primary.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                LucideIcons.gift,
                color: AppTheme.colors.background,
                size: 16,
              ),
              const SizedBox(width: 6),
              Text(
                'Claim',
                style: TextStyle(
                  color: AppTheme.colors.background,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ],
          ),
        ),
      ).animate(onPlay: (controller) => controller.repeat())
        .shimmer(duration: 2000.ms);
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.colors.textSecondary.withOpacity(0.2),
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.textSecondary,
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            LucideIcons.clock,
            color: AppTheme.colors.textSecondary,
            size: 16,
          ),
          const SizedBox(width: 6),
          Text(
            'In Progress',
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
        ],
      ),
    );
  }

  // Helper methods
  void _selectFilter(int index) {
    setState(() {
      _selectedFilter = index;
    });
    
    // Restart quests animation
    _questsAnimationController.reset();
    _questsAnimationController.forward();
  }

  List<QuestModel> _getFilteredQuests(AppProvider appProvider) {
    switch (_selectedFilter) {
      case 1: // Available
        return appProvider.quests
            .where((quest) => !quest.isCompleted && !quest.isExpired)
            .toList();
      case 2: // Completed
        return appProvider.quests
            .where((quest) => quest.isCompleted)
            .toList();
      default: // All
        return appProvider.quests;
    }
  }

  int _getAvailableQuestsCount(AppProvider appProvider) {
    return appProvider.quests
        .where((quest) => !quest.isCompleted && !quest.isExpired)
        .length;
  }

  int _getCompletedQuestsCount(AppProvider appProvider) {
    return appProvider.quests
        .where((quest) => quest.isCompleted)
        .length;
  }

  double _getTotalRewards(AppProvider appProvider) {
    return appProvider.quests
        .where((quest) => quest.isCompleted)
        .fold(0.0, (sum, quest) => sum + quest.reward);
  }

  String _getEmptyMessage() {
    switch (_selectedFilter) {
      case 1:
        return 'No available quests\nCheck back later for new challenges!';
      case 2:
        return 'No completed quests yet\nStart completing quests to earn rewards!';
      default:
        return 'No quests available\nNew quests are added regularly!';
    }
  }

  Color _getQuestTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'daily':
        return AppTheme.colors.primary;
      case 'weekly':
        return AppTheme.colors.secondary;
      case 'special':
        return AppTheme.colors.warning;
      case 'team':
        return AppTheme.colors.success;
      default:
        return AppTheme.colors.textSecondary;
    }
  }

  IconData _getQuestTypeIcon(String type) {
    switch (type.toLowerCase()) {
      case 'daily':
        return LucideIcons.sun;
      case 'weekly':
        return LucideIcons.calendar;
      case 'special':
        return LucideIcons.star;
      case 'team':
        return LucideIcons.users;
      default:
        return LucideIcons.target;
    }
  }

  String _getQuestTypeLabel(String type) {
    switch (type.toLowerCase()) {
      case 'daily':
        return 'Daily Quest';
      case 'weekly':
        return 'Weekly Quest';
      case 'special':
        return 'Special Event';
      case 'team':
        return 'Team Quest';
      default:
        return 'Quest';
    }
  }

  String _getRequirementLabel(String key) {
    switch (key.toLowerCase()) {
      case 'ads_watched':
        return 'Watch ads';
      case 'tiers_unlocked':
        return 'Unlock tiers';
      case 'team_members':
        return 'Recruit team members';
      case 'daily_login':
        return 'Daily login streak';
      case 'earnings':
        return 'Earn money';
      default:
        return key.replaceAll('_', ' ').toUpperCase();
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = date.difference(now);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ${difference.inHours % 24}h';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ${difference.inMinutes % 60}m';
    } else {
      return '${difference.inMinutes}m';
    }
  }

  void _completeQuest(QuestModel quest, AppProvider appProvider) async {
    try {
      await appProvider.completeQuest(quest.id);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Quest completed! Earned ${_currencyService.formatCurrency(quest.reward, appProvider.userCurrency)}',
              style: TextStyle(
                color: AppTheme.colors.background,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
            backgroundColor: AppTheme.colors.success,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Failed to complete quest: $e',
              style: TextStyle(
                color: AppTheme.colors.background,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
            backgroundColor: AppTheme.colors.error,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
            ),
          ),
        );
      }
    }
  }
}