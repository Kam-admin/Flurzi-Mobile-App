import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../models/quest_model.dart';
import '../services/currency_service.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen>
    with TickerProviderStateMixin {
  late AnimationController _headerAnimationController;
  late AnimationController _listAnimationController;
  late Animation<double> _headerSlideAnimation;
  late Animation<double> _listFadeAnimation;
  
  final CurrencyService _currencyService = CurrencyService();
  int _selectedTab = 0; // 0: Individual, 1: Team

  @override
  void initState() {
    super.initState();
    
    _headerAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _listAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _headerSlideAnimation = Tween<double>(
      begin: -100,
      end: 0,
    ).animate(CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeOutBack,
    ));
    
    _listFadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _listAnimationController,
      curve: Curves.easeOut,
    ));
    
    // Start animations
    _headerAnimationController.forward();
    Future.delayed(const Duration(milliseconds: 300), () {
      _listAnimationController.forward();
    });
    
    // Load leaderboard data
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppProvider>().loadLeaderboard();
    });
  }

  @override
  void dispose() {
    _headerAnimationController.dispose();
    _listAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.colors.background,
      body: SafeArea(
        child: Consumer<AppProvider>(builder: (context, appProvider, child) {
          return Column(
            children: [
              // Header with prize pool and timer
              _buildHeader(appProvider),
              
              // Tab selector
              _buildTabSelector(),
              
              // Leaderboard content
              Expanded(
                child: _selectedTab == 0
                    ? _buildIndividualLeaderboard(appProvider)
                    : _buildTeamLeaderboard(appProvider),
              ),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildHeader(AppProvider appProvider) {
    return AnimatedBuilder(
      animation: _headerSlideAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _headerSlideAnimation.value),
          child: Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.colors.warning.withOpacity(0.2),
                  AppTheme.colors.primary.withOpacity(0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
              border: Border.all(
                color: AppTheme.colors.warning.withOpacity(0.5),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.colors.warning.withOpacity(0.3),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
                ...AppTheme.shadows.medium,
              ],
            ),
            child: Column(
              children: [
                // Title and trophy
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      LucideIcons.trophy,
                      color: AppTheme.colors.warning,
                      size: 32,
                    ).animate(onPlay: (controller) => controller.repeat())
                      .rotate(duration: 2000.ms, begin: -0.1, end: 0.1)
                      .then()
                      .rotate(duration: 2000.ms, begin: 0.1, end: -0.1),
                    const SizedBox(width: 12),
                    Text(
                      'Weekly Competition',
                      style: TextStyle(
                        color: AppTheme.colors.text,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 16),
                
                // Prize pool and timer
                Row(
                  children: [
                    Expanded(
                      child: _buildHeaderStat(
                        'Prize Pool',
                        '£4,500',
                        LucideIcons.dollarSign,
                        AppTheme.colors.success,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _buildHeaderStat(
                        'Time Left',
                        _getTimeLeft(),
                        LucideIcons.clock,
                        AppTheme.colors.primary,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 16),
                
                // Your position
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.colors.surface,
                    borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                    border: Border.all(
                      color: AppTheme.colors.primary.withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        LucideIcons.user,
                        color: AppTheme.colors.primary,
                        size: 16,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Your Position: ',
                        style: TextStyle(
                          color: AppTheme.colors.textSecondary,
                          fontSize: 14,
                          fontFamily: AppTheme.fonts.secondary,
                        ),
                      ),
                      Text(
                        _getUserPosition(appProvider),
                        style: TextStyle(
                          color: AppTheme.colors.primary,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeaderStat(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: color,
                size: 16,
              ),
              const SizedBox(width: 6),
              Text(
                title,
                style: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontSize: 12,
                  fontFamily: AppTheme.fonts.secondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabSelector() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => _selectTab(0),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: _selectedTab == 0
                      ? AppTheme.colors.primary
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      LucideIcons.user,
                      color: _selectedTab == 0
                          ? AppTheme.colors.background
                          : AppTheme.colors.textSecondary,
                      size: 16,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Individual',
                      style: TextStyle(
                        color: _selectedTab == 0
                            ? AppTheme.colors.background
                            : AppTheme.colors.textSecondary,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () => _selectTab(1),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: _selectedTab == 1
                      ? AppTheme.colors.primary
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      LucideIcons.users,
                      color: _selectedTab == 1
                          ? AppTheme.colors.background
                          : AppTheme.colors.textSecondary,
                      size: 16,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Team',
                      style: TextStyle(
                        color: _selectedTab == 1
                            ? AppTheme.colors.background
                            : AppTheme.colors.textSecondary,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    ).animate().slideY(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack);
  }

  Widget _buildIndividualLeaderboard(AppProvider appProvider) {
    if (appProvider.isLoading && appProvider.leaderboard.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppTheme.colors.primary),
            ),
            const SizedBox(height: 16),
            Text(
              'Loading leaderboard...',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 16,
                fontFamily: AppTheme.fonts.secondary,
              ),
            ),
          ],
        ),
      );
    }

    return AnimatedBuilder(
      animation: _listFadeAnimation,
      builder: (context, child) {
        return Opacity(
          opacity: _listFadeAnimation.value,
          child: Column(
            children: [
              // Top 3 podium
              if (appProvider.leaderboard.length >= 3) _buildPodium(appProvider),
              
              // Rest of the leaderboard
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: appProvider.leaderboard.length > 3
                      ? appProvider.leaderboard.length - 3
                      : 0,
                  itemBuilder: (context, index) {
                    final actualIndex = index + 3;
                    final entry = appProvider.leaderboard[actualIndex];
                    
                    return _buildLeaderboardItem(
                      entry,
                      actualIndex + 1,
                      appProvider,
                    ).animate(delay: Duration(milliseconds: index * 100))
                      .slideX(begin: 1, duration: 400.ms, curve: Curves.easeOutBack);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTeamLeaderboard(AppProvider appProvider) {
    // Similar structure but for teams
    return AnimatedBuilder(
      animation: _listFadeAnimation,
      builder: (context, child) {
        return Opacity(
          opacity: _listFadeAnimation.value,
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: appProvider.teamLeaderboard.length,
            itemBuilder: (context, index) {
              final entry = appProvider.teamLeaderboard[index];
              
              return _buildTeamLeaderboardItem(
                entry,
                index + 1,
                appProvider,
              ).animate(delay: Duration(milliseconds: index * 100))
                .slideX(begin: 1, duration: 400.ms, curve: Curves.easeOutBack);
            },
          ),
        );
      },
    );
  }

  Widget _buildPodium(AppProvider appProvider) {
    final top3 = appProvider.leaderboard.take(3).toList();
    
    return Container(
      margin: const EdgeInsets.all(16),
      height: 200,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // 2nd place
          if (top3.length > 1)
            Expanded(
              child: _buildPodiumPlace(
                top3[1],
                2,
                160,
                AppTheme.colors.secondary,
                appProvider,
              ),
            ),
          
          // 1st place
          if (top3.isNotEmpty)
            Expanded(
              child: _buildPodiumPlace(
                top3[0],
                1,
                200,
                AppTheme.colors.warning,
                appProvider,
              ),
            ),
          
          // 3rd place
          if (top3.length > 2)
            Expanded(
              child: _buildPodiumPlace(
                top3[2],
                3,
                120,
                AppTheme.colors.primary,
                appProvider,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPodiumPlace(
    LeaderboardEntry entry,
    int position,
    double height,
    Color color,
    AppProvider appProvider,
  ) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          // Avatar and crown
          Stack(
            alignment: Alignment.topCenter,
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12),
                child: CircleAvatar(
                  radius: 24,
                  backgroundColor: color.withOpacity(0.2),
                  backgroundImage: entry.photoUrl != null
                      ? NetworkImage(entry.photoUrl!)
                      : null,
                  child: entry.photoUrl == null
                      ? Text(
                          entry.displayName.isNotEmpty
                              ? entry.displayName[0].toUpperCase()
                              : 'U',
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.bold,
                            fontFamily: AppTheme.fonts.primary,
                          ),
                        )
                      : null,
                ),
              ),
              if (position == 1)
                Icon(
                  LucideIcons.crown,
                  color: AppTheme.colors.warning,
                  size: 24,
                ).animate(onPlay: (controller) => controller.repeat())
                  .shimmer(duration: 2000.ms),
            ],
          ),
          
          const SizedBox(height: 8),
          
          // Name
          Text(
            entry.displayName,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          
          const SizedBox(height: 4),
          
          // Earnings
          Text(
            _currencyService.formatCurrency(
              entry.weeklyEarnings,
              appProvider.userCurrency,
            ),
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
            textAlign: TextAlign.center,
          ),
          
          const SizedBox(height: 8),
          
          // Podium base
          Container(
            height: height,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  color.withOpacity(0.8),
                  color.withOpacity(0.4),
                ],
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
              border: Border.all(
                color: color,
                width: 2,
              ),
            ),
            child: Center(
              child: Text(
                position.toString(),
                style: TextStyle(
                  color: AppTheme.colors.background,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ),
          ),
        ],
      ),
    ).animate(delay: Duration(milliseconds: position * 200))
      .slideY(begin: 1, duration: 800.ms, curve: Curves.bounceOut);
  }

  Widget _buildLeaderboardItem(
    LeaderboardEntry entry,
    int position,
    AppProvider appProvider,
  ) {
    final isCurrentUser = entry.userId == appProvider.user?.id;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isCurrentUser
            ? AppTheme.colors.primary.withOpacity(0.1)
            : AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: isCurrentUser
              ? AppTheme.colors.primary
              : AppTheme.colors.border,
          width: isCurrentUser ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          // Position
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: _getPositionColor(position).withOpacity(0.2),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
              border: Border.all(
                color: _getPositionColor(position),
                width: 1,
              ),
            ),
            child: Center(
              child: Text(
                position.toString(),
                style: TextStyle(
                  color: _getPositionColor(position),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ),
          ),
          
          const SizedBox(width: 12),
          
          // Avatar
          CircleAvatar(
            radius: 20,
            backgroundColor: AppTheme.colors.primary.withOpacity(0.2),
            backgroundImage: entry.photoUrl != null
                ? NetworkImage(entry.photoUrl!)
                : null,
            child: entry.photoUrl == null
                ? Text(
                    entry.displayName.isNotEmpty
                        ? entry.displayName[0].toUpperCase()
                        : 'U',
                    style: TextStyle(
                      color: AppTheme.colors.primary,
                      fontWeight: FontWeight.bold,
                      fontFamily: AppTheme.fonts.primary,
                    ),
                  )
                : null,
          ),
          
          const SizedBox(width: 12),
          
          // User info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        entry.displayName,
                        style: TextStyle(
                          color: AppTheme.colors.text,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                    ),
                    if (isCurrentUser)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppTheme.colors.primary,
                          borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
                        ),
                        child: Text(
                          'YOU',
                          style: TextStyle(
                            color: AppTheme.colors.background,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: AppTheme.fonts.primary,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      LucideIcons.zap,
                      color: AppTheme.colors.warning,
                      size: 12,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${entry.adsWatched} ads watched',
                      style: TextStyle(
                        color: AppTheme.colors.textSecondary,
                        fontSize: 12,
                        fontFamily: AppTheme.fonts.secondary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          // Earnings
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _currencyService.formatCurrency(
                  entry.weeklyEarnings,
                  appProvider.userCurrency,
                ),
                style: TextStyle(
                  color: AppTheme.colors.success,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'this week',
                style: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontSize: 10,
                  fontFamily: AppTheme.fonts.secondary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTeamLeaderboardItem(
    LeaderboardEntry entry,
    int position,
    AppProvider appProvider,
  ) {
    // Similar to individual but for teams
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          // Position
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: _getPositionColor(position).withOpacity(0.2),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
              border: Border.all(
                color: _getPositionColor(position),
                width: 1,
              ),
            ),
            child: Center(
              child: Text(
                position.toString(),
                style: TextStyle(
                  color: _getPositionColor(position),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ),
          ),
          
          const SizedBox(width: 12),
          
          // Team icon
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppTheme.colors.secondary.withOpacity(0.2),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
              border: Border.all(
                color: AppTheme.colors.secondary,
                width: 1,
              ),
            ),
            child: Icon(
              LucideIcons.users,
              color: AppTheme.colors.secondary,
              size: 20,
            ),
          ),
          
          const SizedBox(width: 12),
          
          // Team info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  entry.displayName, // Team name
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${entry.adsWatched} members', // Member count
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 12,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
              ],
            ),
          ),
          
          // Team earnings
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _currencyService.formatCurrency(
                  entry.weeklyEarnings,
                  appProvider.userCurrency,
                ),
                style: TextStyle(
                  color: AppTheme.colors.success,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'team total',
                style: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontSize: 10,
                  fontFamily: AppTheme.fonts.secondary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Helper methods
  void _selectTab(int index) {
    setState(() {
      _selectedTab = index;
    });
    
    // Restart list animation
    _listAnimationController.reset();
    _listAnimationController.forward();
  }

  String _getTimeLeft() {
    // Calculate time left until next Monday
    final now = DateTime.now();
    final nextMonday = now.add(Duration(days: (8 - now.weekday) % 7));
    final difference = nextMonday.difference(now);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ${difference.inHours % 24}h';
    } else {
      return '${difference.inHours}h ${difference.inMinutes % 60}m';
    }
  }

  String _getUserPosition(AppProvider appProvider) {
    if (appProvider.user == null) return 'N/A';
    
    final userIndex = appProvider.leaderboard.indexWhere(
      (entry) => entry.userId == appProvider.user!.id,
    );
    
    if (userIndex == -1) return 'Unranked';
    return '#${userIndex + 1}';
  }

  Color _getPositionColor(int position) {
    if (position <= 3) {
      switch (position) {
        case 1:
          return AppTheme.colors.warning;
        case 2:
          return AppTheme.colors.secondary;
        case 3:
          return AppTheme.colors.primary;
        default:
          return AppTheme.colors.textSecondary;
      }
    } else if (position <= 10) {
      return AppTheme.colors.success;
    } else {
      return AppTheme.colors.textSecondary;
    }
  }
}