import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../constants/theme.dart';
import '../widgets/neon_button.dart';

class TutorialScreen extends StatefulWidget {
  const TutorialScreen({super.key});

  @override
  State<TutorialScreen> createState() => _TutorialScreenState();
}

class _TutorialScreenState extends State<TutorialScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<TutorialStep> _steps = [
    TutorialStep(
      icon: LucideIcons.home,
      title: 'Welcome to Your Dashboard',
      description: 'Track your mining progress and rewards in real-time.',
    ),
    TutorialStep(
      icon: LucideIcons.checkSquare,
      title: 'Complete Tasks',
      description: 'Earn rewards by completing daily and weekly tasks.',
    ),
    TutorialStep(
      icon: LucideIcons.users,
      title: 'Team Collaboration',
      description: 'Join forces with other miners to maximize earnings.',
    ),
    TutorialStep(
      icon: LucideIcons.mapPin,
      title: 'Location Tracking',
      description: 'Optimize your mining based on your location.',
    ),
    TutorialStep(
      icon: LucideIcons.trophy,
      title: 'Achievements',
      description: 'Unlock special rewards and climb the leaderboard.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.colors.background,
              AppTheme.colors.surface,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: PageView.builder(
                  controller: _pageController,
                  onPageChanged: (index) => setState(() => _currentPage = index),
                  itemCount: _steps.length,
                  itemBuilder: (context, index) => _buildTutorialStep(_steps[index]),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(AppTheme.spacing.lg),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        _steps.length,
                        (index) => _buildPageIndicator(index),
                      ),
                    ),
                    SizedBox(height: AppTheme.spacing.lg),
                    NeonButton(
                      text: _currentPage == _steps.length - 1
                          ? 'Get Started'
                          : 'Next',
                      onPressed: () {
                        if (_currentPage < _steps.length - 1) {
                          _pageController.nextPage(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeInOut,
                          );
                        } else {
                          context.go('/');
                        }
                      },
                    ),
                    if (_currentPage < _steps.length - 1) ...[
                      SizedBox(height: AppTheme.spacing.md),
                      TextButton(
                        onPressed: () => context.go('/'),
                        child: Text(
                          'Skip Tutorial',
                          style: TextStyle(
                            color: AppTheme.colors.textSecondary,
                            fontFamily: AppTheme.fonts.primary,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTutorialStep(TutorialStep step) {
    return Padding(
      padding: EdgeInsets.all(AppTheme.spacing.lg),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(AppTheme.spacing.xl),
            decoration: BoxDecoration(
              color: AppTheme.colors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.xl),
              border: Border.all(color: AppTheme.colors.primary),
              boxShadow: AppTheme.shadows.primary,
            ),
            child: Icon(
              step.icon,
              size: 64,
              color: AppTheme.colors.primary,
            ),
          ),
          SizedBox(height: AppTheme.spacing.xl),
          Text(
            step.title,
            style: TextStyle(
              fontSize: 24,
              fontFamily: AppTheme.fonts.primary,
              color: AppTheme.colors.text,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: AppTheme.spacing.md),
          Text(
            step.description,
            style: TextStyle(
              fontSize: 16,
              color: AppTheme.colors.textSecondary,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildPageIndicator(int index) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4),
      height: 8,
      width: _currentPage == index ? 24 : 8,
      decoration: BoxDecoration(
        color: _currentPage == index
            ? AppTheme.colors.primary
            : AppTheme.colors.primary.withOpacity(0.3),
        borderRadius: BorderRadius.circular(4),
      ),
    );
  }
}

class TutorialStep {
  final IconData icon;
  final String title;
  final String description;

  TutorialStep({
    required this.icon,
    required this.title,
    required this.description,
  });
}