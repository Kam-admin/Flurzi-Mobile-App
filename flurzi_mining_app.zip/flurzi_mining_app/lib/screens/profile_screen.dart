import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../services/currency_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with TickerProviderStateMixin {
  late AnimationController _headerAnimationController;
  late AnimationController _cardsAnimationController;
  late Animation<double> _headerSlideAnimation;
  late Animation<double> _cardsFadeAnimation;
  
  final CurrencyService _currencyService = CurrencyService();
  bool _notificationsEnabled = true;
  bool _autoPlayEnabled = false;
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;

  @override
  void initState() {
    super.initState();
    
    _headerAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _cardsAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _headerSlideAnimation = Tween<double>(
      begin: -100,
      end: 0,
    ).animate(CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeOutBack,
    ));
    
    _cardsFadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _cardsAnimationController,
      curve: Curves.easeOut,
    ));
    
    // Start animations
    _headerAnimationController.forward();
    Future.delayed(const Duration(milliseconds: 300), () {
      _cardsAnimationController.forward();
    });
    
    // Load user preferences
    _loadUserPreferences();
  }

  @override
  void dispose() {
    _headerAnimationController.dispose();
    _cardsAnimationController.dispose();
    super.dispose();
  }

  void _loadUserPreferences() {
    final appProvider = context.read<AppProvider>();
    final user = appProvider.user;
    
    if (user != null) {
      setState(() {
        _notificationsEnabled = user.preferences['notifications'] ?? true;
        _autoPlayEnabled = user.hasAutoPlayUpgrade;
        _soundEnabled = user.preferences['sound'] ?? true;
        _vibrationEnabled = user.preferences['vibration'] ?? true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.colors.background,
      body: SafeArea(
        child: Consumer<AppProvider>(builder: (context, appProvider, child) {
          return SingleChildScrollView(
            child: Column(
              children: [
                // Header with user info
                _buildHeader(appProvider),
                
                // Stats cards
                _buildStatsCards(appProvider),
                
                // Settings sections
                _buildSettingsSection(appProvider),
                
                // Developer section (if enabled)
                if (appProvider.user?.isDeveloperMode ?? false)
                  _buildDeveloperSection(appProvider),
                
                // Account actions
                _buildAccountActions(appProvider),
                
                const SizedBox(height: 20),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _buildHeader(AppProvider appProvider) {
    return AnimatedBuilder(
      animation: _headerSlideAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _headerSlideAnimation.value),
          child: Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.colors.primary.withOpacity(0.2),
                  AppTheme.colors.secondary.withOpacity(0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
              border: Border.all(
                color: AppTheme.colors.primary.withOpacity(0.5),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.colors.primary.withOpacity(0.3),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
                ...AppTheme.shadows.medium,
              ],
            ),
            child: Column(
              children: [
                // Profile picture and basic info
                Row(
                  children: [
                    // Avatar
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: AppTheme.colors.primary,
                          width: 3,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.colors.primary.withOpacity(0.3),
                            blurRadius: 10,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: appProvider.user?.photoUrl != null
                            ? Image.network(
                                appProvider.user!.photoUrl!,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return _buildDefaultAvatar();
                                },
                              )
                            : _buildDefaultAvatar(),
                      ),
                    ).animate(onPlay: (controller) => controller.repeat())
                      .scale(duration: 3000.ms, begin: 0.95, end: 1.05)
                      .then()
                      .scale(duration: 3000.ms, begin: 1.05, end: 0.95),
                    
                    const SizedBox(width: 16),
                    
                    // User info
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            appProvider.user?.displayName ?? 'Anonymous User',
                            style: TextStyle(
                              color: AppTheme.colors.text,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              fontFamily: AppTheme.fonts.primary,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            appProvider.user?.email ?? 'No email',
                            style: TextStyle(
                              color: AppTheme.colors.textSecondary,
                              fontSize: 14,
                              fontFamily: AppTheme.fonts.secondary,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.colors.primary.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(
                                AppTheme.borderRadius.small,
                              ),
                              border: Border.all(
                                color: AppTheme.colors.primary,
                                width: 1,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  LucideIcons.crown,
                                  color: AppTheme.colors.primary,
                                  size: 12,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  'Level ${_getUserLevel(appProvider)}',
                                  style: TextStyle(
                                    color: AppTheme.colors.primary,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: AppTheme.fonts.primary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    // Edit button
                    GestureDetector(
                      onTap: () => _showEditProfileDialog(appProvider),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppTheme.colors.surface,
                          borderRadius: BorderRadius.circular(
                            AppTheme.borderRadius.small,
                          ),
                          border: Border.all(
                            color: AppTheme.colors.border,
                            width: 1,
                          ),
                        ),
                        child: Icon(
                          LucideIcons.edit,
                          color: AppTheme.colors.primary,
                          size: 16,
                        ),
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 20),
                
                // Member since and country
                Row(
                  children: [
                    Expanded(
                      child: _buildInfoItem(
                        'Member Since',
                        _formatMemberSince(appProvider.user?.createdAt),
                        LucideIcons.calendar,
                        AppTheme.colors.secondary,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildInfoItem(
                        'Country',
                        appProvider.user?.country ?? 'Unknown',
                        LucideIcons.mapPin,
                        AppTheme.colors.warning,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildDefaultAvatar() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.colors.primary,
            AppTheme.colors.secondary,
          ],
        ),
      ),
      child: Icon(
        LucideIcons.user,
        color: AppTheme.colors.background,
        size: 40,
      ),
    );
  }

  Widget _buildInfoItem(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: color,
                size: 16,
              ),
              const SizedBox(width: 6),
              Text(
                title,
                style: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontSize: 12,
                  fontFamily: AppTheme.fonts.secondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildStatsCards(AppProvider appProvider) {
    return AnimatedBuilder(
      animation: _cardsFadeAnimation,
      builder: (context, child) {
        return Opacity(
          opacity: _cardsFadeAnimation.value,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    'Total Earnings',
                    _currencyService.formatCurrency(
                      appProvider.user?.totalEarnings ?? 0.0,
                      appProvider.userCurrency,
                    ),
                    LucideIcons.dollarSign,
                    AppTheme.colors.success,
                  ).animate(delay: 100.ms)
                    .slideX(begin: -0.5, duration: 600.ms, curve: Curves.easeOutBack),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    'Ads Watched',
                    '${appProvider.user?.totalAdsWatched ?? 0}',
                    LucideIcons.play,
                    AppTheme.colors.primary,
                  ).animate(delay: 200.ms)
                    .slideX(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: AppTheme.shadows.small,
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
            ),
            child: Icon(
              icon,
              color: color,
              size: 20,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: 12,
              fontFamily: AppTheme.fonts.secondary,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsSection(AppProvider appProvider) {
    return Container(
      margin: const EdgeInsets.all(16),
      child: Column(
        children: [
          // App Settings
          _buildSettingsCard(
            'App Settings',
            LucideIcons.settings,
            AppTheme.colors.primary,
            [
              _buildSettingItem(
                'Notifications',
                'Receive push notifications',
                LucideIcons.bell,
                Switch(
                  value: _notificationsEnabled,
                  onChanged: (value) => _updateNotifications(value, appProvider),
                  activeColor: AppTheme.colors.primary,
                ),
              ),
              _buildSettingItem(
                'Sound Effects',
                'Play sound effects',
                LucideIcons.volume2,
                Switch(
                  value: _soundEnabled,
                  onChanged: (value) => _updateSound(value, appProvider),
                  activeColor: AppTheme.colors.primary,
                ),
              ),
              _buildSettingItem(
                'Vibration',
                'Haptic feedback',
                LucideIcons.smartphone,
                Switch(
                  value: _vibrationEnabled,
                  onChanged: (value) => _updateVibration(value, appProvider),
                  activeColor: AppTheme.colors.primary,
                ),
              ),
            ],
          ).animate(delay: 300.ms)
            .slideY(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack),
          
          const SizedBox(height: 16),
          
          // Premium Features
          _buildSettingsCard(
            'Premium Features',
            LucideIcons.star,
            AppTheme.colors.warning,
            [
              _buildSettingItem(
                'Auto-Play Upgrade',
                appProvider.user?.hasAutoPlayUpgrade ?? false
                    ? 'Active - 5s delay removed'
                    : 'Upgrade for £5.99',
                LucideIcons.zap,
                appProvider.user?.hasAutoPlayUpgrade ?? false
                    ? Icon(
                        LucideIcons.checkCircle,
                        color: AppTheme.colors.success,
                        size: 20,
                      )
                    : GestureDetector(
                        onTap: () => _showAutoPlayUpgradeDialog(appProvider),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.colors.warning,
                            borderRadius: BorderRadius.circular(
                              AppTheme.borderRadius.small,
                            ),
                          ),
                          child: Text(
                            'Upgrade',
                            style: TextStyle(
                              color: AppTheme.colors.background,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: AppTheme.fonts.primary,
                            ),
                          ),
                        ),
                      ),
              ),
            ],
          ).animate(delay: 400.ms)
            .slideY(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack),
          
          const SizedBox(height: 16),
          
          // Developer Settings
          _buildSettingsCard(
            'Developer Settings',
            LucideIcons.code,
            AppTheme.colors.secondary,
            [
              _buildSettingItem(
                'Developer Mode',
                'Enable SDK and testing features',
                LucideIcons.terminal,
                Switch(
                  value: appProvider.user?.isDeveloperMode ?? false,
                  onChanged: (value) => _toggleDeveloperMode(value, appProvider),
                  activeColor: AppTheme.colors.secondary,
                ),
              ),
            ],
          ).animate(delay: 500.ms)
            .slideY(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack),
        ],
      ),
    );
  }

  Widget _buildSettingsCard(
    String title,
    IconData icon,
    Color color,
    List<Widget> children,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
        boxShadow: AppTheme.shadows.small,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
                ),
                child: Icon(
                  icon,
                  color: color,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  Widget _buildSettingItem(
    String title,
    String subtitle,
    IconData icon,
    Widget trailing,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.colors.background,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: AppTheme.colors.primary,
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 12,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
              ],
            ),
          ),
          trailing,
        ],
      ),
    );
  }

  Widget _buildDeveloperSection(AppProvider appProvider) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.colors.secondary.withOpacity(0.2),
            AppTheme.colors.primary.withOpacity(0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.secondary.withOpacity(0.5),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.colors.secondary.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                LucideIcons.code,
                color: AppTheme.colors.secondary,
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Developer Tools',
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          // Developer ID
          _buildDeveloperInfoItem(
            'Developer ID',
            appProvider.user?.id ?? 'N/A',
            LucideIcons.key,
            () => _copyToClipboard(appProvider.user?.id ?? ''),
          ),
          
          // App Check Token
          _buildDeveloperInfoItem(
            'App Check Token',
            'tap to generate',
            LucideIcons.shield,
            () => _generateAppCheckToken(appProvider),
          ),
          
          const SizedBox(height: 16),
          
          // SDK Documentation
          _buildDeveloperActionButton(
            'SDK Documentation',
            'View API reference and examples',
            LucideIcons.book,
            AppTheme.colors.primary,
            () => _openSDKDocumentation(),
          ),
          
          const SizedBox(height: 12),
          
          // Test Webhooks
          _buildDeveloperActionButton(
            'Test Webhooks',
            'Sandbox mode for testing',
            LucideIcons.webhook,
            AppTheme.colors.warning,
            () => _openTestWebhooks(appProvider),
          ),
        ],
      ),
    ).animate(delay: 600.ms)
      .slideY(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack);
  }

  Widget _buildDeveloperInfoItem(
    String title,
    String value,
    IconData icon,
    VoidCallback onTap,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: AppTheme.colors.secondary,
            size: 16,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 12,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: onTap,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: AppTheme.colors.secondary.withOpacity(0.2),
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
              ),
              child: Icon(
                LucideIcons.copy,
                color: AppTheme.colors.secondary,
                size: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeveloperActionButton(
    String title,
    String subtitle,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
          border: Border.all(
            color: color.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
              ),
              child: Icon(
                icon,
                color: color,
                size: 16,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: AppTheme.colors.text,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: AppTheme.fonts.primary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: AppTheme.colors.textSecondary,
                      fontSize: 12,
                      fontFamily: AppTheme.fonts.secondary,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              LucideIcons.externalLink,
              color: color,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccountActions(AppProvider appProvider) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          // Account management
          _buildActionButton(
            'Privacy Policy',
            'View our privacy policy',
            LucideIcons.shield,
            AppTheme.colors.primary,
            () => _openPrivacyPolicy(),
          ).animate(delay: 700.ms)
            .slideX(begin: -0.5, duration: 600.ms, curve: Curves.easeOutBack),
          
          const SizedBox(height: 12),
          
          _buildActionButton(
            'Terms of Service',
            'View terms and conditions',
            LucideIcons.fileText,
            AppTheme.colors.secondary,
            () => _openTermsOfService(),
          ).animate(delay: 800.ms)
            .slideX(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack),
          
          const SizedBox(height: 12),
          
          _buildActionButton(
            'Contact Support',
            'Get help with your account',
            LucideIcons.helpCircle,
            AppTheme.colors.warning,
            () => _contactSupport(),
          ).animate(delay: 900.ms)
            .slideX(begin: -0.5, duration: 600.ms, curve: Curves.easeOutBack),
          
          const SizedBox(height: 20),
          
          // Sign out button
          _buildActionButton(
            'Sign Out',
            'Sign out of your account',
            LucideIcons.logOut,
            AppTheme.colors.error,
            () => _showSignOutDialog(appProvider),
          ).animate(delay: 1000.ms)
            .slideY(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack),
        ],
      ),
    );
  }

  Widget _buildActionButton(
    String title,
    String subtitle,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.colors.surface,
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
          border: Border.all(
            color: color.withOpacity(0.3),
            width: 1,
          ),
          boxShadow: AppTheme.shadows.small,
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
              ),
              child: Icon(
                icon,
                color: color,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: AppTheme.colors.text,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: AppTheme.fonts.primary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: AppTheme.colors.textSecondary,
                      fontSize: 12,
                      fontFamily: AppTheme.fonts.secondary,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              LucideIcons.chevronRight,
              color: AppTheme.colors.textSecondary,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  // Helper methods
  int _getUserLevel(AppProvider appProvider) {
    final totalAds = appProvider.user?.totalAdsWatched ?? 0;
    return (totalAds / 100).floor() + 1;
  }

  String _formatMemberSince(DateTime? date) {
    if (date == null) return 'Unknown';
    return '${date.month}/${date.year}';
  }

  void _updateNotifications(bool value, AppProvider appProvider) {
    setState(() {
      _notificationsEnabled = value;
    });
    appProvider.updateUserPreference('notifications', value);
  }

  void _updateSound(bool value, AppProvider appProvider) {
    setState(() {
      _soundEnabled = value;
    });
    appProvider.updateUserPreference('sound', value);
  }

  void _updateVibration(bool value, AppProvider appProvider) {
    setState(() {
      _vibrationEnabled = value;
    });
    appProvider.updateUserPreference('vibration', value);
  }

  void _toggleDeveloperMode(bool value, AppProvider appProvider) {
    appProvider.toggleDeveloperMode(value);
  }

  void _showEditProfileDialog(AppProvider appProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.colors.surface,
        title: Text(
          'Edit Profile',
          style: TextStyle(
            color: AppTheme.colors.text,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        content: Text(
          'Profile editing will be available in a future update.',
          style: TextStyle(
            color: AppTheme.colors.textSecondary,
            fontFamily: AppTheme.fonts.secondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'OK',
              style: TextStyle(
                color: AppTheme.colors.primary,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showAutoPlayUpgradeDialog(AppProvider appProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.colors.surface,
        title: Text(
          'Auto-Play Upgrade',
          style: TextStyle(
            color: AppTheme.colors.text,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Upgrade to remove the 5-second delay between ads and earn faster!',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontFamily: AppTheme.fonts.secondary,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Price: £5.99 (one-time payment)',
              style: TextStyle(
                color: AppTheme.colors.warning,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _purchaseAutoPlayUpgrade(appProvider);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.colors.warning,
              foregroundColor: AppTheme.colors.background,
            ),
            child: Text(
              'Upgrade',
              style: TextStyle(
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showSignOutDialog(AppProvider appProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.colors.surface,
        title: Text(
          'Sign Out',
          style: TextStyle(
            color: AppTheme.colors.text,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        content: Text(
          'Are you sure you want to sign out?',
          style: TextStyle(
            color: AppTheme.colors.textSecondary,
            fontFamily: AppTheme.fonts.secondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              appProvider.signOut();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.colors.error,
              foregroundColor: AppTheme.colors.background,
            ),
            child: Text(
              'Sign Out',
              style: TextStyle(
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _copyToClipboard(String text) {
    // TODO: Implement clipboard functionality
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Copied to clipboard',
          style: TextStyle(
            color: AppTheme.colors.background,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        backgroundColor: AppTheme.colors.success,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        ),
      ),
    );
  }

  void _generateAppCheckToken(AppProvider appProvider) async {
    try {
      final token = await appProvider.generateAppCheckToken();
      _copyToClipboard(token);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Failed to generate token: $e',
            style: TextStyle(
              color: AppTheme.colors.background,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          backgroundColor: AppTheme.colors.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
          ),
        ),
      );
    }
  }

  void _openSDKDocumentation() async {
    const url = 'https://docs.flurzi.app/sdk';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    }
  }

  void _openTestWebhooks(AppProvider appProvider) {
    // TODO: Implement test webhooks interface
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Test webhooks interface coming soon',
          style: TextStyle(
            color: AppTheme.colors.background,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        backgroundColor: AppTheme.colors.warning,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        ),
      ),
    );
  }

  void _openPrivacyPolicy() async {
    const url = 'https://flurzi.app/privacy';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    }
  }

  void _openTermsOfService() async {
    const url = 'https://flurzi.app/terms';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    }
  }

  void _contactSupport() async {
    const url = 'mailto:support@flurzi.app';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    }
  }

  void _purchaseAutoPlayUpgrade(AppProvider appProvider) async {
    try {
      await appProvider.purchaseAutoPlayUpgrade();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Auto-Play upgrade purchased successfully!',
              style: TextStyle(
                color: AppTheme.colors.background,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
            backgroundColor: AppTheme.colors.success,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Purchase failed: $e',
              style: TextStyle(
                color: AppTheme.colors.background,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
            backgroundColor: AppTheme.colors.error,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
            ),
          ),
        );
      }
    }
  }
}