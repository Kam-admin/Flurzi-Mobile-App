import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../widgets/tier_card.dart';
import '../widgets/neon_button.dart';
import '../services/currency_service.dart';

class MiningScreen extends StatefulWidget {
  const MiningScreen({super.key});

  @override
  State<MiningScreen> createState() => _MiningScreenState();
}

class _MiningScreenState extends State<MiningScreen>
    with TickerProviderStateMixin {
  late AnimationController _headerAnimationController;
  late AnimationController _statsAnimationController;
  late Animation<double> _headerSlideAnimation;
  late Animation<double> _statsScaleAnimation;
  
  int _selectedTierIndex = -1;
  final ScrollController _scrollController = ScrollController();
  final CurrencyService _currencyService = CurrencyService();

  @override
  void initState() {
    super.initState();
    
    _headerAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _statsAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );
    
    _headerSlideAnimation = Tween<double>(
      begin: -100,
      end: 0,
    ).animate(CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeOutBack,
    ));
    
    _statsScaleAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _statsAnimationController,
      curve: Curves.elasticOut,
    ));
    
    // Start animations
    _headerAnimationController.forward();
    Future.delayed(const Duration(milliseconds: 300), () {
      _statsAnimationController.forward();
    });
    
    // Load data
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppProvider>().loadTiers();
    });
  }

  @override
  void dispose() {
    _headerAnimationController.dispose();
    _statsAnimationController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.colors.background,
      body: SafeArea(
        child: Consumer<AppProvider>(builder: (context, appProvider, child) {
          return CustomScrollView(
            controller: _scrollController,
            slivers: [
              // Header with mining stats
              _buildHeader(appProvider),
              
              // Quick actions
              _buildQuickActions(appProvider),
              
              // Tier grid
              _buildTierGrid(appProvider),
              
              // Bottom padding
              const SliverToBoxAdapter(
                child: SizedBox(height: 100),
              ),
            ],
          );
        }),
      ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  Widget _buildHeader(AppProvider appProvider) {
    return SliverToBoxAdapter(
      child: AnimatedBuilder(
        animation: _headerSlideAnimation,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(0, _headerSlideAnimation.value),
            child: Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppTheme.colors.primary.withOpacity(0.1),
                    AppTheme.colors.secondary.withOpacity(0.05),
                  ],
                ),
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
                border: Border.all(
                  color: AppTheme.colors.primary.withOpacity(0.3),
                  width: 1,
                ),
                boxShadow: AppTheme.shadows.medium,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title and mining status
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Mining Dashboard',
                            style: TextStyle(
                              color: AppTheme.colors.text,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              fontFamily: AppTheme.fonts.primary,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: appProvider.hasActiveTiers
                                      ? AppTheme.colors.success
                                      : AppTheme.colors.warning,
                                  shape: BoxShape.circle,
                                ),
                              ).animate(onPlay: (controller) => controller.repeat())
                                .fadeIn(duration: 1000.ms)
                                .then()
                                .fadeOut(duration: 1000.ms),
                              const SizedBox(width: 8),
                              Text(
                                appProvider.hasActiveTiers ? 'Mining Active' : 'Mining Inactive',
                                style: TextStyle(
                                  color: AppTheme.colors.textSecondary,
                                  fontSize: 14,
                                  fontFamily: AppTheme.fonts.secondary,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      
                      // Mining power indicator
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: AppTheme.colors.primary.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                          border: Border.all(
                            color: AppTheme.colors.primary,
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              LucideIcons.zap,
                              color: AppTheme.colors.primary,
                              size: 16,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '${appProvider.activeTiersCount}/${appProvider.totalTiers}',
                              style: TextStyle(
                                color: AppTheme.colors.primary,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: AppTheme.fonts.primary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 20),
                  
                  // Stats grid
                  _buildStatsGrid(appProvider),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatsGrid(AppProvider appProvider) {
    return AnimatedBuilder(
      animation: _statsScaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _statsScaleAnimation.value,
          child: GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 2.5,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            children: [
              _buildStatCard(
                'Total Earnings',
                _currencyService.formatCurrency(
                  appProvider.user?.totalEarnings ?? 0,
                  appProvider.userCurrency,
                ),
                LucideIcons.dollarSign,
                AppTheme.colors.success,
              ),
              _buildStatCard(
                'Daily Earnings',
                _currencyService.formatCurrency(
                  appProvider.dailyEarnings,
                  appProvider.userCurrency,
                ),
                LucideIcons.trendingUp,
                AppTheme.colors.primary,
              ),
              _buildStatCard(
                'Ads Watched',
                '${appProvider.user?.totalAdsWatched ?? 0}',
                LucideIcons.eye,
                AppTheme.colors.secondary,
              ),
              _buildStatCard(
                'Active Tiers',
                '${appProvider.activeTiersCount}',
                LucideIcons.layers,
                AppTheme.colors.warning,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(
                icon,
                color: color,
                size: 16,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 11,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          Text(
            value,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActions(AppProvider appProvider) {
    return SliverToBoxAdapter(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            Expanded(
              child: NeonButton(
                text: 'WATCH AD',
                onPressed: appProvider.canWatchMoreAds ? () => _watchQuickAd(appProvider) : null,
                variant: NeonButtonVariant.primary,
                icon: LucideIcons.play,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: NeonButton(
                text: 'AUTO-PLAY',
                onPressed: appProvider.user?.hasAutoPlayUpgrade == true
                    ? () => _toggleAutoPlay(appProvider)
                    : () => _showAutoPlayUpgrade(),
                variant: appProvider.user?.hasAutoPlayUpgrade == true
                    ? NeonButtonVariant.success
                    : NeonButtonVariant.secondary,
                icon: appProvider.user?.hasAutoPlayUpgrade == true
                    ? LucideIcons.pause
                    : LucideIcons.crown,
              ),
            ),
          ],
        ),
      ).animate().slideX(begin: -1, duration: 600.ms, curve: Curves.easeOutBack),
    );
  }

  Widget _buildTierGrid(AppProvider appProvider) {
    if (appProvider.isLoading && appProvider.tiers.isEmpty) {
      return SliverToBoxAdapter(
        child: Container(
          height: 400,
          margin: const EdgeInsets.all(16),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(AppTheme.colors.primary),
                ),
                const SizedBox(height: 16),
                Text(
                  'Loading mining tiers...',
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 16,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return SliverPadding(
      padding: const EdgeInsets.all(16),
      sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.75,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
        ),
        delegate: SliverChildBuilderDelegate(
          (context, index) {
            if (index >= appProvider.tiers.length) return null;
            
            final tier = appProvider.tiers[index];
            return TierCard(
              tier: tier,
              isSelected: _selectedTierIndex == index,
              onTap: () => _selectTier(index),
            ).animate(delay: Duration(milliseconds: index * 100))
              .slideY(begin: 1, duration: 600.ms, curve: Curves.easeOutBack)
              .fadeIn(duration: 400.ms);
          },
          childCount: appProvider.tiers.length,
        ),
      ),
    );
  }

  Widget _buildFloatingActionButton() {
    return Consumer<AppProvider>(builder: (context, appProvider, child) {
      if (!appProvider.hasActiveTiers) return const SizedBox.shrink();
      
      return FloatingActionButton.extended(
        onPressed: () => _collectAllEarnings(appProvider),
        backgroundColor: AppTheme.colors.primary,
        foregroundColor: AppTheme.colors.background,
        icon: const Icon(LucideIcons.coins),
        label: Text(
          'COLLECT ALL',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
      ).animate(onPlay: (controller) => controller.repeat())
        .shimmer(duration: 2000.ms, color: AppTheme.colors.secondary.withOpacity(0.3));
    });
  }

  // Action methods
  void _selectTier(int index) {
    setState(() {
      _selectedTierIndex = _selectedTierIndex == index ? -1 : index;
    });
    
    // Scroll to selected tier
    if (_selectedTierIndex != -1) {
      final RenderBox? renderBox = context.findRenderObject() as RenderBox?;
      if (renderBox != null) {
        final position = (index ~/ 2) * 200.0; // Approximate card height
        _scrollController.animateTo(
          position,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
    }
  }

  void _watchQuickAd(AppProvider appProvider) async {
    // Find the best tier to watch ad for (highest earning active tier)
    final activeTiers = appProvider.tiers.where((tier) => tier.isActive).toList();
    if (activeTiers.isEmpty) {
      _showNoActiveTiersDialog();
      return;
    }
    
    activeTiers.sort((a, b) => b.dailyEarning.compareTo(a.dailyEarning));
    final bestTier = activeTiers.first;
    
    final result = await appProvider.watchAd(bestTier);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(result.message),
          backgroundColor: result.success ? AppTheme.colors.success : AppTheme.colors.error,
        ),
      );
    }
  }

  void _toggleAutoPlay(AppProvider appProvider) {
    // Implement auto-play toggle logic
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Auto-play toggled'),
        backgroundColor: AppTheme.colors.success,
      ),
    );
  }

  void _showAutoPlayUpgrade() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.colors.surface,
        title: Text(
          'Auto-Play Upgrade',
          style: TextStyle(
            color: AppTheme.colors.text,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              LucideIcons.crown,
              color: AppTheme.colors.warning,
              size: 48,
            ),
            const SizedBox(height: 16),
            Text(
              'Unlock auto-play feature for £5.99',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontFamily: AppTheme.fonts.secondary,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              '• 5-second delay between ads\n• Automatic tier progression\n• Background mining',
              style: TextStyle(
                color: AppTheme.colors.text,
                fontSize: 12,
                fontFamily: AppTheme.fonts.secondary,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'Cancel',
              style: TextStyle(color: AppTheme.colors.textSecondary),
            ),
          ),
          NeonButton(
            text: 'UPGRADE',
            onPressed: () {
              Navigator.of(context).pop();
              _purchaseAutoPlay();
            },
            variant: NeonButtonVariant.warning,
          ),
        ],
      ),
    );
  }

  void _showNoActiveTiersDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.colors.surface,
        title: Text(
          'No Active Tiers',
          style: TextStyle(
            color: AppTheme.colors.text,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        content: Text(
          'You need to unlock and activate at least one tier to watch ads.',
          style: TextStyle(
            color: AppTheme.colors.textSecondary,
            fontFamily: AppTheme.fonts.secondary,
          ),
        ),
        actions: [
          NeonButton(
            text: 'OK',
            onPressed: () => Navigator.of(context).pop(),
            variant: NeonButtonVariant.primary,
          ),
        ],
      ),
    );
  }

  void _collectAllEarnings(AppProvider appProvider) async {
    // Implement collect all earnings logic
    final totalEarnings = appProvider.pendingEarnings;
    if (totalEarnings > 0) {
      await appProvider.collectEarnings();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Collected ${_currencyService.formatCurrency(totalEarnings, appProvider.userCurrency)}!',
            ),
            backgroundColor: AppTheme.colors.success,
          ),
        );
      }
    }
  }

  void _purchaseAutoPlay() {
    // Implement auto-play purchase logic
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Auto-play upgrade purchased!'),
        backgroundColor: AppTheme.colors.success,
      ),
    );
  }
}