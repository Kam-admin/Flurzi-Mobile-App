import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../models/quest_model.dart';
import '../services/currency_service.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen>
    with TickerProviderStateMixin {
  late AnimationController _headerAnimationController;
  late AnimationController _cardsAnimationController;
  late Animation<double> _headerSlideAnimation;
  late Animation<double> _cardsFadeAnimation;
  
  final CurrencyService _currencyService = CurrencyService();
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _paypalController = TextEditingController();
  final TextEditingController _bankAccountController = TextEditingController();
  final TextEditingController _sortCodeController = TextEditingController();
  
  int _selectedTab = 0; // 0: Balance, 1: Withdraw, 2: History
  int _selectedWithdrawMethod = 0; // 0: PayPal, 1: Bank

  @override
  void initState() {
    super.initState();
    
    _headerAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _cardsAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _headerSlideAnimation = Tween<double>(
      begin: -100,
      end: 0,
    ).animate(CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeOutBack,
    ));
    
    _cardsFadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _cardsAnimationController,
      curve: Curves.easeOut,
    ));
    
    // Start animations
    _headerAnimationController.forward();
    Future.delayed(const Duration(milliseconds: 300), () {
      _cardsAnimationController.forward();
    });
    
    // Load withdrawal history
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppProvider>().loadWithdrawalHistory();
    });
  }

  @override
  void dispose() {
    _headerAnimationController.dispose();
    _cardsAnimationController.dispose();
    _amountController.dispose();
    _paypalController.dispose();
    _bankAccountController.dispose();
    _sortCodeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.colors.background,
      body: SafeArea(
        child: Consumer<AppProvider>(builder: (context, appProvider, child) {
          return Column(
            children: [
              // Header with balance
              _buildHeader(appProvider),
              
              // Tab selector
              _buildTabSelector(),
              
              // Content based on selected tab
              Expanded(
                child: _buildTabContent(appProvider),
              ),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildHeader(AppProvider appProvider) {
    return AnimatedBuilder(
      animation: _headerSlideAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _headerSlideAnimation.value),
          child: Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.colors.success.withOpacity(0.2),
                  AppTheme.colors.primary.withOpacity(0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
              border: Border.all(
                color: AppTheme.colors.success.withOpacity(0.5),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.colors.success.withOpacity(0.3),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
                ...AppTheme.shadows.medium,
              ],
            ),
            child: Column(
              children: [
                // Title and wallet icon
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      LucideIcons.wallet,
                      color: AppTheme.colors.success,
                      size: 32,
                    ).animate(onPlay: (controller) => controller.repeat())
                      .scale(duration: 2000.ms, begin: 0.9, end: 1.1)
                      .then()
                      .scale(duration: 2000.ms, begin: 1.1, end: 0.9),
                    const SizedBox(width: 12),
                    Text(
                      'My Wallet',
                      style: TextStyle(
                        color: AppTheme.colors.text,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 20),
                
                // Balance display
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.colors.surface,
                    borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                    border: Border.all(
                      color: AppTheme.colors.success.withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  child: Column(
                    children: [
                      Text(
                        'Available Balance',
                        style: TextStyle(
                          color: AppTheme.colors.textSecondary,
                          fontSize: 14,
                          fontFamily: AppTheme.fonts.secondary,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _currencyService.formatCurrency(
                          appProvider.user?.totalEarnings ?? 0.0,
                          appProvider.userCurrency,
                        ),
                        style: TextStyle(
                          color: AppTheme.colors.success,
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          fontFamily: AppTheme.fonts.primary,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            LucideIcons.trendingUp,
                            color: AppTheme.colors.primary,
                            size: 16,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Weekly: ${_currencyService.formatCurrency(
                              appProvider.user?.weeklyEarnings ?? 0.0,
                              appProvider.userCurrency,
                            )}',
                            style: TextStyle(
                              color: AppTheme.colors.primary,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: AppTheme.fonts.secondary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 16),
                
                // Quick stats
                Row(
                  children: [
                    Expanded(
                      child: _buildQuickStat(
                        'Pending',
                        _currencyService.formatCurrency(
                          _getPendingAmount(appProvider),
                          appProvider.userCurrency,
                        ),
                        LucideIcons.clock,
                        AppTheme.colors.warning,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildQuickStat(
                        'Withdrawn',
                        _currencyService.formatCurrency(
                          _getWithdrawnAmount(appProvider),
                          appProvider.userCurrency,
                        ),
                        LucideIcons.checkCircle,
                        AppTheme.colors.primary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildQuickStat(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: color,
                size: 16,
              ),
              const SizedBox(width: 6),
              Text(
                title,
                style: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontSize: 12,
                  fontFamily: AppTheme.fonts.secondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabSelector() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildTab('Balance', 0, LucideIcons.dollarSign),
          ),
          Expanded(
            child: _buildTab('Withdraw', 1, LucideIcons.send),
          ),
          Expanded(
            child: _buildTab('History', 2, LucideIcons.history),
          ),
        ],
      ),
    ).animate().slideY(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack);
  }

  Widget _buildTab(String title, int index, IconData icon) {
    final isSelected = _selectedTab == index;
    
    return GestureDetector(
      onTap: () => _selectTab(index),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.colors.primary
              : Colors.transparent,
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isSelected
                  ? AppTheme.colors.background
                  : AppTheme.colors.textSecondary,
              size: 20,
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(
                color: isSelected
                    ? AppTheme.colors.background
                    : AppTheme.colors.textSecondary,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabContent(AppProvider appProvider) {
    return AnimatedBuilder(
      animation: _cardsFadeAnimation,
      builder: (context, child) {
        return Opacity(
          opacity: _cardsFadeAnimation.value,
          child: _getTabContent(appProvider),
        );
      },
    );
  }

  Widget _getTabContent(AppProvider appProvider) {
    switch (_selectedTab) {
      case 1:
        return _buildWithdrawTab(appProvider);
      case 2:
        return _buildHistoryTab(appProvider);
      default:
        return _buildBalanceTab(appProvider);
    }
  }

  Widget _buildBalanceTab(AppProvider appProvider) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Earnings breakdown
          _buildEarningsCard(appProvider),
          
          const SizedBox(height: 16),
          
          // Payment methods
          _buildPaymentMethodsCard(appProvider),
          
          const SizedBox(height: 16),
          
          // Currency settings
          _buildCurrencyCard(appProvider),
        ],
      ),
    );
  }

  Widget _buildEarningsCard(AppProvider appProvider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
        boxShadow: AppTheme.shadows.small,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                LucideIcons.trendingUp,
                color: AppTheme.colors.success,
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Earnings Breakdown',
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          // Earnings items
          _buildEarningsItem(
            'Ad Watching',
            appProvider.user?.adEarnings ?? 0.0,
            appProvider.userCurrency,
            LucideIcons.play,
            AppTheme.colors.primary,
          ),
          
          _buildEarningsItem(
            'Quest Rewards',
            appProvider.user?.questEarnings ?? 0.0,
            appProvider.userCurrency,
            LucideIcons.target,
            AppTheme.colors.secondary,
          ),
          
          _buildEarningsItem(
            'Team Bonuses',
            appProvider.user?.teamEarnings ?? 0.0,
            appProvider.userCurrency,
            LucideIcons.users,
            AppTheme.colors.warning,
          ),
          
          _buildEarningsItem(
            'Referral Bonuses',
            appProvider.user?.referralEarnings ?? 0.0,
            appProvider.userCurrency,
            LucideIcons.userPlus,
            AppTheme.colors.success,
          ),
        ],
      ),
    ).animate().slideX(begin: -0.5, duration: 600.ms, curve: Curves.easeOutBack);
  }

  Widget _buildEarningsItem(
    String title,
    double amount,
    String currency,
    IconData icon,
    Color color,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
            ),
            child: Icon(
              icon,
              color: color,
              size: 16,
            ),
          ),
          
          const SizedBox(width: 12),
          
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                color: AppTheme.colors.text,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ),
          
          Text(
            _currencyService.formatCurrency(amount, currency),
            style: TextStyle(
              color: color,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentMethodsCard(AppProvider appProvider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
        boxShadow: AppTheme.shadows.small,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                LucideIcons.creditCard,
                color: AppTheme.colors.primary,
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Payment Methods',
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          // PayPal
          _buildPaymentMethodItem(
            'PayPal',
            appProvider.user?.paymentMethods['paypal'] ?? 'Not configured',
            LucideIcons.dollarSign,
            AppTheme.colors.primary,
            appProvider.user?.paymentMethods.containsKey('paypal') ?? false,
          ),
          
          const SizedBox(height: 12),
          
          // Bank Transfer
          _buildPaymentMethodItem(
            'Bank Transfer',
            appProvider.user?.paymentMethods['bank'] ?? 'Not configured',
            LucideIcons.building,
            AppTheme.colors.secondary,
            appProvider.user?.paymentMethods.containsKey('bank') ?? false,
          ),
        ],
      ),
    ).animate().slideX(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack);
  }

  Widget _buildPaymentMethodItem(
    String title,
    String subtitle,
    IconData icon,
    Color color,
    bool isConfigured,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
            ),
            child: Icon(
              icon,
              color: color,
              size: 16,
            ),
          ),
          
          const SizedBox(width: 12),
          
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: AppTheme.colors.textSecondary,
                    fontSize: 12,
                    fontFamily: AppTheme.fonts.secondary,
                  ),
                ),
              ],
            ),
          ),
          
          Icon(
            isConfigured ? LucideIcons.checkCircle : LucideIcons.plus,
            color: isConfigured ? AppTheme.colors.success : color,
            size: 20,
          ),
        ],
      ),
    );
  }

  Widget _buildCurrencyCard(AppProvider appProvider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
        boxShadow: AppTheme.shadows.small,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                LucideIcons.globe,
                color: AppTheme.colors.warning,
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Currency Settings',
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Display Currency',
                      style: TextStyle(
                        color: AppTheme.colors.textSecondary,
                        fontSize: 12,
                        fontFamily: AppTheme.fonts.secondary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      appProvider.userCurrency,
                      style: TextStyle(
                        color: AppTheme.colors.text,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                  ],
                ),
              ),
              
              GestureDetector(
                onTap: () => _showCurrencySelector(appProvider),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.colors.warning.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
                    border: Border.all(
                      color: AppTheme.colors.warning,
                      width: 1,
                    ),
                  ),
                  child: Icon(
                    LucideIcons.edit,
                    color: AppTheme.colors.warning,
                    size: 16,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    ).animate().slideY(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack);
  }

  Widget _buildWithdrawTab(AppProvider appProvider) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Withdrawal method selector
          _buildWithdrawMethodSelector(),
          
          const SizedBox(height: 20),
          
          // Withdrawal form
          _buildWithdrawForm(appProvider),
        ],
      ),
    );
  }

  Widget _buildWithdrawMethodSelector() {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildWithdrawMethodTab('PayPal', 0, LucideIcons.dollarSign),
          ),
          Expanded(
            child: _buildWithdrawMethodTab('Bank', 1, LucideIcons.building),
          ),
        ],
      ),
    ).animate().slideY(begin: -0.5, duration: 600.ms, curve: Curves.easeOutBack);
  }

  Widget _buildWithdrawMethodTab(String title, int index, IconData icon) {
    final isSelected = _selectedWithdrawMethod == index;
    
    return GestureDetector(
      onTap: () => setState(() => _selectedWithdrawMethod = index),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.colors.primary
              : Colors.transparent,
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isSelected
                  ? AppTheme.colors.background
                  : AppTheme.colors.textSecondary,
              size: 20,
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                color: isSelected
                    ? AppTheme.colors.background
                    : AppTheme.colors.textSecondary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWithdrawForm(AppProvider appProvider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
        boxShadow: AppTheme.shadows.small,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _selectedWithdrawMethod == 0 ? 'PayPal Withdrawal' : 'Bank Transfer',
            style: TextStyle(
              color: AppTheme.colors.text,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Amount input
          _buildAmountInput(appProvider),
          
          const SizedBox(height: 16),
          
          // Payment details
          if (_selectedWithdrawMethod == 0)
            _buildPayPalForm()
          else
            _buildBankForm(),
          
          const SizedBox(height: 20),
          
          // Withdrawal info
          _buildWithdrawInfo(appProvider),
          
          const SizedBox(height: 20),
          
          // Submit button
          _buildSubmitButton(appProvider),
        ],
      ),
    ).animate().slideY(begin: 0.5, duration: 600.ms, curve: Curves.easeOutBack);
  }

  Widget _buildAmountInput(AppProvider appProvider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Withdrawal Amount',
          style: TextStyle(
            color: AppTheme.colors.text,
            fontSize: 14,
            fontWeight: FontWeight.bold,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _amountController,
          keyboardType: TextInputType.number,
          style: TextStyle(
            color: AppTheme.colors.text,
            fontSize: 16,
            fontFamily: AppTheme.fonts.primary,
          ),
          decoration: InputDecoration(
            hintText: 'Enter amount',
            hintStyle: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontFamily: AppTheme.fonts.secondary,
            ),
            prefixIcon: Icon(
              LucideIcons.dollarSign,
              color: AppTheme.colors.primary,
            ),
            suffixText: appProvider.userCurrency,
            suffixStyle: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontFamily: AppTheme.fonts.secondary,
            ),
            filled: true,
            fillColor: AppTheme.colors.background,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
              borderSide: BorderSide(
                color: AppTheme.colors.border,
                width: 1,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
              borderSide: BorderSide(
                color: AppTheme.colors.border,
                width: 1,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
              borderSide: BorderSide(
                color: AppTheme.colors.primary,
                width: 2,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Text(
              'Available: ',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 12,
                fontFamily: AppTheme.fonts.secondary,
              ),
            ),
            Text(
              _currencyService.formatCurrency(
                appProvider.user?.totalEarnings ?? 0.0,
                appProvider.userCurrency,
              ),
              style: TextStyle(
                color: AppTheme.colors.success,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildPayPalForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'PayPal Email',
          style: TextStyle(
            color: AppTheme.colors.text,
            fontSize: 14,
            fontWeight: FontWeight.bold,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _paypalController,
          keyboardType: TextInputType.emailAddress,
          style: TextStyle(
            color: AppTheme.colors.text,
            fontSize: 16,
            fontFamily: AppTheme.fonts.primary,
          ),
          decoration: InputDecoration(
            hintText: 'your.email@paypal.com',
            hintStyle: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontFamily: AppTheme.fonts.secondary,
            ),
            prefixIcon: Icon(
              LucideIcons.mail,
              color: AppTheme.colors.primary,
            ),
            filled: true,
            fillColor: AppTheme.colors.background,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
              borderSide: BorderSide(
                color: AppTheme.colors.border,
                width: 1,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
              borderSide: BorderSide(
                color: AppTheme.colors.border,
                width: 1,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
              borderSide: BorderSide(
                color: AppTheme.colors.primary,
                width: 2,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBankForm() {
    return Column(
      children: [
        // Account number
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Account Number',
              style: TextStyle(
                color: AppTheme.colors.text,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _bankAccountController,
              keyboardType: TextInputType.number,
              style: TextStyle(
                color: AppTheme.colors.text,
                fontSize: 16,
                fontFamily: AppTheme.fonts.primary,
              ),
              decoration: InputDecoration(
                hintText: '12345678',
                hintStyle: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontFamily: AppTheme.fonts.secondary,
                ),
                prefixIcon: Icon(
                  LucideIcons.creditCard,
                  color: AppTheme.colors.primary,
                ),
                filled: true,
                fillColor: AppTheme.colors.background,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                  borderSide: BorderSide(
                    color: AppTheme.colors.border,
                    width: 1,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                  borderSide: BorderSide(
                    color: AppTheme.colors.border,
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                  borderSide: BorderSide(
                    color: AppTheme.colors.primary,
                    width: 2,
                  ),
                ),
              ),
            ),
          ],
        ),
        
        const SizedBox(height: 16),
        
        // Sort code
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sort Code',
              style: TextStyle(
                color: AppTheme.colors.text,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _sortCodeController,
              keyboardType: TextInputType.number,
              style: TextStyle(
                color: AppTheme.colors.text,
                fontSize: 16,
                fontFamily: AppTheme.fonts.primary,
              ),
              decoration: InputDecoration(
                hintText: '12-34-56',
                hintStyle: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontFamily: AppTheme.fonts.secondary,
                ),
                prefixIcon: Icon(
                  LucideIcons.building,
                  color: AppTheme.colors.primary,
                ),
                filled: true,
                fillColor: AppTheme.colors.background,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                  borderSide: BorderSide(
                    color: AppTheme.colors.border,
                    width: 1,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                  borderSide: BorderSide(
                    color: AppTheme.colors.border,
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
                  borderSide: BorderSide(
                    color: AppTheme.colors.primary,
                    width: 2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildWithdrawInfo(AppProvider appProvider) {
    final amount = double.tryParse(_amountController.text) ?? 0.0;
    final fee = _currencyService.calculateWithdrawalFee(
      amount,
      _selectedWithdrawMethod == 0 ? 'paypal' : 'bank',
    );
    final total = amount - fee;
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.colors.background,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: AppTheme.colors.border,
          width: 1,
        ),
      ),
      child: Column(
        children: [
          _buildInfoRow(
            'Withdrawal Amount',
            _currencyService.formatCurrency(amount, appProvider.userCurrency),
          ),
          _buildInfoRow(
            'Processing Fee',
            _currencyService.formatCurrency(fee, appProvider.userCurrency),
          ),
          const Divider(),
          _buildInfoRow(
            'You will receive',
            _currencyService.formatCurrency(total, appProvider.userCurrency),
            isTotal: true,
          ),
          const SizedBox(height: 8),
          Text(
            'Processing time: ${_selectedWithdrawMethod == 0 ? '1-2 business days' : '3-5 business days'}',
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: 12,
              fontFamily: AppTheme.fonts.secondary,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              color: AppTheme.colors.textSecondary,
              fontSize: isTotal ? 14 : 12,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
              fontFamily: AppTheme.fonts.secondary,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              color: isTotal ? AppTheme.colors.success : AppTheme.colors.text,
              fontSize: isTotal ? 16 : 12,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubmitButton(AppProvider appProvider) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () => _submitWithdrawal(appProvider),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppTheme.colors.primary,
          foregroundColor: AppTheme.colors.background,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
          ),
          elevation: 0,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              LucideIcons.send,
              size: 20,
            ),
            const SizedBox(width: 8),
            Text(
              'Submit Withdrawal Request',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ],
        ),
      ),
    ).animate().scale(duration: 200.ms, curve: Curves.easeOut);
  }

  Widget _buildHistoryTab(AppProvider appProvider) {
    if (appProvider.isLoading && appProvider.withdrawalHistory.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppTheme.colors.primary),
            ),
            const SizedBox(height: 16),
            Text(
              'Loading withdrawal history...',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 16,
                fontFamily: AppTheme.fonts.secondary,
              ),
            ),
          ],
        ),
      );
    }

    if (appProvider.withdrawalHistory.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              LucideIcons.history,
              color: AppTheme.colors.textSecondary,
              size: 64,
            ),
            const SizedBox(height: 16),
            Text(
              'No withdrawal history',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 16,
                fontFamily: AppTheme.fonts.secondary,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Your withdrawal requests will appear here',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 14,
                fontFamily: AppTheme.fonts.secondary,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: appProvider.withdrawalHistory.length,
      itemBuilder: (context, index) {
        final withdrawal = appProvider.withdrawalHistory[index];
        
        return _buildWithdrawalHistoryItem(withdrawal, appProvider)
            .animate(delay: Duration(milliseconds: index * 100))
            .slideX(begin: 1, duration: 400.ms, curve: Curves.easeOutBack);
      },
    );
  }

  Widget _buildWithdrawalHistoryItem(
    WithdrawalRequest withdrawal,
    AppProvider appProvider,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
        border: Border.all(
          color: _getStatusColor(withdrawal.status),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _getStatusColor(withdrawal.status).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
                ),
                child: Icon(
                  _getStatusIcon(withdrawal.status),
                  color: _getStatusColor(withdrawal.status),
                  size: 16,
                ),
              ),
              
              const SizedBox(width: 12),
              
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _currencyService.formatCurrency(
                        withdrawal.amount,
                        appProvider.userCurrency,
                      ),
                      style: TextStyle(
                        color: AppTheme.colors.text,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: AppTheme.fonts.primary,
                      ),
                    ),
                    Text(
                      withdrawal.method.toUpperCase(),
                      style: TextStyle(
                        color: AppTheme.colors.textSecondary,
                        fontSize: 12,
                        fontFamily: AppTheme.fonts.secondary,
                      ),
                    ),
                  ],
                ),
              ),
              
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _getStatusColor(withdrawal.status).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(AppTheme.borderRadius.small),
                ),
                child: Text(
                  withdrawal.status.toUpperCase(),
                  style: TextStyle(
                    color: _getStatusColor(withdrawal.status),
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          Row(
            children: [
              Icon(
                LucideIcons.calendar,
                color: AppTheme.colors.textSecondary,
                size: 12,
              ),
              const SizedBox(width: 4),
              Text(
                'Requested: ${_formatWithdrawalDate(withdrawal.requestedAt)}',
                style: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontSize: 12,
                  fontFamily: AppTheme.fonts.secondary,
                ),
              ),
            ],
          ),
          
          if (withdrawal.processedAt != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Row(
                children: [
                  Icon(
                    LucideIcons.checkCircle,
                    color: AppTheme.colors.success,
                    size: 12,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'Processed: ${_formatWithdrawalDate(withdrawal.processedAt!)}',
                    style: TextStyle(
                      color: AppTheme.colors.success,
                      fontSize: 12,
                      fontFamily: AppTheme.fonts.secondary,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // Helper methods
  void _selectTab(int index) {
    setState(() {
      _selectedTab = index;
    });
    
    // Restart cards animation
    _cardsAnimationController.reset();
    _cardsAnimationController.forward();
  }

  double _getPendingAmount(AppProvider appProvider) {
    return appProvider.withdrawalHistory
        .where((w) => w.status == 'pending')
        .fold(0.0, (sum, w) => sum + w.amount);
  }

  double _getWithdrawnAmount(AppProvider appProvider) {
    return appProvider.withdrawalHistory
        .where((w) => w.status == 'completed')
        .fold(0.0, (sum, w) => sum + w.amount);
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return AppTheme.colors.warning;
      case 'processing':
        return AppTheme.colors.primary;
      case 'completed':
        return AppTheme.colors.success;
      case 'failed':
      case 'rejected':
        return AppTheme.colors.error;
      default:
        return AppTheme.colors.textSecondary;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return LucideIcons.clock;
      case 'processing':
        return LucideIcons.loader;
      case 'completed':
        return LucideIcons.checkCircle;
      case 'failed':
      case 'rejected':
        return LucideIcons.xCircle;
      default:
        return LucideIcons.help;
    }
  }

  String _formatWithdrawalDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  void _showCurrencySelector(AppProvider appProvider) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.colors.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppTheme.borderRadius.large),
        ),
      ),
      builder: (context) {
        final currencies = ['GBP', 'USD', 'EUR', 'CAD', 'AUD'];
        
        return Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Select Currency',
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
              const SizedBox(height: 20),
              ...currencies.map((currency) => ListTile(
                title: Text(
                  currency,
                  style: TextStyle(
                    color: AppTheme.colors.text,
                    fontFamily: AppTheme.fonts.primary,
                  ),
                ),
                trailing: appProvider.userCurrency == currency
                    ? Icon(
                        LucideIcons.check,
                        color: AppTheme.colors.success,
                      )
                    : null,
                onTap: () {
                  appProvider.updateUserCurrency(currency);
                  Navigator.pop(context);
                },
              )),
            ],
          ),
        );
      },
    );
  }

  void _submitWithdrawal(AppProvider appProvider) async {
    final amount = double.tryParse(_amountController.text);
    
    if (amount == null || amount <= 0) {
      _showError('Please enter a valid amount');
      return;
    }
    
    if (amount > (appProvider.user?.totalEarnings ?? 0.0)) {
      _showError('Insufficient balance');
      return;
    }
    
    String paymentDetails;
    if (_selectedWithdrawMethod == 0) {
      if (_paypalController.text.isEmpty) {
        _showError('Please enter your PayPal email');
        return;
      }
      paymentDetails = _paypalController.text;
    } else {
      if (_bankAccountController.text.isEmpty || _sortCodeController.text.isEmpty) {
        _showError('Please enter your bank details');
        return;
      }
      paymentDetails = '${_bankAccountController.text}|${_sortCodeController.text}';
    }
    
    try {
      await appProvider.submitWithdrawal(
        amount,
        _selectedWithdrawMethod == 0 ? 'paypal' : 'bank',
        paymentDetails,
      );
      
      // Clear form
      _amountController.clear();
      _paypalController.clear();
      _bankAccountController.clear();
      _sortCodeController.clear();
      
      // Switch to history tab
      _selectTab(2);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Withdrawal request submitted successfully!',
              style: TextStyle(
                color: AppTheme.colors.background,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
            backgroundColor: AppTheme.colors.success,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
            ),
          ),
        );
      }
    } catch (e) {
      _showError('Failed to submit withdrawal: $e');
    }
  }

  void _showError(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            message,
            style: TextStyle(
              color: AppTheme.colors.background,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
          backgroundColor: AppTheme.colors.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
          ),
        ),
      );
    }
  }
}