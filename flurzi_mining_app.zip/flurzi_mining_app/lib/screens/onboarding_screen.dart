import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../constants/theme.dart';
import '../widgets/neon_button.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _teamCodeController = TextEditingController();
  final _fullNameController = TextEditingController();
  final _nicknameController = TextEditingController();
  final _emailController = TextEditingController();
  bool _isJoiningTeam = false;
  int _step = 1; // 1: Welcome, 2: User Info, 3: Team Join (optional)

  void _handleGoogleSignIn() {
    if (_step == 1) {
      setState(() => _step = 2);
      return;
    }

    if (_fullNameController.text.isEmpty ||
        _nicknameController.text.isEmpty ||
        _emailController.text.isEmpty) {
      _showAlert('Missing Information', 'Please fill in all required fields');
      return;
    }

    // In production, implement actual Google sign-in
    context.go('/tutorial');
  }

  void _handleAppleSignIn() {
    if (_step == 1) {
      setState(() => _step = 2);
      return;
    }

    if (_fullNameController.text.isEmpty ||
        _nicknameController.text.isEmpty ||
        _emailController.text.isEmpty) {
      _showAlert('Missing Information', 'Please fill in all required fields');
      return;
    }

    // In production, implement actual Apple sign-in
    context.go('/tutorial');
  }

  void _handleTeamJoin() {
    if (_teamCodeController.text.length != 4) {
      _showAlert('Invalid Code', 'Team code must be 4 digits');
      return;
    }

    _showAlert(
      'Join Request Sent',
      'Your request to join the team has been sent. Please wait for approval.',
      onConfirm: () => context.go('/tutorial'),
    );
  }

  void _showAlert(String title, String message, {VoidCallback? onConfirm}) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              if (onConfirm != null) onConfirm();
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.colors.background,
              AppTheme.colors.surface,
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(AppTheme.spacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: AppTheme.spacing.xl),
                Icon(
                  LucideIcons.zap,
                  size: 64,
                  color: AppTheme.colors.primary,
                ),
                SizedBox(height: AppTheme.spacing.lg),
                Text(
                  _step == 1 ? 'Welcome to Flurzi' : 'Create Your Account',
                  style: TextStyle(
                    fontSize: 32,
                    fontFamily: AppTheme.fonts.primary,
                    color: AppTheme.colors.text,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: AppTheme.spacing.md),
                Text(
                  _step == 1
                      ? 'Join the next generation of mining'
                      : 'Fill in your details to get started',
                  style: TextStyle(
                    fontSize: 16,
                    color: AppTheme.colors.textSecondary,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: AppTheme.spacing.xl),
                if (_step == 2) ..._buildUserInfoForm(),
                if (_step == 3) ..._buildTeamJoinForm(),
                if (_step == 1) ...[
                  NeonButton(
                    text: 'Continue with Google',
                    onPressed: _handleGoogleSignIn,
                    icon: LucideIcons.mail,
                  ),
                  SizedBox(height: AppTheme.spacing.md),
                  NeonButton(
                    text: 'Continue with Apple',
                    onPressed: _handleAppleSignIn,
                    variant: 'secondary',
                    icon: LucideIcons.apple,
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildUserInfoForm() {
    return [
      _buildTextField(
        controller: _fullNameController,
        label: 'Full Name',
        icon: LucideIcons.user,
      ),
      SizedBox(height: AppTheme.spacing.md),
      _buildTextField(
        controller: _nicknameController,
        label: 'Nickname',
        icon: LucideIcons.userCircle,
      ),
      SizedBox(height: AppTheme.spacing.md),
      _buildTextField(
        controller: _emailController,
        label: 'Email',
        icon: LucideIcons.mail,
        keyboardType: TextInputType.emailAddress,
      ),
      SizedBox(height: AppTheme.spacing.xl),
      NeonButton(
        text: 'Continue',
        onPressed: () => setState(() {
          _isJoiningTeam ? _step = 3 : context.go('/tutorial');
        }),
      ),
      SizedBox(height: AppTheme.spacing.md),
      Row(
        children: [
          Checkbox(
            value: _isJoiningTeam,
            onChanged: (value) => setState(() => _isJoiningTeam = value!),
          ),
          Text(
            'I want to join a team',
            style: TextStyle(color: AppTheme.colors.text),
          ),
        ],
      ),
    ];
  }

  List<Widget> _buildTeamJoinForm() {
    return [
      _buildTextField(
        controller: _teamCodeController,
        label: 'Team Code',
        icon: LucideIcons.users,
        maxLength: 4,
        keyboardType: TextInputType.number,
      ),
      SizedBox(height: AppTheme.spacing.xl),
      NeonButton(
        text: 'Join Team',
        onPressed: _handleTeamJoin,
      ),
    ];
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    int? maxLength,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.colors.surface,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.md),
        border: Border.all(color: AppTheme.colors.primary),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: AppTheme.spacing.md,
        vertical: AppTheme.spacing.sm,
      ),
      child: TextField(
        controller: controller,
        style: TextStyle(color: AppTheme.colors.text),
        keyboardType: keyboardType,
        maxLength: maxLength,
        decoration: InputDecoration(
          icon: Icon(icon, color: AppTheme.colors.primary),
          labelText: label,
          labelStyle: TextStyle(color: AppTheme.colors.textSecondary),
          border: InputBorder.none,
          counterText: '',
        ),
      ),
    );
  }
}