import 'package:flutter/material.dart';
import '../constants/theme.dart';

class NeonButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final String variant;
  final bool isLoading;
  final bool isDisabled;
  final IconData? icon;

  const NeonButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.variant = 'primary',
    this.isLoading = false,
    this.isDisabled = false,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final colors = AppTheme.colors;
    final shadows = AppTheme.shadows;

    Color getButtonColor() {
      switch (variant) {
        case 'primary':
          return colors.primary;
        case 'secondary':
          return colors.secondary;
        default:
          return colors.primary;
      }
    }

    List<BoxShadow> getButtonShadow() {
      switch (variant) {
        case 'primary':
          return shadows.primary;
        case 'secondary':
          return shadows.secondary;
        default:
          return shadows.primary;
      }
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppTheme.borderRadius.md),
        boxShadow: isDisabled ? [] : getButtonShadow(),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isDisabled || isLoading ? null : onPressed,
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.md),
          child: Container(
            padding: EdgeInsets.symmetric(
              horizontal: AppTheme.spacing.lg,
              vertical: AppTheme.spacing.md,
            ),
            decoration: BoxDecoration(
              color: isDisabled
                  ? Colors.grey
                  : getButtonColor().withOpacity(0.2),
              border: Border.all(
                color: isDisabled
                    ? Colors.grey
                    : getButtonColor(),
                width: 2,
              ),
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.md),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null && !isLoading)
                  Padding(
                    padding: EdgeInsets.only(right: AppTheme.spacing.sm),
                    child: Icon(
                      icon!,
                      color: colors.text,
                      size: 20,
                    ),
                  ),
                if (isLoading)
                  Padding(
                    padding: EdgeInsets.only(right: AppTheme.spacing.sm),
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          colors.text,
                        ),
                      ),
                    ),
                  ),
                Text(
                  text,
                  style: TextStyle(
                    color: colors.text,
                    fontFamily: AppTheme.fonts.primary,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}