import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../models/tier_model.dart';
import '../constants/theme.dart';
import '../providers/app_provider.dart';
import '../services/currency_service.dart';
import 'neon_button.dart';

class TierCard extends StatefulWidget {
  final TierModel tier;
  final VoidCallback? onTap;
  final bool isSelected;

  const TierCard({
    super.key,
    required this.tier,
    this.onTap,
    this.isSelected = false,
  });

  @override
  State<TierCard> createState() => _TierCardState();
}

class _TierCardState extends State<TierCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 1.05,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    _glowAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    if (widget.tier.isActive) {
      _animationController.repeat(reverse: true);
    }
  }

  @override
  void didUpdateWidget(TierCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.tier.isActive && !oldWidget.tier.isActive) {
      _animationController.repeat(reverse: true);
    } else if (!widget.tier.isActive && oldWidget.tier.isActive) {
      _animationController.stop();
      _animationController.reset();
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currencyService = CurrencyService();
    final appProvider = Provider.of<AppProvider>(context);
    
    return AnimatedBuilder(
      animation: _animationController,
      builder: (context, child) {
        return Transform.scale(
          scale: widget.tier.isActive ? _scaleAnimation.value : 1.0,
          child: GestureDetector(
            onTap: widget.onTap,
            child: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
                gradient: _getCardGradient(),
                border: Border.all(
                  color: _getBorderColor(),
                  width: widget.isSelected ? 3 : 2,
                ),
                boxShadow: _getCardShadows(),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
                child: Stack(
                  children: [
                    // Background pattern
                    _buildBackgroundPattern(),
                    
                    // Main content
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Header with tier number and status
                          _buildHeader(),
                          
                          const SizedBox(height: 12),
                          
                          // Tier name and icon
                          _buildTierInfo(),
                          
                          const SizedBox(height: 16),
                          
                          // Progress bar (if unlocked)
                          if (widget.tier.isUnlocked) _buildProgressBar(),
                          
                          const SizedBox(height: 12),
                          
                          // Stats
                          _buildStats(currencyService, appProvider),
                          
                          const SizedBox(height: 16),
                          
                          // Action button
                          _buildActionButton(appProvider),
                        ],
                      ),
                    ),
                    
                    // Status overlay
                    if (widget.tier.needsRenewal) _buildRenewalOverlay(),
                    if (widget.tier.isExpired) _buildExpiredOverlay(),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildBackgroundPattern() {
    return Positioned.fill(
      child: Opacity(
        opacity: 0.1,
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(_getTierIcon()),
              fit: BoxFit.cover,
              alignment: Alignment.bottomRight,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // Tier number
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: AppTheme.colors.primary.withOpacity(0.2),
            borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
            border: Border.all(
              color: AppTheme.colors.primary,
              width: 1,
            ),
          ),
          child: Text(
            'TIER ${widget.tier.tierNumber}',
            style: TextStyle(
              color: AppTheme.colors.primary,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              fontFamily: AppTheme.fonts.primary,
            ),
          ),
        ),
        
        // Status indicators
        Row(
          children: [
            if (widget.tier.isActive)
              Icon(
                LucideIcons.zap,
                color: AppTheme.colors.success,
                size: 20,
              ).animate(onPlay: (controller) => controller.repeat())
                .shimmer(duration: 1500.ms),
            
            if (widget.tier.needsRenewal)
              Icon(
                LucideIcons.alertTriangle,
                color: AppTheme.colors.warning,
                size: 20,
              ),
            
            if (widget.tier.isExpired)
              Icon(
                LucideIcons.clock,
                color: AppTheme.colors.error,
                size: 20,
              ),
          ],
        ),
      ],
    );
  }

  Widget _buildTierInfo() {
    return Row(
      children: [
        // Tier icon
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: _getIconBackgroundColor(),
            borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
            border: Border.all(
              color: _getIconBorderColor(),
              width: 2,
            ),
          ),
          child: Icon(
            _getTierIconData(),
            color: _getIconColor(),
            size: 24,
          ),
        ),
        
        const SizedBox(width: 12),
        
        // Tier name and description
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.tier.name,
                style: TextStyle(
                  color: AppTheme.colors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: AppTheme.fonts.primary,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                widget.tier.description,
                style: TextStyle(
                  color: AppTheme.colors.textSecondary,
                  fontSize: 12,
                  fontFamily: AppTheme.fonts.secondary,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildProgressBar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Progress',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 12,
                fontFamily: AppTheme.fonts.secondary,
              ),
            ),
            Text(
              '${widget.tier.adsWatched}/${widget.tier.adsRequired} ads',
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 12,
                fontFamily: AppTheme.fonts.secondary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          height: 6,
          decoration: BoxDecoration(
            color: AppTheme.colors.surface,
            borderRadius: BorderRadius.circular(3),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: widget.tier.progressPercentage,
              backgroundColor: Colors.transparent,
              valueColor: AlwaysStoppedAnimation<Color>(
                widget.tier.isActive ? AppTheme.colors.primary : AppTheme.colors.secondary,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStats(CurrencyService currencyService, AppProvider appProvider) {
    return Row(
      children: [
        Expanded(
          child: _buildStatItem(
            'Unlock Cost',
            currencyService.formatCurrency(
              widget.tier.unlockCost,
              appProvider.userCurrency,
            ),
            LucideIcons.unlock,
          ),
        ),
        Expanded(
          child: _buildStatItem(
            'Daily Earning',
            currencyService.formatCurrency(
              widget.tier.dailyEarning,
              appProvider.userCurrency,
            ),
            LucideIcons.trendingUp,
          ),
        ),
      ],
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              icon,
              color: AppTheme.colors.textSecondary,
              size: 14,
            ),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                color: AppTheme.colors.textSecondary,
                fontSize: 11,
                fontFamily: AppTheme.fonts.secondary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: AppTheme.colors.text,
            fontSize: 14,
            fontWeight: FontWeight.bold,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
      ],
    );
  }

  Widget _buildActionButton(AppProvider appProvider) {
    String buttonText;
    VoidCallback? onPressed;
    NeonButtonVariant variant = NeonButtonVariant.primary;
    
    if (!widget.tier.isUnlocked) {
      buttonText = 'UNLOCK';
      onPressed = () => _unlockTier(appProvider);
      variant = NeonButtonVariant.primary;
    } else if (widget.tier.needsRenewal) {
      buttonText = 'RENEW';
      onPressed = () => _renewTier(appProvider);
      variant = NeonButtonVariant.warning;
    } else if (widget.tier.isActive) {
      buttonText = 'WATCH AD';
      onPressed = appProvider.canWatchMoreAds ? () => _watchAd(appProvider) : null;
      variant = NeonButtonVariant.success;
    } else {
      buttonText = 'ACTIVATE';
      onPressed = () => _activateTier(appProvider);
      variant = NeonButtonVariant.secondary;
    }
    
    return SizedBox(
      width: double.infinity,
      child: NeonButton(
        text: buttonText,
        onPressed: onPressed,
        variant: variant,
        isLoading: appProvider.isLoading,
      ),
    );
  }

  Widget _buildRenewalOverlay() {
    return Positioned(
      top: 0,
      right: 0,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: AppTheme.colors.warning,
          borderRadius: const BorderRadius.only(
            bottomLeft: Radius.circular(8),
            topRight: Radius.circular(16),
          ),
        ),
        child: Text(
          'RENEWAL REQUIRED',
          style: TextStyle(
            color: AppTheme.colors.background,
            fontSize: 10,
            fontWeight: FontWeight.bold,
            fontFamily: AppTheme.fonts.primary,
          ),
        ),
      ),
    );
  }

  Widget _buildExpiredOverlay() {
    return Positioned.fill(
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.colors.error.withOpacity(0.1),
          borderRadius: BorderRadius.circular(AppTheme.borderRadius.large),
        ),
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: AppTheme.colors.error,
              borderRadius: BorderRadius.circular(AppTheme.borderRadius.medium),
            ),
            child: Text(
              'EXPIRED',
              style: TextStyle(
                color: AppTheme.colors.background,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.fonts.primary,
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Helper methods
  LinearGradient _getCardGradient() {
    if (widget.tier.isActive) {
      return LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          AppTheme.colors.primary.withOpacity(0.2),
          AppTheme.colors.secondary.withOpacity(0.1),
          AppTheme.colors.surface,
        ],
      );
    } else if (widget.tier.isUnlocked) {
      return LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          AppTheme.colors.secondary.withOpacity(0.1),
          AppTheme.colors.surface,
        ],
      );
    } else {
      return LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          AppTheme.colors.surface,
          AppTheme.colors.background,
        ],
      );
    }
  }

  Color _getBorderColor() {
    if (widget.isSelected) {
      return AppTheme.colors.primary;
    } else if (widget.tier.isActive) {
      return AppTheme.colors.primary.withOpacity(_glowAnimation.value);
    } else if (widget.tier.isUnlocked) {
      return AppTheme.colors.secondary;
    } else {
      return AppTheme.colors.border;
    }
  }

  List<BoxShadow> _getCardShadows() {
    if (widget.tier.isActive) {
      return [
        BoxShadow(
          color: AppTheme.colors.primary.withOpacity(0.3 * _glowAnimation.value),
          blurRadius: 20,
          spreadRadius: 2,
        ),
        ...AppTheme.shadows.medium,
      ];
    } else if (widget.tier.isUnlocked) {
      return AppTheme.shadows.small;
    } else {
      return [];
    }
  }

  IconData _getTierIconData() {
    // Map tier numbers to appropriate icons
    const tierIcons = {
      1: LucideIcons.zap,
      2: LucideIcons.flame,
      3: LucideIcons.star,
      4: LucideIcons.diamond,
      5: LucideIcons.crown,
      6: LucideIcons.trophy,
      7: LucideIcons.rocket,
      8: LucideIcons.gem,
      9: LucideIcons.shield,
      10: LucideIcons.swords,
      11: LucideIcons.target,
      12: LucideIcons.thunderbolt,
      13: LucideIcons.sparkles,
      14: LucideIcons.infinity,
      15: LucideIcons.atom,
      16: LucideIcons.galaxy,
      17: LucideIcons.sun,
      18: LucideIcons.moon,
      19: LucideIcons.planet,
      20: LucideIcons.universe,
    };
    
    return tierIcons[widget.tier.tierNumber] ?? LucideIcons.circle;
  }

  String _getTierIcon() {
    return 'assets/images/tier_${widget.tier.tierNumber}.png';
  }

  Color _getIconBackgroundColor() {
    if (widget.tier.isActive) {
      return AppTheme.colors.primary.withOpacity(0.2);
    } else if (widget.tier.isUnlocked) {
      return AppTheme.colors.secondary.withOpacity(0.2);
    } else {
      return AppTheme.colors.surface;
    }
  }

  Color _getIconBorderColor() {
    if (widget.tier.isActive) {
      return AppTheme.colors.primary;
    } else if (widget.tier.isUnlocked) {
      return AppTheme.colors.secondary;
    } else {
      return AppTheme.colors.border;
    }
  }

  Color _getIconColor() {
    if (widget.tier.isActive) {
      return AppTheme.colors.primary;
    } else if (widget.tier.isUnlocked) {
      return AppTheme.colors.secondary;
    } else {
      return AppTheme.colors.textSecondary;
    }
  }

  // Action methods
  void _unlockTier(AppProvider appProvider) async {
    final success = await appProvider.unlockTier(widget.tier.id);
    if (success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Tier ${widget.tier.tierNumber} unlocked successfully!'),
          backgroundColor: AppTheme.colors.success,
        ),
      );
    }
  }

  void _renewTier(AppProvider appProvider) async {
    final success = await appProvider.renewTier(widget.tier.id);
    if (success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Tier ${widget.tier.tierNumber} renewed successfully!'),
          backgroundColor: AppTheme.colors.success,
        ),
      );
    }
  }

  void _watchAd(AppProvider appProvider) async {
    final result = await appProvider.watchAd(widget.tier);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(result.message),
          backgroundColor: result.success ? AppTheme.colors.success : AppTheme.colors.error,
        ),
      );
    }
  }

  void _activateTier(AppProvider appProvider) {
    // Implement tier activation logic
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Tier ${widget.tier.tierNumber} activated!'),
        backgroundColor: AppTheme.colors.success,
      ),
    );
  }
}