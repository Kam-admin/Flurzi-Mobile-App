class TierModel {
  final String id;
  final int tierNumber;
  final String name;
  final double unlockCost; // in GBP
  final int adsRequired;
  final double dailyEarning;
  final String iconPath;
  final String description;
  final bool isUnlocked;
  final bool isActive;
  final DateTime? unlockDate;
  final DateTime? expiryDate;
  final int adsWatched;
  final double progress;

  TierModel({
    required this.id,
    required this.tierNumber,
    required this.name,
    required this.unlockCost,
    required this.adsRequired,
    required this.dailyEarning,
    required this.iconPath,
    required this.description,
    this.isUnlocked = false,
    this.isActive = false,
    this.unlockDate,
    this.expiryDate,
    this.adsWatched = 0,
    this.progress = 0.0,
  });

  factory TierModel.fromJson(Map<String, dynamic> json) {
    return TierModel(
      id: json['id'] ?? '',
      tierNumber: json['tierNumber'] ?? 0,
      name: json['name'] ?? '',
      unlockCost: (json['unlockCost'] ?? 0.0).toDouble(),
      adsRequired: json['adsRequired'] ?? 0,
      dailyEarning: (json['dailyEarning'] ?? 0.0).toDouble(),
      iconPath: json['iconPath'] ?? '',
      description: json['description'] ?? '',
      isUnlocked: json['isUnlocked'] ?? false,
      isActive: json['isActive'] ?? false,
      unlockDate: json['unlockDate'] != null 
          ? DateTime.parse(json['unlockDate']) 
          : null,
      expiryDate: json['expiryDate'] != null 
          ? DateTime.parse(json['expiryDate']) 
          : null,
      adsWatched: json['adsWatched'] ?? 0,
      progress: (json['progress'] ?? 0.0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'tierNumber': tierNumber,
      'name': name,
      'unlockCost': unlockCost,
      'adsRequired': adsRequired,
      'dailyEarning': dailyEarning,
      'iconPath': iconPath,
      'description': description,
      'isUnlocked': isUnlocked,
      'isActive': isActive,
      'unlockDate': unlockDate?.toIso8601String(),
      'expiryDate': expiryDate?.toIso8601String(),
      'adsWatched': adsWatched,
      'progress': progress,
    };
  }

  TierModel copyWith({
    String? id,
    int? tierNumber,
    String? name,
    double? unlockCost,
    int? adsRequired,
    double? dailyEarning,
    String? iconPath,
    String? description,
    bool? isUnlocked,
    bool? isActive,
    DateTime? unlockDate,
    DateTime? expiryDate,
    int? adsWatched,
    double? progress,
  }) {
    return TierModel(
      id: id ?? this.id,
      tierNumber: tierNumber ?? this.tierNumber,
      name: name ?? this.name,
      unlockCost: unlockCost ?? this.unlockCost,
      adsRequired: adsRequired ?? this.adsRequired,
      dailyEarning: dailyEarning ?? this.dailyEarning,
      iconPath: iconPath ?? this.iconPath,
      description: description ?? this.description,
      isUnlocked: isUnlocked ?? this.isUnlocked,
      isActive: isActive ?? this.isActive,
      unlockDate: unlockDate ?? this.unlockDate,
      expiryDate: expiryDate ?? this.expiryDate,
      adsWatched: adsWatched ?? this.adsWatched,
      progress: progress ?? this.progress,
    );
  }

  bool get isExpired {
    if (expiryDate == null) return false;
    return DateTime.now().isAfter(expiryDate!);
  }

  bool get needsRenewal {
    return isUnlocked && isExpired;
  }

  double get progressPercentage {
    if (adsRequired == 0) return 0.0;
    return (adsWatched / adsRequired).clamp(0.0, 1.0);
  }
}