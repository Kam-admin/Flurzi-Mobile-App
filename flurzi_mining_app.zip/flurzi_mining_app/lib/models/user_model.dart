class UserModel {
  final String id;
  final String email;
  final String displayName;
  final String? photoUrl;
  final double totalEarnings;
  final double availableBalance;
  final double pendingBalance;
  final int totalAdsWatched;
  final String? teamId;
  final String? teamRole; // 'owner', 'member'
  final List<String> unlockedTiers;
  final List<String> activeTiers;
  final DateTime createdAt;
  final DateTime lastActiveAt;
  final Map<String, dynamic> preferences;
  final bool isDeveloperMode;
  final String? developerToken;
  final int weeklyAdsWatched;
  final double weeklyEarnings;
  final String country;
  final String currency;
  final bool hasAutoPlayUpgrade;
  final Map<String, dynamic> paymentMethods;

  UserModel({
    required this.id,
    required this.email,
    required this.displayName,
    this.photoUrl,
    this.totalEarnings = 0.0,
    this.availableBalance = 0.0,
    this.pendingBalance = 0.0,
    this.totalAdsWatched = 0,
    this.teamId,
    this.teamRole,
    this.unlockedTiers = const [],
    this.activeTiers = const [],
    required this.createdAt,
    required this.lastActiveAt,
    this.preferences = const {},
    this.isDeveloperMode = false,
    this.developerToken,
    this.weeklyAdsWatched = 0,
    this.weeklyEarnings = 0.0,
    this.country = 'GB',
    this.currency = 'GBP',
    this.hasAutoPlayUpgrade = false,
    this.paymentMethods = const {},
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? '',
      email: json['email'] ?? '',
      displayName: json['displayName'] ?? '',
      photoUrl: json['photoUrl'],
      totalEarnings: (json['totalEarnings'] ?? 0.0).toDouble(),
      availableBalance: (json['availableBalance'] ?? 0.0).toDouble(),
      pendingBalance: (json['pendingBalance'] ?? 0.0).toDouble(),
      totalAdsWatched: json['totalAdsWatched'] ?? 0,
      teamId: json['teamId'],
      teamRole: json['teamRole'],
      unlockedTiers: List<String>.from(json['unlockedTiers'] ?? []),
      activeTiers: List<String>.from(json['activeTiers'] ?? []),
      createdAt: json['createdAt'] != null 
          ? DateTime.parse(json['createdAt']) 
          : DateTime.now(),
      lastActiveAt: json['lastActiveAt'] != null 
          ? DateTime.parse(json['lastActiveAt']) 
          : DateTime.now(),
      preferences: Map<String, dynamic>.from(json['preferences'] ?? {}),
      isDeveloperMode: json['isDeveloperMode'] ?? false,
      developerToken: json['developerToken'],
      weeklyAdsWatched: json['weeklyAdsWatched'] ?? 0,
      weeklyEarnings: (json['weeklyEarnings'] ?? 0.0).toDouble(),
      country: json['country'] ?? 'GB',
      currency: json['currency'] ?? 'GBP',
      hasAutoPlayUpgrade: json['hasAutoPlayUpgrade'] ?? false,
      paymentMethods: Map<String, dynamic>.from(json['paymentMethods'] ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'totalEarnings': totalEarnings,
      'availableBalance': availableBalance,
      'pendingBalance': pendingBalance,
      'totalAdsWatched': totalAdsWatched,
      'teamId': teamId,
      'teamRole': teamRole,
      'unlockedTiers': unlockedTiers,
      'activeTiers': activeTiers,
      'createdAt': createdAt.toIso8601String(),
      'lastActiveAt': lastActiveAt.toIso8601String(),
      'preferences': preferences,
      'isDeveloperMode': isDeveloperMode,
      'developerToken': developerToken,
      'weeklyAdsWatched': weeklyAdsWatched,
      'weeklyEarnings': weeklyEarnings,
      'country': country,
      'currency': currency,
      'hasAutoPlayUpgrade': hasAutoPlayUpgrade,
      'paymentMethods': paymentMethods,
    };
  }

  UserModel copyWith({
    String? id,
    String? email,
    String? displayName,
    String? photoUrl,
    double? totalEarnings,
    double? availableBalance,
    double? pendingBalance,
    int? totalAdsWatched,
    String? teamId,
    String? teamRole,
    List<String>? unlockedTiers,
    List<String>? activeTiers,
    DateTime? createdAt,
    DateTime? lastActiveAt,
    Map<String, dynamic>? preferences,
    bool? isDeveloperMode,
    String? developerToken,
    int? weeklyAdsWatched,
    double? weeklyEarnings,
    String? country,
    String? currency,
    bool? hasAutoPlayUpgrade,
    Map<String, dynamic>? paymentMethods,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      totalEarnings: totalEarnings ?? this.totalEarnings,
      availableBalance: availableBalance ?? this.availableBalance,
      pendingBalance: pendingBalance ?? this.pendingBalance,
      totalAdsWatched: totalAdsWatched ?? this.totalAdsWatched,
      teamId: teamId ?? this.teamId,
      teamRole: teamRole ?? this.teamRole,
      unlockedTiers: unlockedTiers ?? this.unlockedTiers,
      activeTiers: activeTiers ?? this.activeTiers,
      createdAt: createdAt ?? this.createdAt,
      lastActiveAt: lastActiveAt ?? this.lastActiveAt,
      preferences: preferences ?? this.preferences,
      isDeveloperMode: isDeveloperMode ?? this.isDeveloperMode,
      developerToken: developerToken ?? this.developerToken,
      weeklyAdsWatched: weeklyAdsWatched ?? this.weeklyAdsWatched,
      weeklyEarnings: weeklyEarnings ?? this.weeklyEarnings,
      country: country ?? this.country,
      currency: currency ?? this.currency,
      hasAutoPlayUpgrade: hasAutoPlayUpgrade ?? this.hasAutoPlayUpgrade,
      paymentMethods: paymentMethods ?? this.paymentMethods,
    );
  }

  bool get isTeamOwner => teamRole == 'owner';
  bool get isTeamMember => teamId != null;
  bool get canInviteToTeam => isTeamOwner;
}