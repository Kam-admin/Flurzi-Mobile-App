class QuestModel {
  final String id;
  final String title;
  final String description;
  final String type; // 'daily', 'weekly', 'special', 'partner'
  final double reward;
  final String? iconUrl;
  final Map<String, dynamic> requirements;
  final DateTime startDate;
  final DateTime endDate;
  final bool isActive;
  final int maxCompletions;
  final int currentCompletions;
  final List<String> completedByUsers;
  final String? partnerName;
  final String? externalUrl;
  final Map<String, dynamic> metadata;

  QuestModel({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.reward,
    this.iconUrl,
    this.requirements = const {},
    required this.startDate,
    required this.endDate,
    this.isActive = true,
    this.maxCompletions = -1, // -1 means unlimited
    this.currentCompletions = 0,
    this.completedByUsers = const [],
    this.partnerName,
    this.externalUrl,
    this.metadata = const {},
  });

  factory QuestModel.fromJson(Map<String, dynamic> json) {
    return QuestModel(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      type: json['type'] ?? 'daily',
      reward: (json['reward'] ?? 0.0).toDouble(),
      iconUrl: json['iconUrl'],
      requirements: Map<String, dynamic>.from(json['requirements'] ?? {}),
      startDate: json['startDate'] != null 
          ? DateTime.parse(json['startDate']) 
          : DateTime.now(),
      endDate: json['endDate'] != null 
          ? DateTime.parse(json['endDate']) 
          : DateTime.now().add(const Duration(days: 1)),
      isActive: json['isActive'] ?? true,
      maxCompletions: json['maxCompletions'] ?? -1,
      currentCompletions: json['currentCompletions'] ?? 0,
      completedByUsers: List<String>.from(json['completedByUsers'] ?? []),
      partnerName: json['partnerName'],
      externalUrl: json['externalUrl'],
      metadata: Map<String, dynamic>.from(json['metadata'] ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'type': type,
      'reward': reward,
      'iconUrl': iconUrl,
      'requirements': requirements,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
      'isActive': isActive,
      'maxCompletions': maxCompletions,
      'currentCompletions': currentCompletions,
      'completedByUsers': completedByUsers,
      'partnerName': partnerName,
      'externalUrl': externalUrl,
      'metadata': metadata,
    };
  }

  bool get isExpired => DateTime.now().isAfter(endDate);
  bool get isAvailable => isActive && !isExpired && !isMaxedOut;
  bool get isMaxedOut => maxCompletions > 0 && currentCompletions >= maxCompletions;
  
  bool isCompletedBy(String userId) {
    return completedByUsers.contains(userId);
  }
}

class LeaderboardEntry {
  final String userId;
  final String displayName;
  final String? photoUrl;
  final double earnings;
  final int adsWatched;
  final int rank;
  final String? teamId;
  final String? teamName;
  final DateTime lastUpdate;

  LeaderboardEntry({
    required this.userId,
    required this.displayName,
    this.photoUrl,
    required this.earnings,
    required this.adsWatched,
    required this.rank,
    this.teamId,
    this.teamName,
    required this.lastUpdate,
  });

  factory LeaderboardEntry.fromJson(Map<String, dynamic> json) {
    return LeaderboardEntry(
      userId: json['userId'] ?? '',
      displayName: json['displayName'] ?? '',
      photoUrl: json['photoUrl'],
      earnings: (json['earnings'] ?? 0.0).toDouble(),
      adsWatched: json['adsWatched'] ?? 0,
      rank: json['rank'] ?? 0,
      teamId: json['teamId'],
      teamName: json['teamName'],
      lastUpdate: json['lastUpdate'] != null 
          ? DateTime.parse(json['lastUpdate']) 
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'earnings': earnings,
      'adsWatched': adsWatched,
      'rank': rank,
      'teamId': teamId,
      'teamName': teamName,
      'lastUpdate': lastUpdate.toIso8601String(),
    };
  }
}

class WithdrawalRequest {
  final String id;
  final String userId;
  final double amount;
  final String currency;
  final String method; // 'paypal', 'bank'
  final Map<String, dynamic> paymentDetails;
  final String status; // 'pending', 'processing', 'completed', 'failed'
  final DateTime requestedAt;
  final DateTime? processedAt;
  final String? transactionId;
  final String? failureReason;

  WithdrawalRequest({
    required this.id,
    required this.userId,
    required this.amount,
    required this.currency,
    required this.method,
    required this.paymentDetails,
    this.status = 'pending',
    required this.requestedAt,
    this.processedAt,
    this.transactionId,
    this.failureReason,
  });

  factory WithdrawalRequest.fromJson(Map<String, dynamic> json) {
    return WithdrawalRequest(
      id: json['id'] ?? '',
      userId: json['userId'] ?? '',
      amount: (json['amount'] ?? 0.0).toDouble(),
      currency: json['currency'] ?? 'GBP',
      method: json['method'] ?? 'paypal',
      paymentDetails: Map<String, dynamic>.from(json['paymentDetails'] ?? {}),
      status: json['status'] ?? 'pending',
      requestedAt: json['requestedAt'] != null 
          ? DateTime.parse(json['requestedAt']) 
          : DateTime.now(),
      processedAt: json['processedAt'] != null 
          ? DateTime.parse(json['processedAt']) 
          : null,
      transactionId: json['transactionId'],
      failureReason: json['failureReason'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'amount': amount,
      'currency': currency,
      'method': method,
      'paymentDetails': paymentDetails,
      'status': status,
      'requestedAt': requestedAt.toIso8601String(),
      'processedAt': processedAt?.toIso8601String(),
      'transactionId': transactionId,
      'failureReason': failureReason,
    };
  }

  bool get isPending => status == 'pending';
  bool get isProcessing => status == 'processing';
  bool get isCompleted => status == 'completed';
  bool get isFailed => status == 'failed';
}