class TeamModel {
  final String id;
  final String name;
  final String description;
  final String ownerId;
  final String ownerName;
  final String inviteCode;
  final List<TeamMember> members;
  final int maxMembers;
  final double totalEarnings;
  final double weeklyEarnings;
  final Map<String, double> earningsDistribution; // userId -> percentage
  final DateTime createdAt;
  final DateTime lastActiveAt;
  final bool isPublic;
  final Map<String, dynamic> settings;

  TeamModel({
    required this.id,
    required this.name,
    required this.description,
    required this.ownerId,
    required this.ownerName,
    required this.inviteCode,
    this.members = const [],
    this.maxMembers = 10,
    this.totalEarnings = 0.0,
    this.weeklyEarnings = 0.0,
    this.earningsDistribution = const {},
    required this.createdAt,
    required this.lastActiveAt,
    this.isPublic = false,
    this.settings = const {},
  });

  factory TeamModel.fromJson(Map<String, dynamic> json) {
    return TeamModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      description: json['description'] ?? '',
      ownerId: json['ownerId'] ?? '',
      ownerName: json['ownerName'] ?? '',
      inviteCode: json['inviteCode'] ?? '',
      members: (json['members'] as List<dynamic>? ?? [])
          .map((m) => TeamMember.fromJson(m))
          .toList(),
      maxMembers: json['maxMembers'] ?? 10,
      totalEarnings: (json['totalEarnings'] ?? 0.0).toDouble(),
      weeklyEarnings: (json['weeklyEarnings'] ?? 0.0).toDouble(),
      earningsDistribution: Map<String, double>.from(
        (json['earningsDistribution'] ?? {}).map(
          (key, value) => MapEntry(key, (value ?? 0.0).toDouble()),
        ),
      ),
      createdAt: json['createdAt'] != null 
          ? DateTime.parse(json['createdAt']) 
          : DateTime.now(),
      lastActiveAt: json['lastActiveAt'] != null 
          ? DateTime.parse(json['lastActiveAt']) 
          : DateTime.now(),
      isPublic: json['isPublic'] ?? false,
      settings: Map<String, dynamic>.from(json['settings'] ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'ownerId': ownerId,
      'ownerName': ownerName,
      'inviteCode': inviteCode,
      'members': members.map((m) => m.toJson()).toList(),
      'maxMembers': maxMembers,
      'totalEarnings': totalEarnings,
      'weeklyEarnings': weeklyEarnings,
      'earningsDistribution': earningsDistribution,
      'createdAt': createdAt.toIso8601String(),
      'lastActiveAt': lastActiveAt.toIso8601String(),
      'isPublic': isPublic,
      'settings': settings,
    };
  }

  bool get hasAvailableSlots => members.length < maxMembers;
  int get availableSlots => maxMembers - members.length;
  
  TeamMember? getMember(String userId) {
    try {
      return members.firstWhere((m) => m.userId == userId);
    } catch (e) {
      return null;
    }
  }

  bool isMember(String userId) {
    return members.any((m) => m.userId == userId);
  }

  double getMemberEarningsPercentage(String userId) {
    return earningsDistribution[userId] ?? 0.0;
  }
}

class TeamMember {
  final String userId;
  final String displayName;
  final String? photoUrl;
  final String role; // 'owner', 'member'
  final DateTime joinedAt;
  final double contributedEarnings;
  final int adsWatched;
  final bool isActive;

  TeamMember({
    required this.userId,
    required this.displayName,
    this.photoUrl,
    required this.role,
    required this.joinedAt,
    this.contributedEarnings = 0.0,
    this.adsWatched = 0,
    this.isActive = true,
  });

  factory TeamMember.fromJson(Map<String, dynamic> json) {
    return TeamMember(
      userId: json['userId'] ?? '',
      displayName: json['displayName'] ?? '',
      photoUrl: json['photoUrl'],
      role: json['role'] ?? 'member',
      joinedAt: json['joinedAt'] != null 
          ? DateTime.parse(json['joinedAt']) 
          : DateTime.now(),
      contributedEarnings: (json['contributedEarnings'] ?? 0.0).toDouble(),
      adsWatched: json['adsWatched'] ?? 0,
      isActive: json['isActive'] ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'role': role,
      'joinedAt': joinedAt.toIso8601String(),
      'contributedEarnings': contributedEarnings,
      'adsWatched': adsWatched,
      'isActive': isActive,
    };
  }

  bool get isOwner => role == 'owner';
}